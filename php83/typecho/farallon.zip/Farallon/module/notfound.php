<main class="site--main">              
            <header class="archive-header archive-header__search">
                <div class="pagination">
                    <h2>Sorry</h2>
                    <p>很遗憾,未找到您期待的内容</p>
                </div> 
            </header> 
        </main>  