<?php
if (!defined('puyuetian')) {
    exit('403');
}

if ('out' == input('get.type/s')) {
    UserLogout(true);
    setcookie('USERNAME', '', time() - 3600);
    setcookie('PASSWORD', '', time() - 3600);
    setcookie('SESSION_TOKEN', '', time() - 3600);
    if (input('get.json/s')) {
        ExitJson('退出成功', true);
    }
    ExitGourl('index.php?from=loginout');
}

if (user('id')) {
    PkPopup('{
		icon:0,
		shade:1,
		nomove:1,
		hideclose:1,
		content:"您已登录",
		submit:function(){
			location.href="' . ReWriteURL('center') . '"
		}
	}');
}
set('webtitle', '用户登录' . (set('webaddedwords') ? '-' . set('webaddedwords') : ''));
gConcat('htmlcode.output', template('login', true));
