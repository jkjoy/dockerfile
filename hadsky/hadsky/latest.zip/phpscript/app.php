<?php
if (!defined('puyuetian')) {
    exit('Not Found puyuetian!Please contact QQ632827168');
}

g('app.a', Cstr(strtolower(input('get.a/s')), false, g('string.lowercase') . g('string.numerical') . '_:', 1, 255));
if (g('app.a') && strpos(g('app.a'), ':') === false) {
    g('app.a', g('app.a') . ':index');
}
if (!g('app.a')) {
    PkPopup('{
		content:"非法的请求参数",
		icon:2,
		shade:1,
		hideclose:1,
		nomove:1,
		submit:function(){
			window.close()
		}
	}');
}
g('app.as', explode(':', g('app.a')));
if (count(g('app.as')) != 2) {
    PkPopup('{
		content:"非法的插件请求",
		icon:2,
		shade:1,
		hideclose:1,
		nomove:1,
		submit:function(){
			window.close()
		}
	}');
}
sys('appdir', g('app.as')[0]);
sys('appfile', g('app.as')[1]);
if (InArray('load,embed', sys('appfile'))) {
    PkPopup('{
		content:"加载文件禁止直接访问",
		icon:2,
		shade:1,
		hideclose:1,
		nomove:1,
		submit:function(){
			window.close()
		}
	}');
}
sys('apppath', sys('path') . 'app/' . sys('appdir') . '/' . sys('appfile') . '.php');
if (!file_exists(sys('apppath')) || !set('app_' . sys('appdir') . '_load')) {
    PkPopup('{
		content:"不存在的应用或未启用",
		icon:2,
		shade:1,
		hideclose:1,
		nomove:1,
		submit:function(){
			window.close()
		}
	}');
}
sys('appconfig', sys('path') . 'app/' . sys('appdir') . '/config.json');
if (file_exists(sys('appconfig'))) {
    sys('appconfig', json_decode(file_get_contents(sys('appconfig')), true));
    set([
        'webtitle'       => sys('appconfig')['title'] . (set('webaddedwords') ? '-' . set('webaddedwords') : ''),
        'webkeywords'    => sys('appconfig')['title'],
        'webdescription' => sys('appconfig')['description'],
    ]);
} else {
    sys('appconfig', []);
}

// 部分插件公共环境运行，无法独立
require sys('apppath');
