<?php
if (!defined('puyuetian')) {
    exit('403');
}

include set('php_include_path');
