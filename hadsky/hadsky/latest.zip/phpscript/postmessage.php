<?php
if (!defined('puyuetian')) {
    exit('403');
}

if (!$_G['USER']['ID']) {
    ExitJson('请登录后再操作');
}
if (InArray(getUserQX(), 'nopostmsg')) {
    ExitJson('您无权发送消息');
}
if (!$_G['GET']['UID'] || $_G['GET']['UID'] == $_G['USER']['ID']) {
    ExitJson('不能自己给自己发消息');
}
$content        = strip_tags($_POST['content']);
$content_strlen = mb_strlen($_POST['content']);
$content_maxlen = Cnum($_G['SET']['POSTMESSAGEMAXNUM'], 0, true, 0);
if ($content_maxlen && $content_strlen > $content_maxlen) {
    ExitJson("每条消息最多{$content_maxlen}个字");
}
if (!$content && 0 !== $content) {
    ExitJson('内容不能为空');
}

$ss = time() - Cnum(JsonData($_G['USER']['DATA'], 'lasttimemessageposttime')) - 5;
if ($ss < 0) {
    ExitJson('操作太快，请稍后一会再操作');
}
//检测消息是否包含违禁词
$wjcs = $_G['SET']['BANPOSTWORDS'];
if ($wjcs) {
    $wjcs = explode(',', $wjcs);
    foreach ($wjcs as $w) {
        if ($w) {
            if (strpos(str_replace(array("\n", "\r", "\r\n", "\t", " ", "&nbsp;"), '', strip_tags($content)), $w) !== false) {
                ExitJson('您发送的消息包含违禁词，无法发送');
            }
        }
    }
}
$udata = $_G['TABLE']['USER']->getData($_G['GET']['UID']);
if (!$udata) {
    ExitJson('不存在的目标用户');
}
if (strpos($udata['friends'], "_{$_G['USER']['ID']}_") === false) {
    NewMessage($_G['GET']['UID'], '陌生人<a class="pk-text-bold" target="_blank" href="index.php?c=center&uid=' . $_G['USER']['ID'] . '">[' . $_G['USER']['NICKNAME'] . ']</a>：' . $content, 0, 2);
} else {
    NewMessage($_G['GET']['UID'], $content, $_G['USER']['ID']);
}
//记录最后一次发布时间
$array['id']   = $_G['USER']['ID'];
$array['data'] = JsonData($_G['USER']['DATA'], 'lasttimemessageposttime', time());
$_G['TABLE']['USER']->newData($array);
ExitJson('发送成功', true);
