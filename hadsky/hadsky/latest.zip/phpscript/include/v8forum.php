<?php
if (!defined('puyuetian')) {
    exit('Not Found puyuetian!Please contact QQ632827168');
}

$id = input('get.id/d');
if (!chkReadSortQx($id, 'readlevel')) {
    set([
        'webtitle'       => '提示',
        'webkeywords'    => '',
        'webdescription' => '',
    ]);
    PkPopup('{
		content:"您的阅读权限太低或您的用户组不被允许",
		icon:2,
		hideclose:1,
		shade:1
	}');
}
$forumDb = table('readsort');
if (set('forumshowids') && !$id) {
    $forumDb->where('id', 'IN', set('forumshowids'));
} else {
    $forumDb->where([
        'pid'  => $id,
        'show' => 1,
    ]);
}
$forumlist = $forumDb->order('rank', 'asc')->select();
// 不存在子版块
if ($id && !$forumlist) {
    ExitGourl(ReWriteURL('list', "sortid={$id}&page=1"));
}
// 获取子版块
foreach ($forumlist as $k => $v) {
    $forumlist[$k]['children'] = table('readsort')->where([
        'pid'  => $v['id'],
        'show' => 1,
    ])->order('rank', 'asc')->select();
}
if ($id) {
    // 获取版块信息
    $forumdata = table('readsort')->where($id)->find();
    // 是否设置了版块跳转
    if ($forumdata['url']) {
        ExitGourl($forumdata['url']);
    }
    if ($forumdata['webtitle']) {
        $webtitle = $forumdata['webtitle'];
    } else {
        $webtitle = strip_tags($forumdata['title']);
        if (set('webaddedwords')) {
            $webtitle .= '-' . set('webaddedwords');
        }
    }

    if ($forumdata['webkeywords']) {
        $webkeywords = $forumdata['webkeywords'];
    } else {
        $webkeywords = strip_tags($forumdata['title']);
    }
    if ($forumdata['webdescription']) {
        $webdescription = $forumdata['webdescription'];
    } else {
        if ($forumdata['content']) {
            $webdescription = strip_tags($pdata['content']);
        } else {
            $webdescription = strip_tags($forumdata['title']);
        }
    }
    set([
        'webtitle'       => $webtitle,
        'webkeywords'    => $webkeywords,
        'webdescription' => $webdescription,
    ]);
} else {
    $forumdata = [];
    set('webtitle', '版块列表' . (set('webaddedwords') ? '-' . set('webaddedwords') : ''));
}
gConcat('htmlcode.output', template('forum', [
    'forumdata' => $forumdata,
    'forumlist' => $forumlist,
]));
