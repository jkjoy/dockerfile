<?php
if (!defined('puyuetian')) {
    exit('403');
}

$sortid  = Cnum($_G['GET']['SORTID'], 0, true, 1);
$type    = $_G['GET']['TYPE'];
$page    = Cnum($_G['GET']['PAGE'], 1, true, 1);
$syy     = $page - 1;
$xyy     = $page + 1;
$prenum  = Cnum($_G['SET']['READLISTNUM'], 10, true, 1);
$spos    = ($page - 1) * $prenum;
$noqxtip = '请<a class=\\"pk-text-primary pk-hover-underline\\" href=\\"' . ReWriteURL('login', '', 'referer=' . urlencode(sys('location'))) . '\\">登录</a>后再操作';

if (!InArray(getUserQX(), 'lookread')) {
    PkPopup('{
        icon:2,
        shade:1,
        nomove:1,
		hideclose:1,
		content:"' . (user('id') ? '您无权查看任何文章' : $noqxtip) . '"
	}');
}
if (!chkReadSortQx($sortid, 'looklevel')) {
    PkPopup('{
		content:"' . (user('id') ? '您所在的用户组阅读权限太低或自身阅读权限太低无法查看该板块内容' : $noqxtip) . '",
		icon:2,
        nomove:1,
		hideclose:true,
		shade:true
	}');
}
if ($_GET['label']) {
    //安全处理
    $label    = '';
    $labels   = array_unique(explode(',', $_GET['label']));
    $sqllabel = ' and (';
    $i        = 0;
    foreach ($labels as $value) {
        if ($value) {
            $sqllabel .= '`label` like ' . mysqlstr(preg_replace('/[\"\']+/', '', strip_tags($value)), true, '%', true) . ' or ';
        }
        $i++;
        if ($i > 9) {
            break;
        }
    }
    if (' and (' != $sqllabel) {
        $sqllabel = substr($sqllabel, 0, -4) . ')';
    } else {
        $sqllabel = '';
    }
}
if ($sortid) {
    $forumdata = $_G['TABLE']['READSORT']->getData($sortid);
    // 是否设置了版块跳转
    if ($forumdata['url']) {
        ExitGourl($forumdata['url']);
    }
    if ($forumdata['showchildlist']) {
        $forumdatas = $_G['TABLE']['READSORT']->getDatas(0, 0, "where `pid`={$sortid}", false, 'id');
        $sql        = " and (`sortid`={$sortid} or ";
        foreach ($forumdatas as $value) {
            $sql .= "`sortid`={$value['id']} or ";
        }
        $sql = substr($sql, 0, strlen($sql) - 4) . ')';
    } else {
        $sql = " and `sortid`={$sortid}";
    }
} else {
    if ($_G['SET']['READLISTSHOWBKS'] || $_G['SET']['READLISTHIDDENBKS']) {
        if ($_G['SET']['READLISTSHOWBKS']) {
            $sql = ' and (';
            $bks = explode(',', $_G['SET']['READLISTSHOWBKS']);
            foreach ($bks as $value) {
                $sql .= '`sortid`=' . $value . ' or ';
            }
            $sql = substr($sql, 0, strlen($sql) - 4) . ')';
        } else {
            $sql = ' and (';
            $bks = explode(',', $_G['SET']['READLISTHIDDENBKS']);
            foreach ($bks as $value) {
                $sql .= '`sortid`<>' . $value . ' and ';
            }
            $sql = substr($sql, 0, strlen($sql) - 5) . ')';
        }
    } else {
        $sql = '';
    }
}

if ($sqllabel) {
    $sql .= ($sql ? ' ' . $sqllabel : $sqllabel);
}

if ('high' == $type) {
    $sql .= ' and `high`=1';
}
$template    = template('list-2', true, false, false);
$topreadhtml = $normalreadhtml = '';
if (InArray('activetime,posttime', $_G['GET']['ORDER'])) {
    $_G['SET']['READLISTORDER'] = $_G['GET']['ORDER'];
}

for ($i = 0; $i < 2; $i++) {
    $readdatas = array();
    if (!$sortid && !$i) {
        if (1 != $page || !$_G['SET']['ACTIVETOPREADIDS']) {
            continue;
        }
        //动态页单独处理
        $sql2  = $sql;
        $_aids = explode(',', $_G['SET']['ACTIVETOPREADIDS']);
        foreach ($_aids as $_id) {
            $_readdata = $_G['TABLE']['READ']->getData(array('id' => Cnum($_id)));
            if ($_readdata) {
                $readdatas[] = $_readdata;
            }
        }
        unset($_aids, $_id, $_readdata);
    } else {
        //先读取置顶帖，在读取其他贴
        if ($sortid) {
            $sql2 = (0 == $i ? ' and `top`=1' . $sql : ' and `top`=0' . $sql);
        } else {
            $sql2 = $sql;
        }
        if (ltrim($sql2, ' and ')) {
            $hs_sql = 'where ' . ltrim($sql2, ' and ') . ' order by `' . Cstr($_G['SET']['READLISTORDER'], 'activetime', true, 1, 255) . '` desc,`id` desc';
        } else {
            $hs_sql = 'order by `' . Cstr($_G['SET']['READLISTORDER'], 'activetime', true, 1, 255) . '` desc';
        }
        $readdatas = $_G['TABLE']['READ']->getDatas($spos, $prenum, $hs_sql);
    }
    if ($i) {
        $readcount = $_G['TABLE']['READ']->getCount(ltrim($sql2, ' and ') ? 'where ' . ltrim($sql2, ' and ') : '');
        $pagecount = Cnum(ceil($readcount / $prenum), 1, true, 1);
        if ($page > $pagecount) {
            $page = $pagecount;
        }
    } else {
        if ($sortid && $_G['SET']['GLOBALTOPREADIDS']) {
            // 加入全局置顶帖子
            $_readdatas = $_G['TABLE']['READ']->getDatas(0, 0, "WHERE `id` IN ({$_G['SET']['GLOBALTOPREADIDS']}) ORDER BY field(id,{$_G['SET']['GLOBALTOPREADIDS']})");
            if ($readdatas) {
                $readdatas = array_merge($_readdatas, $readdatas);
            } else {
                $readdatas = $_readdatas;
            }
        }
    }
    if ($readdatas) {
        foreach ($readdatas as $readdata) {
            //该文章的版块信息
            if ($sortid) {
                $readsortdata = $forumdata;
            } else {
                $readsortdata = $_G['TABLE']['READSORT']->getData($readdata['sortid']);
            }
            //检测是否为回复查看帖
            if ($readdata['replyafterlook']) {
                if ($_G['USER']['ID']) {
                    if (!$_G['TABLE']['REPLY']->getId(array('rid' => $readdata['id'], 'uid' => $_G['USER']['ID']))) {
                        $readdata['content'] = '该文章设置了回复查看，请回复后查看内容';
                    }
                } else {
                    $readdata['content'] = '您需要登录并回复后才可以查看该文章内容';
                }
            }
            //部分内容回复后可见
            $readdata['content'] = preg_replace('/\<p class="PytReplylook"\>[\s\S]+?\<\/p\>/', '<p>隐藏内容</p>', $readdata['content']);
            //检测阅读权限是否合法
            if ((($_G['USERGROUP']['ID'] && Cnum($readdata['readlevel']) > Cnum($_G['USERGROUP']['READLEVEL'])) || (!$_G['USERGROUP']['ID'] && Cnum($readdata['readlevel']) > Cnum($_G['USER']['READLEVEL']))) || !chkReadSortQx($sortid, 'readlevel')) {
                $readdata['content'] = '您的阅读权限太低或您的用户组不被允许';
            }
            if ($readdata['uid']) {
                $readuserdata = $_G['TABLE']['USER']->getData($readdata['uid']);
            } else {
                $readuserdata = JsonData($_G['SET']['GUESTDATA']);
            }
            $replydata = $_G['TABLE']['REPLY']->getData($readdata['replyid']);
            if ($replydata['uid']) {
                $replyuserdata = $_G['TABLE']['USER']->getData($replydata['uid']);
            } else {
                $replyuserdata = JsonData($_G['SET']['GUESTDATA']);
            }
            $i == 0 ? $topreadhtml .= template('list-2', true, $template) : $normalreadhtml .= template('list-2', true, $template);
        }
    }
}

//seo优化
if ($forumdata) {
    $label                 = $forumdata['label'];
    $_G['SET']['WEBTITLE'] = strip_tags($forumdata['title']) . (Cnum($_G['GET']['PAGE'], 1, true, 1) != 1 ? '-第' . Cnum($_G['GET']['PAGE'], 1, true, 1) . '页' : '') . ($_G['SET']['WEBADDEDWORDS'] ? "-{$_G['SET']['WEBADDEDWORDS']}" : '');
    if ($forumdata['webtitle']) {
        $_G['SET']['WEBTITLE'] = $forumdata['webtitle'];
    }
    if ($forumdata['webkeywords']) {
        $_G['SET']['WEBKEYWORDS'] = $forumdata['webkeywords'];
    } else {
        if ($forumdata['label']) {
            $_G['SET']['WEBKEYWORDS'] = $forumdata['label'];
        }
    }
    if ($forumdata['webdescription']) {
        $_G['SET']['WEBDESCRIPTION'] = $forumdata['webdescription'];
    } else {
        if ($forumdata['content']) {
            $_G['SET']['WEBDESCRIPTION'] = strip_tags($forumdata['content']);
        }
    }
} else {
    $label = $_G['SET']['DEFAULTLABEL'];
    if ('list' != $_G['SET']['DEFAULTPAGE']) {
        $_G['SET']['WEBTITLE'] = '动态' . (1 != $page ? '-第' . Cnum($_G['GET']['PAGE'], 1, true, 1) . '页' : '') . ($_G['SET']['WEBADDEDWORDS'] ? "-{$_G['SET']['WEBADDEDWORDS']}" : '');
    } else {
        $_G['SET']['WEBTITLE'] .= (Cnum($_G['GET']['PAGE'], 1, true, 1) != 1 ? '-第' . Cnum($_G['GET']['PAGE'], 1, true, 1) . '页' : '');
    }
}

//读取版块标签
$labels                   = explode(',', $label);
$_G['TEMP']['LABELSHTML'] = '<div id="forumlabel">';
foreach ($labels as $value) {
    if ($value) {
        $_G['TEMP']['LABELSHTML'] .= '<a href="javascript:">' . preg_replace('/[\'\"]+/', '', strip_tags($value)) . '</a>';
    }
}
$_G['TEMP']['LABELSHTML'] .= '</div>';

$_G['HTMLCODE']['OUTPUT'] .= template('list-1', true);
$_G['HTMLCODE']['OUTPUT'] .= $topreadhtml;
$_G['HTMLCODE']['OUTPUT'] .= $normalreadhtml;
$_G['HTMLCODE']['OUTPUT'] .= template('list-3', true);
