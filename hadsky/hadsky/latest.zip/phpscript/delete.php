<?php
if (!defined('puyuetian')) {
    exit('403');
}

$table = $_G['GET']['TABLE'];

if (('read' != $table && 'reply' != $table) || !$_G['GET']['ID']) {
    if ($_G['GET']['JSON']) {
        ExitJson('参数非法');
    } else {
        exit('illegal parameter');
    }
}

$data = $_G['TABLE'][strtoupper($table)]->getData($_G['GET']['ID']);

if (!$data) {
    if ($_G['GET']['JSON']) {
        ExitJson('不存在的id');
    } else {
        exit('Does not exist ID');
    }
}

if ('reply' == $table) {
    $sortid = $_G['TABLE']['READ']->getData($data['rid']);
} else {
    $sortid = $_G['TABLE']['READ']->getData($_G['GET']['ID']);
}
$sortid  = $sortid['sortid'];
$bkdata  = $_G['TABLE']['READSORT']->getData($sortid);
$bkadmin = (InArray($bkdata['adminuids'], $_G['USER']['ID']) && $_G['USER']['ID']) ? true : false;

if (1 == $_G['USER']['ID'] || (InArray(getUserQX(), 'del' . $table) && (InArray(getUserQX(), 'admin,superadmin') || $bkadmin || $data['uid'] == $_G['USER']['ID']))) {
    if (!$_G['SET']['DELRRNOJT']) {
        UserDataChange(array("jifen" => Cnum($_G['SET']['POST' . strtoupper($table) . 'JIFEN']), "tiandou" => Cnum($_G['SET']['POST' . strtoupper($table) . 'TIANDOU'])), $data['uid'], '-', ('read' == $table ? '文章' : '回复') . '被删除');
    }
    // 移动至回收站
    moveToCycle($table, $_G['GET']['ID']);
    if ($_G['GET']['JSON']) {
        ExitJson('操作成功', true);
    } else {
        exit('ok');
    }
} else {
    if ($_G['GET']['JSON']) {
        ExitJson('无权操作');
    } else {
        exit('Unauthorized operation');
    }
}
