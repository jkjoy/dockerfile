<?php
if (!defined('puyuetian')) {
    exit('403');
}

if (user('id')) {
    PkPopup('{
		content:"您已登录，无需注册",
		icon:2,
		shade:1,
		nomove:1,
		hideclose:1,
		submit:function(){
			location.href="' . ReWriteURL('center') . '";
		}
	}');
}
set('webtitle', '用户注册' . (set('webaddedwords') ? '-' . set('webaddedwords') : ''));
if (!set('openreg')) {
    PkPopup('{
		content:"' . str_replace(['"', "\r", "\n"], ['\\"', '', '\\n'], set('closeregtip')) . '",
		icon:0,
		shade:1,
		nomove:1,
		hideclose:1,
		submit:function(){
			location.href="index.php";
		}
	}');
}
gConcat('htmlcode.output', template('reg', true));
