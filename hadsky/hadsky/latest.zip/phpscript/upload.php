<?php
if (!defined('puyuetian')) {
    exit('403');
}

// v8上传组件
if (!InArray(getUserQX(), 'uploadfile')) {
    if (!user('id')) {
        v8Error('请先登录');
    }
    v8Error('无权上传');
}

$upload = new upload();
$r      = $upload->file(\input('upload_input_name/s'));
if (!$r) {
    \v8Error($upload->error());
}
\v8Success('ok', $upload->moves());
