<?php
if (!defined('puyuetian')) {
    exit('403');
}

$rid    = input('get.rid/d');
$type   = input('get.type/s');
$page   = input('get.page/d');
$limit  = input('get.limit/d');
$candel = function ($data) {
    if (InArray(getUserQX(), 'admin') || InArray(getUserQX(), 'superman')) {
        return true;
    }
    if (InArray(getUserQX(), 'delreply') && user('id') == $data['uid']) {
        return true;
    }
    // 获取版块管理员
    $reply = table('reply')->where($data['rid'])->find();
    $read  = table('read')->where($reply['rid'])->find();
    $forum = table('readsort')->where($read['sortid'])->find();
    if (InArray($forum['adminuids'], user('id'))) {
        return true;
    }
    return false;
};

switch ($type) {
    case 'get':
        $datas = table('reply_reply')->where([
            'rid' => $rid,
        ])->page($page, $limit)->order('id', set('replyorder') ? 'desc' : 'asc')->select();

        foreach ($datas as $k => $v) {
            if ($v['uid']) {
                $datas[$k]['user']          = table('user')->where($v['uid'])->find();
                $datas[$k]['usergroup']     = table('usergroup')->where($datas[$k]['user']['groupid'])->find();
                $datas[$k]['user']['title'] = userTitle($datas[$k]['user']);
            } else {
                $datas[$k]['user'] = JsonData(set('guestdata'));
            }
            $datas[$k]['user']['userhead'] = userheadURL($v['uid']);
            $datas[$k]['date']             = date('Y-m-d', $v['posttime']);
            $datas[$k]['datetime']         = date('Y-m-d H:i', $v['posttime']);
            $datas[$k]['del']              = false;
            $datas[$k]['noreply']          = true;
            if ($candel($v)) {
                $datas[$k]['del'] = true;
            }
            if (InArray(getUserQX(), 'postreply')) {
                $datas[$k]['noreply'] = false;
            }
        }
        v8Success('ok', [
            'list' => $datas,
        ]);
        break;
    case 'del':
        $id    = input('get.id/d');
        $reply = table('reply_reply')->where($id)->find();
        if (!$candel($reply)) {
            v8Error('无权删除');
        }
        if (!moveToCycle('reply_reply', $id)) {
            v8Error('删除失败');
        }
        v8Success('ok');
        break;
    default:
        # code...
        break;
}
g('template.head', 'null');
g('template.body', 'replyreply');
g('template.foot', 'null');
