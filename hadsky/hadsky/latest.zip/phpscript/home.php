<?php
if (!defined('puyuetian')) {
    exit('403');
}

if (!tSet(set('templatename'), 'bodynottohome')) {
    g('template.body', 'home');
} else {
    gConcat('htmlcode.output', template('home', true));
}

if ('home' != set('defaultpage')) {
    set('webtitle', '首页' . (set('webaddedwords') ? '-' . set('webaddedwords') : ''));
}
