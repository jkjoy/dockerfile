<?php
if (!defined('puyuetian'))
	exit('403');

ExitGourl(ReWriteURL('list'));
