<?php
if (!defined('puyuetian'))
	exit('403');

if ($_G['GET']['ID']) {
	if (!$_G['TABLE']['READSORT'] -> getCount(array('show' => 1, 'pid' => $_G['GET']['ID']))) {
		header('Location:' . ReWriteURL('list', "sortid={$_G['GET']['ID']}&page=1"));
		exit('<script>location.href="' . ReWriteURL('list', "sortid={$_G['GET']['ID']}&page=1") . '"</script>');
	}
}

$_G['TEMPLATE']['BODY'] = 'output';
$_G['SET']['SUMPOSTR'] = $_G['TABLE']['READ'] -> getCount(array('del' => 0));
$_G['SET']['SUMPOSTRR'] = $_G['SET']['SUMPOSTR'] + $_G['TABLE']['REPLY'] -> getCount(array('del' => 0));
$_G['SET']['YESTODAYPOSTRR'] = $_G['TABLE']['READ'] -> getCount('where `del`=0 and `posttime`>' . (strtotime(date('Y-m-d 00:00:00', time())) - 86400) . ' and `posttime`<' . (strtotime(date('Y-m-d 23:59:59', time())) - 86400)) + $_G['TABLE']['REPLY'] -> getCount('where `del`=0 and `posttime`>' . (strtotime(date('Y-m-d 00:00:00', time())) - 86400) . ' and `posttime`<' . (strtotime(date('Y-m-d 23:59:59', time())) - 86400));
$_G['SET']['TODAYPOSTRR'] = $_G['TABLE']['READ'] -> getCount('where `del`=0 and `posttime`>' . strtotime(date('Y-m-d 00:00:00', time())) . ' and `posttime`<' . strtotime(date('Y-m-d 23:59:59', time()))) + $_G['TABLE']['REPLY'] -> getCount('where `del`=0 and `posttime`>' . strtotime(date('Y-m-d 00:00:00', time())) . ' and `posttime`<' . strtotime(date('Y-m-d 23:59:59', time())));
$_G['SET']['MEMBERCOUNT'] = $_G['TABLE']['USER'] -> getCount();

$_G['TEMP']['NUSER'] = $_G['TABLE']['USER'] -> getData('order by `id` desc', FALSE, 'id,nickname');
