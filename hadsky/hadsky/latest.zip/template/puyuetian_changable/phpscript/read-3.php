<?php
if (!defined('puyuetian'))
	exit('403');

global $page, $pagecount;
if (!$page) {
	$page = 1;
}
if (!$pagecount) {
	$pagecount = 1;
}
if ($pagecount < 6) {
	$i = 1;
	$c = $pagecount + 1;
} else {
	$page = Cnum($page, $pagecount, TRUE, 1, $pagecount);
	$i = $page - 2;
	if ($page < 4) {
		$i = 1;
	}
	if ($page > $pagecount - 3) {
		$i = $pagecount - 4;
	}
	$c = $i + 5;
}

$_G['GET']['ID'] = Cnum($_G['GET']['ID'], 0, TRUE, 0);
$q = '';
if ($_G['GET']['ORDERFIELD']) {
	$q .= "orderfield={$_G['GET']['ORDERFIELD']}";
}
if ($_G['GET']['DESC']) {
	$q .= "&desc={$_G['GET']['DESC']}";
}
$q && $q = substr($q, 1);
$_G['TEMP']['HTML'] = $page > 1 ? '<a href="' . ReWriteURL('read', "id={$_G['GET']['ID']}&page=1", $q) . '" title="首页，第1页">首</a>' : '<a href="javascript:" title="首页">首</a>';
for ($i2 = $i; $i2 < $c; $i2++) {
	$_G['TEMP']['HTML'] .= '<a href="' . ($page == $i2 ? 'javascript:' : ReWriteURL('read', "id={$_G['GET']['ID']}&page=" . ($i2), $q)) . '" title="第' . $i2 . '页">' . $i2 . '</a>';
}
$_G['TEMP']['HTML'] .= ($page < $pagecount) ? '<a href="' . ReWriteURL('read', "id={$_G['GET']['ID']}&page=" . $pagecount, $q) . '" title="尾页，第' . $pagecount . '页">尾</a>' : '<a href="javascript:" title="尾页">尾</a>';
