<?php
if (!defined('puyuetian'))
	exit('403');

if (Cnum($_G['GET']['SORTID'])) {
	$data = $forumdata;
	$_G['TEMP']['LISTTITLE'] = $data['title'];
	$_G['TEMP']['LISTCONTENT'] = $data['content'];
	$_G['TEMP']['TODAYCOUNT'] = getReadCount($_G['GET']['SORTID'], 'today');
	$_G['TEMP']['READCOUNT'] = getReadCount($_G['GET']['SORTID']);
} else {
	$_G['TEMP']['LISTTITLE'] = '最新动态';
	$_G['TEMP']['LISTCONTENT'] = '汇集全站版块最新文章';
	$_G['TEMP']['TODAYCOUNT'] = getReadCount(0, 'today');
	$_G['TEMP']['READCOUNT'] = getReadCount(0);
}

//管理移动操作版块列表
if (InArray(getUserQX(), 'superman')) {
	$_G['TEMP']['FORUMLISTOPTION'] = '';
	$datas = $_G['TABLE']['READSORT'] -> getDatas(0, 0, 'order by `id` desc', FALSE, 'id,title');
	foreach ($datas as $value) {
		$_G['TEMP']['FORUMLISTOPTION'] .= '<option value="' . $value['id'] . '">' . str_replace(array("'", "\r", "\n", "\r\n", "\t", " "), '', (strip_tags($value['title']))) . '(ID:' . $value['id'] . ')</option>';
	}
}

//版块列表
//子版块
$_G['TEMP']['C_F_L'] = '';
if (Cnum($_G['GET']['SORTID'], 0, TRUE, 1)) {
	$datas = $_G['TABLE']['READSORT'] -> getDatas(0, 0, 'where `pid`=' . $_G['GET']['SORTID'] . ' and `show`=1 and `looklevel`<=' . Cnum(getUserQX(FALSE, 'readlevel')) . ' order by `rank`');
	foreach ($datas as $value) {
		if ($value['gourl']) {
			$_url = $value['gourl'] . '" target="_blank';
		} else {
			$_url = ReWriteURL('forum', "sortid={$value['id']}");
		}
		$_G['TEMP']['C_F_L'] .= '<li><a href="' . $_url . '" title="' . htmlspecialchars($value['title'], ENT_QUOTES) . '"><span class="fa fa-fw fa-comments-o"></span>' . $value['title'] . '</a></li>';
	}
}
//全部版块
$_G['TEMP']['P_F_L'] = '';
$datas = $_G['TABLE']['READSORT'] -> getDatas(0, 0, 'where `pid`=0 and `show`=1 and `looklevel`<=' . Cnum(getUserQX(FALSE, 'readlevel')) . ' order by `rank`');
foreach ($datas as $value) {
	if ($value['gourl']) {
		$_url = $value['gourl'] . '" target="_blank';
	} else {
		$_url = ReWriteURL('forum', "sortid={$value['id']}");
	}
	$_G['TEMP']['P_F_L'] .= '<li><a href="' . $_url . '" title="' . htmlspecialchars($value['title'], ENT_QUOTES) . '"><span class="fa fa-fw fa-comments-o"></span>' . $value['title'] . '</a></li>';
}
