<?php
if (!defined('puyuetian'))
	exit('403');

global $forumdata;

if ($forumdata['url']) {
	$_G['TEMP']['TARGET'] = '_blank';
	$_G['TEMP']['FORUMURL'] = $forumdata['url'];
} else {
	$_G['TEMP']['TARGET'] = '';
	$_G['TEMP']['FORUMURL'] = ReWriteURL('forum', 'id=' . $forumdata['id']);
}

$_G['TEMP']['READCOUNT'] = $_G['TABLE']['READ'] -> getCount(array('del' => 0, 'sortid' => $forumdata['id']));
$datas = $_G['TABLE']['READSORT'] -> getDatas(0, 0, 'where `pid`=' . $forumdata['id'] . ' order by `rank`', FALSE, 'id');
foreach ($datas as $value) {
	$_G['TEMP']['READCOUNT'] += $_G['TABLE']['READ'] -> getCount(array('del' => 0, 'sortid' => $value['id']));
}
