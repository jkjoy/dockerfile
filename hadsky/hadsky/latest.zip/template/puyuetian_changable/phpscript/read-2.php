<?php
if (!defined('puyuetian'))
	exit('403');

global $replyuserdata, $replyuserhtml, $replydata, $bkdata;

//浮动窗口
$blzd = 'id,username,nickname,sex,birthday,sign,groupid,fans,jifen';
$rud = $replyuserdata;
foreach ($rud as $key => $value) {
	if (!InArray($blzd, $key)) {
		unset($rud[$key]);
	}
}
$gd = $_G['TABLE']['USERGROUP'] -> getData($rud['groupid']);
$rud['groupname'] = 'Lv' . (Cnum($rud['jifen'] / 100)) . '.' . $gd['usergroupname'];
$nl = 0;
if ($rud['birthday']) {
	$nl = date('Y') - substr($rud['birthday'], 0, 4);
}
if ($rud['fans']) {
	$rud['fans'] = count(explode('__', $rud['fans']));
} else {
	$rud['fans'] = 0;
}
if ($rud['sex'] == 'g') {
	$rud['sex'] = "<font style=color:red>女</font> {$nl}岁";
} elseif ($rud['sex'] == 'b') {
	$rud['sex'] = "<font style=color:blue>男</font> {$nl}岁";
} else {
	if ($nl) {
		$rud['sex'] = "{$nl}岁";
	} else {
		$rud['sex'] = '';
	}
}
$_G['TEMP']['F_D'] = htmlspecialchars(json_encode($rud), ENT_QUOTES);

$replyuserhtml = '';
if ($replydata['top']) {
	$replyuserhtml .= '&nbsp;<span class="pk-badge pk-background-color-danger pk-text-xs pk-radius-4 pk-cursor-default"> 置顶 </span>';
}

global $replydata, $readuserdata, $lgtime;
$lgtime = time() - Cnum($replydata['posttime']);
if ($lgtime < 60) {
	$lgtime = '刚刚';
} elseif ($lgtime < 3600) {
	$lgtime = (int)($lgtime / 60) . '分钟前';
} elseif ($lgtime < 86400) {
	$lgtime = (int)($lgtime / 3600) . '小时前';
} elseif ($lgtime < 2592000) {
	$lgtime = (int)($lgtime / 86400) . '天前';
} else {
	$lgtime = date('Y-m-d H:i:s', $replydata['posttime']);
}

$a = adminEditTipbox('reply', $replydata['id']);
$_G['TEMP']['READADMINLINK'] = '';
if ($a) {
	$_G['TEMP']['READADMINLINK'] = '<a class="pk-kxpc-text" href="javascript:" onclick="adminEditTipbox(' . htmlspecialchars(json_encode($a), ENT_QUOTES) . ',{default:function(){location.reload()},del:function(){$(\'#replydivbox-' . $replydata['id'] . '\').remove()}})">管理</a>';
}
