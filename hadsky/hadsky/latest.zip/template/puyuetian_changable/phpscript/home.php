<?php
if (!defined('puyuetian')) {
	exit('403');
}

$hslc = Cnum($_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_SLIDENUM'], 5, true, 1);

$_nssql = '';
if ($_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_HOMENOSHOWSORTIDS']) {
	$_nssql = ' (`sortid`<>\'' . str_replace(',', '\' AND `sortid`<>\'', $_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_HOMENOSHOWSORTIDS']) . '\') AND';
}

//读取最新的图片
$_G['TEMP']['SWIPEHTML'] = '';
if ($hslc) {
	$sliderdatas = $_G['TABLE']['READ'] -> getDatas(0, 100, 'WHERE' . $_nssql . ' `del`=false ORDER BY `id` DESC', false, 'id,title,content');
	$i = 0;
	foreach ($sliderdatas as $sliderdata) {
		if (preg_match_all('#<img.*?src="(.*?)".*?alt="(.*?)".*?\>#', $sliderdata['content'], $match)) {
			$noimglist = 'emotion';
			foreach ($match[1] as $key => $value) {
				if (!InArray($noimglist, $match[2][$key])) {
					$i++;
					$_G['TEMP']['SWIPEHTML'] .= '<div class="swiper-slide"><a target="_blank" href="' . ReWriteURL('read', "id={$sliderdata['id']}&page=1") . '"><img src="' . $value . '" onerror="this.src=\'template/puyuetian_changable/img/error-img.png\'" alt="' . htmlspecialchars(strip_tags($sliderdata['title']), ENT_QUOTES) . '"><p class="bg"></p><p class="txt">' . $sliderdata['title'] . '</p></a></div>';
					if ($i >= $hslc) {
						break 2;
					}
					break;
				}
			}
		}
	}
}

//homenew
$_G['TEMP']['NEW_READ'] = $_G['TEMP']['NEW_REPLY'] = $_G['TEMP']['NEW_MEMBER'] = '';
$_nn = Cnum($_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_HOMENEWNUMS'], 10, true, 1);
//read
$datas = $_G['TABLE']['READ'] -> getDatas(0, $_nn, 'where' . $_nssql . ' `del`=false order by `posttime` desc', false, 'id,title,posttime');
foreach ($datas as $value) {
	$_G['TEMP']['NEW_READ'] .= '<li class="pk-row"><div class="pk-w-md-8 pk-padding-0 pk-text-truncate"><a target="_blank" href="' . ReWriteURL('read', "id={$value['id']}&page=1") . '" title="' . str_replace('"', '', strip_tags($value['title'])) . '">' . $value['title'] . '</a></div><div class="pk-w-md-4 pk-padding-0 pk-text-right">' . date('Y-m-d', $value['posttime']) . '</div></li>';
}
//reply
$datas = $_G['TABLE']['READ'] -> getDatas(0, $_nn, 'where' . $_nssql . ' `del`=false and `fs`>1 order by `activetime` desc', false, 'id,title,activetime');
foreach ($datas as $value) {
	$_G['TEMP']['NEW_REPLY'] .= '<li class="pk-row"><div class="pk-w-md-8 pk-padding-0 pk-text-truncate"><a target="_blank" href="' . ReWriteURL('read', "id={$value['id']}&page=1") . '" title="' . str_replace('"', '', strip_tags($value['title'])) . '">' . $value['title'] . '</a></div><div class="pk-w-md-4 pk-padding-0 pk-text-right">' . date('Y-m-d', $value['activetime']) . '</div></li>';
}
//member
$datas = $_G['TABLE']['USER'] -> getDatas(0, $_nn, 'order by `id` desc', false, 'id,nickname,regtime');
foreach ($datas as $value) {
	$_G['TEMP']['NEW_MEMBER'] .= '<li class="pk-row"><div class="pk-w-md-8 pk-padding-0 pk-text-truncate"><a target="_blank" href="' . ReWriteURL('center', "id={$value['id']}&page=1") . '" title="' . str_replace('"', '', strip_tags($value['nickname'])) . '">' . $value['nickname'] . '</a></div><div class="pk-w-md-4 pk-padding-0 pk-text-right">' . date('Y-m-d', $value['regtime']) . '</div></li>';
}

//xx最多
$_a = array('looknum', 'fs', 'zannum');
$time1 = time() - (86400 * Cnum($_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_HOMEREADLISTDAYS'], 30, true, 1));
$_num = Cnum($_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_HOMEREADLISTNUMS'], 15, true, 1);
for ($i = 0; $i < count($_a); $i++) {
	$_G['TEMP'][$_a[$i]] = '';
	$datas = $_G['TABLE']['READ'] -> getDatas(0, $_num, 'where' . $_nssql . ' `posttime`>' . $time1 . ' and `del`=false order by `' . $_a[$i] . '` desc', false, 'id,title');
	foreach ($datas as $key => $value) {
		$_G['TEMP'][$_a[$i]] .= '<div class="pk-w-md-4 pk-text-truncate"><a target="_blank" class="pk-kxpc-text hover" href="' . ReWriteURL('read', "id={$value['id']}&page=1") . '" title="' . str_replace('"', '', strip_tags($value['title'])) . '">' . $value['title'] . '</a></div>';
	}
}

//网站信息
$_G['SET']['SUMPOSTR'] = $_G['TABLE']['READ'] -> getCount(array('del' => 0));
$_G['SET']['SUMPOSTRR'] = $_G['SET']['SUMPOSTR'] + $_G['TABLE']['REPLY'] -> getCount(array('del' => 0));
$_G['SET']['YESTODAYPOSTRR'] = $_G['TABLE']['READ'] -> getCount('where `del`=0 and `posttime`>' . (strtotime(date('Y-m-d 00:00:00', time())) - 86400) . ' and `posttime`<' . (strtotime(date('Y-m-d 23:59:59', time())) - 86400)) + $_G['TABLE']['REPLY'] -> getCount('where `del`=0 and `posttime`>' . (strtotime(date('Y-m-d 00:00:00', time())) - 86400) . ' and `posttime`<' . (strtotime(date('Y-m-d 23:59:59', time())) - 86400));
$_G['SET']['TODAYPOSTRR'] = $_G['TABLE']['READ'] -> getCount('where `del`=0 and `posttime`>' . strtotime(date('Y-m-d 00:00:00', time())) . ' and `posttime`<' . strtotime(date('Y-m-d 23:59:59', time()))) + $_G['TABLE']['REPLY'] -> getCount('where `del`=0 and `posttime`>' . strtotime(date('Y-m-d 00:00:00', time())) . ' and `posttime`<' . strtotime(date('Y-m-d 23:59:59', time())));
$_G['SET']['MEMBERCOUNT'] = $_G['TABLE']['USER'] -> getCount();

//版块导航
$_G['TEMP']['FORUMS'] = '';
if ($_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_HOMEFORUMIDS']) {
	$_a = explode(',', $_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_HOMEFORUMIDS']);
	$sql = '';
	foreach ($_a as $value) {
		$sql .= "`id`='{$value}' or ";
	}
	$sql .= '(' . substr($sql, 0, -4) . ')';
	$forumdatas = $_G['TABLE']['READSORT'] -> getDatas(0, 0, 'where ' . $sql . ' order by `rank`', false, 'id,title,content,pid,logourl');
} else {
	$forumdatas = $_G['TABLE']['READSORT'] -> getDatas(0, 0, 'where `pid`=0 and `show`=1 order by `rank`', false, 'id,title,content,pid,logourl');
}
foreach ($forumdatas as $forumdata) {
	$_G['TEMP']['READCOUNT'] = $_G['TABLE']['READ'] -> getCount(array('del' => 0, 'sortid' => $forumdata['id']));
	$datas = $_G['TABLE']['READSORT'] -> getDatas(0, 0, 'where `pid`=' . $forumdata['id'] . ' order by `rank`', false, 'id');
	foreach ($datas as $value) {
		$_G['TEMP']['READCOUNT'] += $_G['TABLE']['READ'] -> getCount(array('del' => 0, 'sortid' => $value['id']));
	}
	if ($forumdata['url']) {
		$a = '_blank';
		$b = $forumdata['url'];
	} else {
		$a = '';
		$b = ReWriteURL('forum', 'id=' . $forumdata['id']);
	}
	$_G['TEMP']['FORUMS'] .= '<div id="forumlist-' . $forumdata['id'] . '" class="pk-w-md-6 forumlist"><div class="forumlogo"><a target="' . $a . '" href="' . $b . '"><img src="' . $forumdata['logourl'] . '" onerror="$(this).attr(\'src\',\'template/puyuetian_changable/img/forum.png\').parent().parent().css(\'background-color\',pk_kxpc_primary)" /></a></div><div><div><a class="pk-kxpc-text hover" href="' . ReWriteURL('forum', 'id=' . $forumdata['id']) . '">' . $forumdata['title'] . '</a></div><div>' . $forumdata['content'] . '</div><div>文章数：' . $_G['TEMP']['READCOUNT'] . '</div></div></div>';
}
