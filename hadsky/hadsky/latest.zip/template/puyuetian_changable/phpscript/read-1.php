<?php
if (!defined('puyuetian'))
	exit('403');

global $readdata, $readuserdata, $readuserhtml;
//浮动窗口
$blzd = 'id,username,nickname,sex,birthday,sign,groupid,fans,jifen';
$rud = $readuserdata;
foreach ($rud as $key => $value) {
	if (!InArray($blzd, $key)) {
		unset($rud[$key]);
	}
}
$gd = $_G['TABLE']['USERGROUP'] -> getData($rud['groupid']);
$rud['groupname'] = 'Lv' . (Cnum($rud['jifen'] / 100)) . '.' . $gd['usergroupname'];
$nl = 0;
if ($rud['birthday']) {
	$nl = date('Y') - substr($rud['birthday'], 0, 4);
}
if ($rud['fans']) {
	$rud['fans'] = count(explode('__', $rud['fans']));
} else {
	$rud['fans'] = 0;
}
if ($rud['sex'] == 'g') {
	$rud['sex'] = "<font style=color:red>女</font> {$nl}岁";
} elseif ($rud['sex'] == 'b') {
	$rud['sex'] = "<font style=color:blue>男</font> {$nl}岁";
} else {
	if ($nl) {
		$rud['sex'] = "{$nl}岁";
	} else {
		$rud['sex'] = '';
	}
}
$_G['TEMP']['F_D'] = htmlspecialchars(json_encode($rud), ENT_QUOTES);
$readuserhtml = $_G['TEMP']['ZDJHHTML'] = '';
if ($readdata['high']) {
	$_G['TEMP']['ZDJHHTML'] .= '<font style="color:blue">精华</font>/';
}
if ($readdata['top']) {
	$_G['TEMP']['ZDJHHTML'] .= '<font style="color:green">置顶</font>/';
}
if ($readdata['locked']) {
	$_G['TEMP']['ZDJHHTML'] .= '<font style="color:red">锁定</font>/';
}
if ($_G['TEMP']['ZDJHHTML']) {
	$_G['TEMP']['ZDJHHTML'] = substr($_G['TEMP']['ZDJHHTML'], 0, strlen($_G['TEMP']['ZDJHHTML']) - 1);
} else {
	$_G['TEMP']['ZDJHHTML'] = '普通';
}

$a = adminEditTipbox('read', $readdata['id']);
$_G['TEMP']['READADMINLINK'] = '';
if ($a) {
	$_G['TEMP']['READADMINLINK'] = '<a class="pk-kxpc-text" href="javascript:" onclick="adminEditTipbox(' . htmlspecialchars(json_encode($a), ENT_QUOTES) . ',{default:function(){location.reload()},del:function(){location.href=\'index.php\'}})">管理</a>';
}