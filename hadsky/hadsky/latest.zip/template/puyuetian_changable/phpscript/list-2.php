<?php
if (!defined('puyuetian')) {
	exit('403');
}

global $readdata, $readsortdata, $readuserdata, $replydata, $imgshtml, $lgtime;
//浮动窗口
$blzd = 'id,username,nickname,sex,birthday,sign,groupid,fans,jifen';
$rud = $readuserdata;
foreach ($rud as $key => $value) {
	if (!InArray($blzd, $key)) {
		unset($rud[$key]);
	}
}
$gd = $_G['TABLE']['USERGROUP'] -> getData($rud['groupid']);
$rud['groupname'] = 'Lv' . (Cnum($rud['jifen'] / 100)) . '.' . $gd['usergroupname'];
$nl = 0;
if ($rud['birthday']) {
	$nl = date('Y') - substr($rud['birthday'], 0, 4);
}
if ($rud['fans']) {
	$rud['fans'] = count(explode('__', $rud['fans']));
} else {
	$rud['fans'] = 0;
}
if ($rud['sex'] == 'g') {
	$rud['sex'] = "<font style=color:red>女</font> {$nl}岁";
} elseif ($rud['sex'] == 'b') {
	$rud['sex'] = "<font style=color:blue>男</font> {$nl}岁";
} else {
	if ($nl) {
		$rud['sex'] = "{$nl}岁";
	} else {
		$rud['sex'] = '';
	}
}
$_G['TEMP']['F_D'] = htmlspecialchars(json_encode($rud), ENT_QUOTES);
//
if (!Cnum($_G['GET']['SORTID']) && $readsortdata['title']) {
	$_G['TEMP']['READSORTTITLE'] = '<a target="_blank" class="pk-kxpc-text hover" href="' . ReWriteURL('list', 'sortid=' . $readsortdata['id'] . '&page=1') . '"><span class="fa fa-fw fa-th-large"></span>' . $readsortdata['title'] . '</a>&nbsp;';
} else {
	$_G['TEMP']['READSORTTITLE'] = '';
}
//图标加载
$_G['TEMP']['ZDJHHTML'] = '';
if ($readdata['high']) {
	$_G['TEMP']['ZDJHHTML'] .= '<font style="color:blue">精华</font>/';
}
if ($readdata['top']) {
	$_G['TEMP']['ZDJHHTML'] .= '<font style="color:green">置顶</font>/';
}
if ($readdata['locked']) {
	$_G['TEMP']['ZDJHHTML'] .= '<font style="color:red">锁定</font>/';
}
if ($_G['TEMP']['ZDJHHTML']) {
	$_G['TEMP']['ZDJHHTML'] = '/' . $_G['TEMP']['ZDJHHTML'];
}
if (strpos($readdata['content'], '<img src="') !== false) {
	$readdata['title'] .= '&nbsp;<img src="template/puyuetian_changable/img/image.gif" alt="有图" title="有图" style="width:13px" />';
}
if (strpos($readdata['content'], '<a class="pk-text-primary pk-hover-underline" target="_blank" href="index.php?c=app&amp;a=puyuetianeditor:index&amp;s=showfile&amp;id=') !== false) {
	$readdata['title'] .= '&nbsp;<img src="template/puyuetian_changable/img/attachment.gif" alt="附件" title="附件" style="width:13px" />';
}

//动态时间显示
$readlistorder = Cstr($_G['SET']['READLISTORDER'], 'activetime', true, 1, 255);
if ($readlistorder != 'posttime') {
	$readlistorder = 'activetime';
}
$lgtime = date('Y-m-d', Cnum($readdata[$readlistorder]));
if ($lgtime == date('Y-m-d')) {
	$lgtime = '<font style="color:red">' . date('H:i:s', Cnum($readdata[$readlistorder])) . '</font>';
}

//内容摘要
$_G['TEMP']['CONTENT'] = '';
$zyzs = Cnum($_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_READCONTENTNUM'], false, true, 1);
if ($zyzs) {
	$_G['TEMP']['CONTENT'] = '<div class="pk-text-truncate-multiline pk-word-break-all" style="margin-top:10px;max-height:38px;color:#777">' . EqualReturn(mb_substr(strip_tags($readdata['content']), 0, $zyzs), '', '') . '</div>';
}

// 视频显示，当显示视频的时候，图片默认不显示
$showvideo = false;
if ($_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_LISTSHOWVIDEO']) {
	$videos = getHtmlVideos($readdata['content'], 1);
	if (count($videos)) {
		$_G['TEMP']['CONTENT'] .= '<div class="pk-row">
		<div class="pk-w-sm-12" style="padding:0;padding-top:15px">
			<video src="' . $videos[0]['src'] . '" controls="controls" style="width:100%;height:386px;background-color:#000"></video>
		</div>
		</div>';
		$showvideo = true;
	}
}

// 图片显示
$tpxs = Cnum($_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_READIMGNUM'], false, true, 1);
if ($tpxs && !$showvideo) {
	$imgs = getHtmlImages($readdata['content'], $tpxs);
	$count = count($imgs);
	if ($count) {
		$_G['TEMP']['CONTENT'] .= '<div class="pk-row">';
		for ($i = 0; $i < $count; $i++) {
			switch ($count) {
				case 1:
					$_i = 12;
					break;
				case 2:
					$_i = 6;
					break;
				default:
					$_i = 4;
					break;
			}
			$_G['TEMP']['CONTENT'] .= '<div class="pk-w-sm-' . $_i . ' pk-padding-5" style="height:188px"><img class="pk-cursor-pointer" src="' . $imgs[$i]['src'] . '" alt="" onclick="LookImage(this)" style="width:100%;height:100%;object-fit:cover;border-radius:2px"></div>';
		}
		$_G['TEMP']['CONTENT'] .= '</div>';
	}
}

//管理
$a = adminEditTipbox('read', $readdata['id']);
$_G['TEMP']['READADMINLINK'] = '';
if ($a) {
	$_G['TEMP']['READADMINLINK'] = '<a class="pk-kxpc-text" href="javascript:" onclick="adminEditTipbox(' . htmlspecialchars(json_encode($a), ENT_QUOTES) . ',{default:function(){location.reload()},del:function(){$(\'#listdivbox-' . $readdata['id'] . '\').remove()}})">管理</a>';
}

//用户组
if ($readuserdata['groupid']) {
	$groupdata = $_G['TABLE']['USERGROUP'] -> getData($readuserdata['groupid']);
	$readuserdata['usergroupname'] = $groupdata['usergroupname'];
} else {
	$readuserdata['usergroupname'] = '无组';
}
