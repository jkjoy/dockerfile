<?php
if (!defined('puyuetian'))
	exit('403');

//推荐文章
$tjwz = $_G['SET']['TEMPLATE_PUYUETIAN_CHANGABLE_TJWZ'];
$sql = $_G['TEMP']['READLIST'] = '';
if ($tjwz) {
	if (strpos($tjwz, ':') !== FALSE) {
		$tjwzs = explode(':', $tjwz);
		$sql = "order by `{$tjwzs[0]}` desc";
		if ($tjwzs[1]) {
			$sql = "and `sortid`='{$tjwzs[1]}' {$sql}";
		}
		$sql = "where `del`=false {$sql}";
		$datas = $_G['TABLE']['READ'] -> getDatas(0, Cnum($tjwzs[2], 10, TRUE, 1), $sql);
	} else {
		$tjwzs = explode(',', $tjwz);
		$datas = array();
		foreach ($tjwzs as $value) {
			$data = $_G['TABLE']['READ'] -> getData(Cnum($value, FALSE, TRUE, 1));
			if ($data) {
				$datas[] = $data;
			}
		}
	}
	foreach ($datas as $value) {
		$_G['TEMP']['READLIST'] .= '<li><a target="_blank" href="' . ReWriteURL('read', "id={$value['id']}&page=1") . '">' . $value['title'] . '</a></li>';
	}
}

//背景优化
if (InArray('user,friends,app', $_G['GET']['C'])) {
	$_G['TEMP']['BODY_LEFT'] = 'pk-background-color-white pk-padding-15';
}
