$(function() {
	var mySwiper = new Swiper('.pk-home-slider-1', {
		direction: 'horizontal',
		speed: 1700,
		autoplay: 3000,
		pagination: '.swiper-pagination',
		paginationType: 'bullets',
		paginationClickable: true,
		autoplayDisableOnInteraction: false
	});
	$('.pk-home-slider-1').hover(function() {
		$('.pk-home-slider-1 .bg,.pk-home-slider-1 .txt').animate({
			"height": "48px"
		});
	}, function() {
		$('.pk-home-slider-1 .bg,.pk-home-slider-1 .txt').animate({
			"height": "0px"
		});
	});
	var _h = $('._homenewlist').outerHeight();
	if(_h > 300) {
		$('.pk-home-slider-1').outerHeight(_h);
	}
	$('._homenewlist>div:eq(0)>div').on('click', function() {
		$('._homenewlist>div:eq(0)>div').removeClass('pk-active');
		$('._homenewlist ul').addClass('pk-hide');
		$('._homenewlist ul._new_' + $(this).data('v')).removeClass('pk-hide');
		$(this).addClass('pk-active');
	});
});