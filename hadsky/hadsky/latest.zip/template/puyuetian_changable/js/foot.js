function pk_kxpc_loadtemplate() {
	var _primary = pk_kxpc_primary,
		_secondary = '',
		_fm = pk_kxpc_fm;
	//将16进制颜色转换为rgb颜色
	if(_primary.length == 4 && _primary[0] == '#') {
		_primary = '#' + _primary[1] + _primary[1] + _primary[2] + _primary[2] + _primary[3] + _primary[3];
	}
	if(_primary[0] == '#' && _primary.length == 7) {
		var _r = parseInt(_primary[1] + '' + _primary[2], 16);
		var _g = parseInt(_primary[3] + '' + _primary[4], 16);
		var _b = parseInt(_primary[5] + '' + _primary[6], 16);
	} else if(_primary.substr(0, 3) == 'rgb') {
		_primary = _primary.replace(/[rgb\(\)\s]+/ig, '');
		_primary = _primary.split(',');
		var _r = _primary[0];
		var _g = _primary[1];
		var _b = _primary[2];
	}
	_primary = 'rgb(' + _r + ',' + _g + ',' + _b + ')';
	_secondary = 'rgb(' + parseInt(_r / _fm) + ',' + parseInt(_g / _fm) + ',' + parseInt(_b / _fm) + ')';
	$('#pk-kuxuanpc-searchbox').css('background-color', _secondary);
	$('#puyuetian_kuxuanpc-navbar,.pk-kxpc-btn.primary').css('background-color', _primary);
	$('.pk-kxpc-text.primary,.pk-kxpc-text.primaryhover').css('color', _primary);
	$('#puyuetian_kuxuanpc-navbar ul li[class!="pk-active"],#puyuetian_kuxuanpc-navbar ul li[class!="pk-active"] a').hover(function() {
		$(this).css('background-color', _secondary);
	}, function() {
		$(this).css('background-color', '');
	});
	$('#puyuetian_kuxuanpc-navbar ul li.pk-active').css('background-color', _secondary);
	$('.pk-kxpc-text.hover').hover(function() {
		$(this).css('color', _secondary);
	}, function() {
		$(this).css('color', '');
	});
	$('.pk-kxpc-text.primaryhover').hover(function() {
		$(this).css('color', _secondary);
	}, function() {
		$(this).css('color', _primary);
	});

	$('#listpages a[href!="javascript:"]').css({
		"color": _primary,
		"border-color": _secondary
	});

	$('#listpages a[href="javascript:"]').css({
		"color": "#fff",
		"background-color": _secondary
	});

	$('#listpages a[href!="javascript:"]').hover(function() {
		$(this).css({
			"color": "#fff",
			"background-color": _secondary,
			"border-color": "#fff"
		});
	}, function() {
		$(this).css({
			"color": _primary,
			"background-color": "",
			"border-color": _secondary
		});
	});
	/*
	$('.pk-kxpc-forum-list .forumlogo').css({
		"background-color": _primary
	});
	*/
	if($_USER['C'] == 'user') {
		$('.pk-background-color-primary').removeClass('pk-background-color-primary').css('background-color', _primary).parent().css('border-color', _primary);
	}
	if($_USER['C'] == 'edit') {
		$('head:eq(0)').append('<style>#showforums div{background-color:' + _primary + '};#showforums div:hover{background-color:' + _secondary + '}</style>');
		$('#showforum,#postbtn').css("background-color", _primary);
		$('#showforum,#postbtn').hover(function() {
			$(this).css({
				"background-color": _secondary
			});
		}, function() {
			$(this).css({
				"background-color": _primary
			});
		});
	}
}

var _p = getCookie('template_puyuetian_kuxuanpc_primarycolor');
if(_p) {
	pk_kxpc_primary = _p;
}
pk_kxpc_loadtemplate();

$('#pk-kuxuanpc-searchbox input').keydown(function(e) {
	if(e.keyCode == 13) {
		$('#pk-kuxuanpc-searchbox span').click();
	}
});

$('#pk-kuxuanpc-searchbox span').click(function() {
	var _v = trim($('#pk-kuxuanpc-searchbox input').val());
	trim(_v) ? window.open('index.php?c=app&a=puyuetian_search:index&w=' + encodeURIComponent(_v) + '&chkcsrfval=' + $_USER['CHKCSRFVAL'], '_blank') : $('#pk-kuxuanpc-searchbox input').focus();
});

$('#pk-kxpc-ghps').click(function() {
	var _rnd = randomString(32);
	var _base = ['00', '33', '66', '99', 'CC', 'FF'];
	var _s = [
			"#09f",
			"#009e73",
			"#BF4D4D",
			"#F97F00",
			"#c90",
			"#2A5ABE",
			"#fee200",
			"#1b7e5a",
			"#1abc9c",
			"#24ae44",
			"#168bd8",
			"#777777",
			"#CF9EE0",
			"#5D4B33",
			""
		],
		_h = '<div class="pk-kxpc-xzztys">';
	for(i in _s) {
		_h += '<span style="background' + (_s[i] ? '-color:' + _s[i] : ':url(template/puyuetian_kuxuanpc/img/random.png)" class="' + (pk_kxpc_cd1 ? '' : 'pk-hide') + '" title="彩蛋功能，每秒自动变换主题，不会保存仅体验用') + '"></span>';
	}
	_h += '</div>';
	pkalert(_h, '更换主题配色', false, true);
	$('.pk-kxpc-xzztys>span').click(function() {
		if($(this).attr('title')) {
			pk_zt_random = setInterval(function() {
				var _r = parseInt(Math.random() * 255);
				var _g = parseInt(Math.random() * 255);
				var _b = parseInt(Math.random() * 255);
				pk_kxpc_primary = 'rgb(' + _r + ',' + _g + ',' + _b + ')';
				pk_kxpc_loadtemplate();
			}, 1000);
		} else {
			clearInterval(pk_zt_random);
			pk_kxpc_primary = $(this).css('background-color');
			setCookie('template_puyuetian_kuxuanpc_primarycolor', pk_kxpc_primary, 86400 * 365);
			pk_kxpc_loadtemplate();
		}
	});
});

//登录or已登录
if(parseInt($_USER['ID'])) {
	$('.pk-kxpc-userbox').removeClass('pk-hide');
	//充电吧
	var _bi = 0;
	setInterval(function() {
		_bi++;
		if(_bi > 4) {
			_bi = 0;
		}
		$('#pk-kxpc-battery').attr('class', 'fa fa-battery-' + _bi);
	}, 200);
	//性别
	if($_USER['SEX'] == 'b') {
		$('#pk-kxpc-sexicon').attr({
			"class": "fa fa-male",
			"title": "你好，先生"
		}).css('color', '#69f');
	} else if($_USER['SEX'] == 'g') {
		$('#pk-kxpc-sexicon').attr({
			"class": "fa fa-female",
			"title": "你好，女士"
		}).css('color', '#f69');
	}
	//后台面板
	if($_USER['ID'] == "1") {
		$('#superadminbtn-div').removeClass('pk-hide');
	}
} else {
	$('.pk-kxpc-guestbox').removeClass('pk-hide');
}
$('#showUserInfo>div>img').on('error', function() {
	$(this).attr('src', 'userhead/0.png');
});
$('._float_userbox').on({
	'mouseenter': function() {
		var _f_tmp = '_' + randomString('7');
		var t = $(this).offset().top + $(this).height() / 2;
		var l = $(this).offset().left + $(this).width() / 2;
		//写入数据
		//alert($(this).data('data'));
		var data = eval($(this).data('data'));
		$('#showUserInfo>div').data('uid', data.id);
		$('#showUserInfo>div>img').attr('src', 'userhead/' + data.id + '.png');
		var ps = $('#showUserInfo>div>p');
		for(var i = 0; i < ps.length; i++) {
			var f = $(ps[i]).data('field');
			$(ps[i]).find('span').html(data[f]);
		}
		$('#showUserInfo').data('tmp', _f_tmp).removeClass('pk-hide').css({
			top: t,
			left: l
		});
	},
	'mouseleave': function() {
		var t = $(this).offset().top + $(this).height() / 2;
		var l = $(this).offset().left + $(this).width() / 2;
		var _f_tmp = $('#showUserInfo').data('tmp');
		setTimeout(function() {
			if($('#showUserInfo').data('tmp') == _f_tmp) {
				$('#showUserInfo').addClass('pk-hide');
			}
		}, 1000);
	}
});
$('#showUserInfo').on({
	'mouseenter': function() {
		$(this).data('tmp', '');
	},
	'mouseleave': function() {
		$(this).addClass('pk-hide');
	}
}).find('a').attr('href', 'javascript:').on('click', function() {
	var type = $(this).data('type');
	var uid = $(this).parent().parent().data('uid');
	var username = $(this).parent().parent().find('p[data-field="username"]>span').text();
	if(type == 'message') {
		PostMessageBox({
			uid: uid,
			username: username
		});
		return true;
	}
	if(type == 'center') {
		$url = 'index.php?c=center&uid=' + uid;
		if(Cnum($_SET['REWRITEURL'])) {
			$url = 'center-' + uid + '.html';
		}
		window.open($url, '_blank');
		return true;
	}
	$.getJSON('index.php?c=center', {
		type: type,
		uid: uid,
		chkcsrfval: $_USER['CHKCSRFVAL']
	}, function(data) {
		ppp({
			content: data['datas']['msg'],
			type: 3,
			icon: (data['state'] == 'ok' ? 1 : 0)
		})
	});
});