$(function() {
	//样式
	if($('#pk-c-list-main>div:eq(0)').height() > $('#pk-c-list-main>div:eq(1)').height()) {
		$('#pk-c-list-main>div:eq(1)').height($('#pk-c-list-main>div:eq(0)').height());
	} else {
		$('#pk-c-list-main>div:eq(0)').height($('#pk-c-list-main>div:eq(1)').height());
	}
	if(!$('#pk-c-list-main>div:eq(0) ul.f_l:eq(0)').text()) {
		$('#pk-c-list-main>div:eq(0)>div:eq(1),#pk-c-list-main>div:eq(0)>div:eq(2)').addClass('pk-hide');
	}
	var _top = $('#pk-c-list-main>div:eq(0)').offset().top;
	$(window).on('scroll', function() {
		if(_top < $(window).scrollTop()) {
			$('#pk-c-list-main>div:eq(0)').css({
				position: 'absolute',
				top: $(window).scrollTop() - _top
			});
			$('#pk-c-list-main>div:eq(1)').css({
				marginLeft: '170px'
			});
		} else {
			$('#pk-c-list-main>div:eq(0)').css({
				position: '',
				top: 0
			});
			$('#pk-c-list-main>div:eq(1)').css({
				marginLeft: 0
			});
		}
	});
	$('#read-list .read-list .dingspan').click(function() {
		var This = $(this);
		$.getJSON('index.php?c=ding&type=read&json=yes&id=' + $(this).data('id'), function(data) {
			if(data['state'] == 'ok') {
				This.find('span:eq(1)').html(parseInt(This.find('span:eq(1)').html()) + 1);
			} else {
				pktip('您已经赞过了~', 'info');
			}
		});
	});

	$('#read-list .read-list .admin-a').click(function() {
		var This = $(this);
		ppp({
			type: 1,
			content: '确认' + This.html() + '吗？',
			submit: function() {
				$.getJSON('index.php?c=admincmd&table=read&field=' + This.data('field') + '&value=' + This.data('value') + '&id=' + This.data('id') + '&json=yes&chkcsrfval=' + $_USER['CHKCSRFVAL'], function(data) {
					if(data['state'] == 'ok') {
						ppp({
							type: 3,
							content: '操作成功',
							icon: 1
						});
						location.reload(true);
					} else {
						ppp({
							type: 3,
							content: data['datas']['msg'],
							icon: 2
						});
					}
				});
			}
		});
	});

	$('#read-list .read-list .admin-a-move').click(function() {
		var This = $(this);
		var _rnd = randomString(32);
		var _html = '<select id="hs-' + _rnd + '" class="pk-textbox">' + $('#forumListOption').html() + '</select>';
		ppp({
			type: 1,
			content: _html,
			title: "移动文章",
			noclose: true,
			submit: function(id) {
				$.getJSON('index.php?c=admincmd&table=read&field=sortid&id=' + This.data('id') + '&value=' + $('#hs-' + _rnd).val() + '&json=yes&chkcsrfval=' + $_USER['CHKCSRFVAL'], function(data) {
					if(data['state'] == 'ok') {
						ppp({
							type: 3,
							content: '操作成功',
							icon: 1
						});
					} else {
						ppp({
							type: 3,
							content: data['datas']['msg'],
							icon: 2
						});
					}
					pkpopup.close(id);
				});
			},
			complete: function() {
				$('#hs-' + _rnd).val(This.data('sortid'));
			}
		});
	});
});