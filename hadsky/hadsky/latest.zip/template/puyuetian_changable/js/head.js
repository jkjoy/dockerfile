//热搜词
var _hotwords = $('._hotwords').text();
if(_hotwords) {
	_hotwords = _hotwords.split(',');
	_h = '<span>热搜：</span>';
	for(var i = 0; i < _hotwords.length; i++) {
		_h += '<a href="javascript:">' + _hotwords[i] + '</a>&nbsp;';
	}
	$('._hotwords').html(_h);
	$('._hotwords a').on('click', function() {
		$('.__searchbar input[name="w"]').val($(this).text());
		$('.__searchbar form').submit();
	});
}
if($_GET('w')) {
	$('.__searchbar input[name="w"]').attr('placeholder', decodeURIComponent($_GET('w')));
}
//导航自动更多
var $navas = $('#puyuetian_kuxuanpc-navbar ul li');
var $nav_w = $('#puyuetian_kuxuanpc-navbar ul').parent().width();
//更多按钮初始宽度60
var $nav_ws = 60;
var $nav_c = 10;
for(var i = 0; i < $navas.length; i++) {
	$nav_ws += $($navas[i]).width();
	if($nav_ws > $nav_w) {
		$nav_c = i + 1;
		break;
	}
}
if($navas.length > $nav_c) {
	var $navhtml = '',
		$navdivhtml = '<div class="woshixialacaidantadie2b">';
	for(var $i = 0; $i < $navas.length; $i++) {
		if($i < $nav_c - 1) {
			$navhtml += '<li>' + $($navas[$i]).html() + '</li>';
		} else {
			$navdivhtml += $($navas[$i]).html();
		}
	}
	$navdivhtml += '</div>';
	$navhtml += '<li id="woshixialacaidan2b"><a href="javascript:">更多</a>' + $navdivhtml + '</li>';
	$('#puyuetian_kuxuanpc-navbar ul').html($navhtml);
	$navhtml = '';
	$navdivhtml = '';
	$('#woshixialacaidan2b').hover(function() {
		$('.woshixialacaidantadie2b').css('visibility', 'visible');
	}, function() {
		$('.woshixialacaidantadie2b').css('visibility', 'hidden');
	});
}

//选择当前导航
$navas = $('#puyuetian_kuxuanpc-navbar ul li');
for(var $i = 0; $i < $navas.length; $i++) {
	if($($navas[$i]).find('a')[0].href == location.href) {
		$($navas[$i]).addClass('pk-active');
	}
}