function ReplyNF($uid, $f, $nickname) {
	if($uid) {
		PytCmd('inserthtml', false, '@' + $uid + ':(在' + $f + 'F的' + $nickname + ')&nbsp;');
	} else {
		PytCmd('inserthtml', false, '回复' + $f + '楼:');
	}
}

$(function() {
	if(_usercollect.indexOf("_" + $_URI['ID'] + "_") > -1) {
		$('#_collectbtn').attr("onclick", "Interactive('delcollect', $_URI['ID'], this)").html('<i class="fa fa-fw fa-star-o"></i>取消收藏');
	}

	if($('.pk-kxpc-read .rt>div:eq(0)').height() > 47) {
		$('.pk-kxpc-read .rt>div:eq(0)').toggleClass('pk-text-left pk-text-center');
	}
	var _rh = 500;
	if($('.readcontent').outerHeight() < _rh) {
		var _bh = _rh - $('.readcontent').outerHeight();
		if($('.readcontent').find('p:last').length > 0) {
			$('.readcontent').find('p:last').css('margin-bottom', _bh);
		} else if($('.readcontent').find('div:eq(0)').length > 0) {
			$('.readcontent').find('div:eq(0)').css('margin-top', _bh);
		} else {
			$('.readcontent').outerHeight(_rh);
		}
	}
	$('.readcontent img,.replycontent img').on('click', function() {
		LookImage(this);
	}).on('error', function() {
		$(this).attr({
			src: "template/default/img/imageloaderror.png",
			title: "此图已被狗给吃了~汪呜~"
		});
		$(this).unbind('click,error');
	});
	$('#_zanbtn').on('click', function() {
		var This = $(this);
		$.getJSON('index.php', {
			c: "ding",
			type: "read",
			json: 'yes',
			id: $_URI['ID'],
			chkcsrfval: $_USER['CHKCSRFVAL']
		}, function(data) {
			if(data['state'] == 'ok') {
				This.find('span').html(parseInt(This.find('span').html()) + 1);
				This.unbind();
			} else {
				ppp({
					content: '您已经赞过了',
					type: 3,
					icon: 0
				})
			}
		});
	});
	$('#postreplysubmitbtn').click(function() {
		if(trim(form_post.content.value)) {
			form_post.content.value = form_post.content.value.replace(/\<div/g, '<p');
			form_post.content.value = form_post.content.value.replace(/\<\/div\>/g, '</p>');
			var pid = ppp({
				type: 4,
				shade: 1,
				content: "发布中..."
			});
			var formstring = FormDataPackaging('form[name="form_post"]:eq(0)');
			$.post($('form[name="form_post"]:eq(0)').attr('action'), formstring, function(data) {
				pkpopup.close(pid);
				if(data['state'] == 'ok') {
					ppp({
						type: 3,
						icon: 1,
						content: data['msg'],
						close: function() {
							location.href = "index.php?c=read&id=" + data['rid'] + "&cache=refresh&rnd=" + parseInt(Math.random() * 10000) + "#replylist";
						}
					});
				} else {
					$('form[name="form_post"] input[name="verifycode"]').val('');
					$('#verifycodeimageobject').click();
					ppp({
						icon: 2,
						content: data['msg'] || '未知错误'
					});
				}
				$('#postreplysubmitbtn').prop('disabled', false).html('发布');
			}, 'json');
		} else {
			if(PytEditor.body) {
				PytEditor.body.focus();
			} else {
				form_post.content.focus();
			}
		}
	});
});