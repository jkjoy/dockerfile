<?php
if (!defined('puyuetian')) {
	exit('403');
}

global $readdata, $readuserdata, $readsortdata;
//精华或置顶
$_G['TEMP']['HTHTML'] = '';
if ($readdata['high']) {
	$_G['TEMP']['HTHTML'] .= '<i class="_p_c-high" style="top:0;right:108px"></i>';
}
if ((Cnum($_G['GET']['SORTID']) && $readdata['top']) || (!Cnum($_G['GET']['SORTID']) && InArray($_G['SET']['ACTIVETOPREADIDS'], $readdata['id']))) {
	$_G['TEMP']['HTHTML'] .= '<i class="_p_c-top" style="top:0px;left:0"></i>';
}
//用户组
if ($readuserdata['groupid']) {
	$usergroupdata = $_G['TABLE']['USERGROUP'] -> getData($readuserdata['groupid']);
	$_G['TEMP']['NICKNAME'] = $readuserdata['nickname'] . '<span class="_p_c_usergroupspan">' . $usergroupdata['usergroupname'] . '</span>';
} else {
	$_G['TEMP']['NICKNAME'] = $readuserdata['nickname'];
}
//管理
$a = adminEditTipbox('read', $readdata['id']);
$_G['TEMP']['ADMINHTML'] = '';
if ($a) {
	$_G['TEMP']['ADMINHTML'] = '<span onclick="adminEditTipbox(' . htmlspecialchars(json_encode($a), ENT_QUOTES) . ',{default:function(){location.reload()},del:function(){$(\'#listbox-' . $readdata['id'] . '\').remove()}});event.stopPropagation()"></span>';
}
//关注
if ($_G['USER']['ID'] == $readdata['uid']) {
	$_G['TEMP']['FOCUSHTML'] = '';
} elseif (strpos($_G['USER']['IDOL'], "_{$readdata['uid']}_") !== false) {
	$_G['TEMP']['FOCUSHTML'] = '<a class="_del _p_c-focususerbtn-' . $readdata['uid'] . '" href="javascript:" onclick="_p_c_focususer(' . $readdata['uid'] . ',\'del\');event.stopPropagation()">已关注</a>';
} else {
	$_G['TEMP']['FOCUSHTML'] = '<a class="_p_c-focususerbtn-' . $readdata['uid'] . '" href="javascript:" onclick="_p_c_focususer(' . $readdata['uid'] . ',\'add\');event.stopPropagation()">关注</a>';
}
//内容
$title = '<a href="' . ReWriteURL('read', "id={$readdata['id']}&page=1") . '" onclick="event.stopPropagation()" style="color:#111">' . strip_tags($readdata['title']) . '</a>';
$label = '';
if ($readdata['label']) {
	$labels = explode(',', $readdata['label']);
	foreach ($labels as $value) {
		$label .= '&nbsp;<a href="' . ReWriteURL('list', 'sortid=' . Cnum($_G['GET']['SORTID']) . '&page=1', 'label=' . $value) . '" onclick="event.stopPropagation()">#' . $value . '</a>';
	}
}
$maxwords = Cnum($_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_LISTMAXWORDS'], false, true, 1);
if ($maxwords) {
	$content = mb_substr(strip_tags($readdata['content']), 0, $maxwords, 'UTF-8');
	if ($content != strip_tags($readdata['content'])) {
		$content .= '...&nbsp;<span class="pk-text-primary">查看全文&raquo;</span>';
	}
} else {
	$content = '';
}
$_G['TEMP']['CONTENT'] = '<h2 style="font-size:15px;display:inline;letter-spacing:1px">' . $title . '</h2>' . $label . '<p style="margin-top:4px"><a href="' . ReWriteURL('read', "id={$readdata['id']}&page=1") . '" onclick="event.stopPropagation()" style="color:#333">' . $content . '</a></p>';

$_G['TEMP']['IMGS'] = '';
// 视频显示，当显示视频的时候，图片默认不显示
$showvideo = false;
if ($_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_LISTSHOWVIDEO']) {
	$videos = getHtmlVideos($readdata['content'], 1);
	if (count($videos)) {
		$_G['TEMP']['IMGS'] .= '<div class="pk-row" style="width:100%">
		<div class="pk-w-sm-12" style="padding:0;padding-bottom:15px">
			<video src="' . $videos[0]['src'] . '" controls="controls" style="width:100%;background-color:#000"></video>
		</div>
		</div>';
		$showvideo = true;
	}
}

//读取图片
$maximgs = Cnum($_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_LISTMAXIMGS'], false, true, 1);
if ($maximgs && !$showvideo) {
	$imgs = getHtmlImages($readdata['content'], $maximgs);
	switch (count($imgs)) {
		case 0:
			break;
		case 1:
			$_G['TEMP']['IMGS'] .= '<div style="width:66.66666%;height:268px">
			<img src="' . $imgs[0]['src'] . '" alt="' . htmlspecialchars(strip_tags($readdata['title']), ENT_QUOTES) . '" />
			</div>';
			$_G['TEMP']['IMGS'] .= '<div onclick="$(this).parents(\'._p_c_listbox\').click()"></div>';
			break;
		case 4:
			for ($i = 0; $i < 4; $i++) {
				if ($i == 2) {
					$_G['TEMP']['IMGS'] .= '<div onclick="$(this).parents(\'._p_c_listbox\').click()"></div>';
				}
				$_G['TEMP']['IMGS'] .= '<div><img src="' . $imgs[$i]['src'] . '" alt="' . htmlspecialchars(strip_tags($readdata['title']), ENT_QUOTES) . '" /></div>';
			}
			$_G['TEMP']['IMGS'] .= '<div onclick="$(this).parents(\'._p_c_listbox\').click()"></div>';
			break;
		default:
			foreach ($imgs as $value) {
				$_G['TEMP']['IMGS'] .= '<div><img src="' . $value['src'] . '" alt="' . htmlspecialchars(strip_tags($readdata['title']), ENT_QUOTES) . '" /></div>';
			}
			$a = abs(count($imgs) % 3 - 3);
			if ($a && $a < 3) {
				for ($i = 0; $i < $a; $i++) {
					$_G['TEMP']['IMGS'] .= '<div onclick="$(this).parents(\'._p_c_listbox\').click()"></div>';
				}
			}
			break;
	}
}
//时间
$lgtime = time() - Cnum($readdata['posttime']);
if ($lgtime < 60) {
	$lgtime = '刚刚';
} elseif ($lgtime < 3600) {
	$lgtime = (int)($lgtime / 60) . '分钟前';
} elseif ($lgtime < 86400) {
	$lgtime = (int)($lgtime / 3600) . '小时前';
} elseif ($lgtime < 86400 * 3) {
	$lgtime = (int)($lgtime / 86400) . '天前';
} else {
	$lgtime = date('Y-m-d', $readdata['posttime']);
}
$_G['TEMP']['DATETIME'] = $lgtime . '发布于“' . $readsortdata['title'] . '”';
