<?php
if (!defined('puyuetian'))
	exit('403');

global $forumdata;
if ($forumdata['url']) {
	$_G['TEMP']['TARGET'] = '_blank';
	$_G['TEMP']['FORUMURL'] = $forumdata['url'];
} else {
	$_G['TEMP']['TARGET'] = '';
	$_G['TEMP']['FORUMURL'] = ReWriteURL('list', 'sortid=' . $forumdata['id'] . '&page=1');
}
