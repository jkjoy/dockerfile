<?php
if (!defined('puyuetian'))
	exit('403');

global $replyuserdata, $replydata;
$_G['TEMP']['HTHTML2'] = '';
if ($replydata['top']) {
	$_G['TEMP']['HTHTML2'] .= '<i class="_p_c-top" style="top:0px;left:0"></i>';
}
//用户组
if ($replyuserdata['groupid']) {
	$usergroupdata = $_G['TABLE']['USERGROUP'] -> getData($replyuserdata['groupid']);
	$_G['TEMP']['NICKNAME'] = $replyuserdata['nickname'] . '<span class="_p_c_usergroupspan">' . $usergroupdata['usergroupname'] . '</span>';
} else {
	$_G['TEMP']['NICKNAME'] = $replyuserdata['nickname'];
}
//管理
$a = adminEditTipbox('reply', $replydata['id']);
$_G['TEMP']['ADMINHTML2'] = '';
if ($a) {
	$_G['TEMP']['ADMINHTML2'] = '<span onclick="adminEditTipbox(' . htmlspecialchars(json_encode($a), ENT_QUOTES) . ',{top:function(){location.reload()},del:function(){$(\'#replydivbox-' . $replydata['id'] . '\').remove()}})" class="fa fa-fw fa-gear"></span>';
}
