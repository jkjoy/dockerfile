<?php
if (!defined('puyuetian'))
	exit('403');

global $readdata, $readuserdata, $bkdata;
//精华或置顶
$_G['TEMP']['HTHTML'] = '';
if ($readdata['high']) {
	$_G['TEMP']['HTHTML'] .= '<i class="_p_c-high" style="top:0;right:108px"></i>';
}
if ($readdata['top']) {
	$_G['TEMP']['HTHTML'] .= '<i class="_p_c-top" style="top:0px;left:0"></i>';
}
//用户组
if ($readuserdata['groupid']) {
	$usergroupdata = $_G['TABLE']['USERGROUP'] -> getData($readuserdata['groupid']);
	$_G['TEMP']['NICKNAME'] = $readuserdata['nickname'] . '<span class="_p_c_usergroupspan">' . $usergroupdata['usergroupname'] . '</span>';
} else {
	$_G['TEMP']['NICKNAME'] = $readuserdata['nickname'];
}
//管理
$a = adminEditTipbox('read', $readdata['id']);
$_G['TEMP']['ADMINHTML'] = '';
if ($a) {
	$_G['TEMP']['ADMINHTML'] = '<span onclick="adminEditTipbox(' . htmlspecialchars(json_encode($a), ENT_QUOTES) . ',{default:function(){location.reload()},del:function(){$(\'#listbox-' . $readdata['id'] . '\').remove()}})"></span>';
}
//关注
if ($_G['USER']['ID'] == $readdata['uid']) {
	$_G['TEMP']['FOCUSHTML'] = '';
} elseif (strpos($_G['USER']['IDOL'], "_{$readdata['uid']}_") !== FALSE) {
	$_G['TEMP']['FOCUSHTML'] = '<a class="_del" href="javascript:" onclick="_p_c_focususer(' . $readdata['uid'] . ',\'del\',this)">已关注</a>';
} else {
	$_G['TEMP']['FOCUSHTML'] = '<a href="javascript:" onclick="_p_c_focususer(' . $readdata['uid'] . ',\'add\',this)">关注</a>';
}
//时间
$lgtime = time() - Cnum($readdata['posttime']);
if ($lgtime < 60) {
	$lgtime = '刚刚';
} elseif ($lgtime < 3600) {
	$lgtime = (int)($lgtime / 60) . '分钟前';
} elseif ($lgtime < 86400) {
	$lgtime = (int)($lgtime / 3600) . '小时前';
} elseif ($lgtime < 86400 * 3) {
	$lgtime = (int)($lgtime / 86400) . '天前';
} else {
	$lgtime = date('Y-m-d', $readdata['posttime']);
}
$_G['TEMP']['DATETIME'] = $lgtime . '发布于“' . $bkdata['title'] . '”';
