<?php
if (!defined('puyuetian'))
	exit('403');

//读取最新的图片
$a = json_decode($_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_HOMESLIDEDATA'], TRUE);
if (!$a) {
	$a = array();
	$hslc = Cnum($_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_HOMESLIDENUM'], 5, TRUE, 0);
	if ($hslc && $_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_HOMESHOWBKIDS']) {
		$sql = ' and (';
		$bks = explode(',', $_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_HOMESHOWBKIDS']);
		foreach ($bks as $value) {
			$sql .= '`sortid`=' . $value . ' or ';
		}
		$sql = substr($sql, 0, strlen($sql) - 4) . ')';
		$sliderdatas = $_G['TABLE']['READ'] -> getDatas(0, 100, "where `del`=false{$sql} order by `id` desc", FALSE, 'id,title,content');
		$i = 0;
		foreach ($sliderdatas as $sliderdata) {
			$imgs = getHtmlImages($sliderdata['content'], 1);
			if (!$imgs) {
				continue;
			}
			$i++;
			$a[] = array('src' => $imgs[0]['src'], 'href' => ReWriteURL('read', "id={$sliderdata['id']}&page=1"), 'title' => $sliderdata['title']);
			if ($i >= $hslc) {
				break;
			}
		}
	}
}
$_G['TEMP']['SWIPEDATA'] = htmlspecialchars(json_encode($a), ENT_QUOTES);

//显示版块
$h = '';
if ($_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_HOMESHOWBKIDS'] && Cnum($_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_HOMESHOWBKREADNUM'], FALSE, TRUE, 1)) {
	$a = explode(',', $_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_HOMESHOWBKIDS']);
	foreach ($a as $v) {
		$bd = $_G['TABLE']['READSORT'] -> getData(Cnum($v));
		if (!$bd) {
			continue;
		}
		$h .= '<div class="pk-row _bkbox"><div><span>' . $bd['title'] . '</span><a href="' . ReWriteURL('list', "sortid={$v}&page=1") . '"></a></div><ul>';
		$rds = $_G['TABLE']['READ'] -> getDatas(0, $_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_HOMESHOWBKREADNUM'], 'where sortid=' . $v . ' and del=0 order by id desc', FALSE, 'id,title,posttime');
		foreach ($rds as $v2) {
			$h .= '<li><a href="' . ReWriteURL('read', "id={$v2['id']}&page=1") . '">' . $v2['title'] . '</a><span>' . date('Y-m-d', $v2['posttime']) . '</span></li>';
		}
		$h .= '</ul></div>';
	}
}
$_G['TEMP']['BKBOX'] = $h;
if ($_G['TEMP']['SWIPEDATA'] == '[]' && !$_G['TEMP']['BKBOX']) {
	ExitGourl(ReWriteURL('list'));
}
