<?php
if (!defined('puyuetian'))
	exit('403');

global $forumdata;
$_G['TEMP']['FHTML'] = '';
if (Cnum($_G['GET']['SORTID'], FALSE, TRUE, 1) && $_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_SHOWCHILDFORUM']) {
	$datas = $_G['TABLE']['READSORT'] -> getDatas(0, 0, 'where `pid`=' . $_G['GET']['SORTID'] . ' order by rank asc');
	foreach ($datas as $v) {
		if ($v['url']) {
			$t = '_blank';
			$u = $v['url'];
		} else {
			$t = '';
			$u = ReWriteURL('list', 'sortid=' . $v['id'] . '&page=1');
		}
		$_G['TEMP']['FHTML'] .= '<a target="' . $t . '" href="' . $u . '" class="_p_c-forumbox"><img src="' . $v['logourl'] . '" alt="" onerror="this.src=\'template/puyuetian_copyweibo/img/forum_logo.png\';this.onerror=\'\'"><p>' . $v['title'] . '</p><p>' . $v['content'] . '</p></a>';
	}
}
if ($_G['TEMP']['FHTML']) {
	$_G['TEMP']['FHTML'] = '<div class="pk-row _p_c-bkzt" style="background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAABoUlEQVRYR+2VP1bCQBDG56OhFG/iDYQTiDfAG6Ra0gFddhviCfQIeALhBngSsQOKjG/ysgqYhN0kvFhAEZrdmd9+8+cDtfxDy/npCnCkgFIqAPBARH0pDTOviWix3++f4zje+JYrDMM+M0+Y+U7uAlgDmEVRtLSxfgCUUksA9wVJllrrgQ+AUmoKYJJ3h5lnxphpCiWfg8NfAILtdruQF4dhOGLmmIhuADxFUfTqApG9/J2IyuINRAkLkL6emR+NMYvDJBnECxG9aa2HLgBWzbJ4zLwyxvRTgPF4zPKvtf4zFUEQ9Lrd7qdL4tMzZfGYeWOMuW0NQMqjte7VKkGRct4lyMZvLrIAGO12u5VtwiRJ5gB6eU1YBGCb8Ey83ybMJqFwDG3DnNa4rHe8xtAGFiWIaHiwDz6YWRZRnLeIygAkpiiRJInsg3QRyWLrdDrT3EVUpcvPAbjErGVGV4B/r4CXG7o0zMXH0Bfi3CJydkPfxPZ8Y6u4LkDRfWc3bAPgyA2rAhTd83bDpgEquWHTEJXcsGmIi7thE8C13PAK0IQC39B7xjDdAao4AAAAAElFTkSuQmCC);background-position:10px center;background-size:16px 16px;background-repeat:no-repeat;padding-left:29px">“' . $forumdata['title'] . '”的子版块</div><div class="pk-row pk-margin-bottom-10">' . $_G['TEMP']['FHTML'] . '</div>';
}

if ($_G['SET']['TEMPLATE_PUYUETIAN_COPYWEIBO_SHOWLABEL']) {
	$_G['TEMP']['LABELSHTML'] = '<div class="pk-hadsky forumlabel">' . $_G['TEMP']['LABELSHTML'] . '</div>';
} else {
	$_G['TEMP']['LABELSHTML'] = '';
}
