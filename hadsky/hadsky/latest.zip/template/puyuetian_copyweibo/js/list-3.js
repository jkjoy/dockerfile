//自动加载文章
$(function() {
	var _divid = '_hs' + randomString(7);
	$('body').append('<div id="' + _divid + '" class="pk-hide"></div>');
	$('#loadmorereadlistbtn').click(function() {
		var This = $(this);
		if (This.hasClass('pk-active')) {
			return false;
		}
		var page = Cnum(This.data('page')) + 1;
		This.addClass('pk-active').html('<span class="fa fa-fw fa-spin fa-spinner"></span>正在加载...');
		$('#' + _divid).load('index.php?c=' + ($_URI['C'] || 'list') + '&type=' + ($_URI['TYPE'] || '') + '&sortid=' +
			Cnum($_URI['SORTID']) + '&label=' + ($_GET('label') || '') + '&page=' + page + ' #read-list>div',
			function(r, s, x) {
				if (s == "error") {
					ppp({
						type: 3,
						icon: 2,
						content: '加载出错'
					});
					This.removeClass('pk-active').html('查看更多');
				} else {
					var $html = $('#' + _divid).html();
					if ($($html).find('>div').length) {
						This.data('page', page).removeClass('pk-active').html('查看更多');
						$('#read-list').append($html);
						$('._p_c_listbox  ._imgs:not(._viewer_loaded)').each(function() {
							$(this).addClass('_viewer_loaded').on({
								click: function(e) {
									e.stopPropagation();
								}
							}).viewer(_viewerOption);
						});
					} else {
						This.html('已无更多内容').unbind();
					}
				}
				$('#' + _divid).html('');
			});
	});
	$(window).scroll(function() {
		var obj = $('#loadmorereadlistbtn');
		var xh = $(window).height() - (obj.height() + obj.offset().top - $(window).scrollTop());
		if (xh >= 0 && !obj.hasClass('pk-active')) {
			obj.click();
		}
	});
	//帖子标签展示
	//帖子标签驱动
	if ($('#forumlabel').length) {
		var $as = $('#forumlabel>a');
		var $i = 0;
		var $w = 0;
		for (var i = 0; i < $as.length; i++) {
			$w += $($as[i]).outerWidth() + 10;
			//当前选中的东西
			var $labels = decodeURIComponent($_GET('label') || '');
			if ($labels) {
				$labels = $labels.split(',');
				for (var ii = 0; ii < $labels.length; ii++) {
					if ($labels[ii] == $($as[i]).html() && $labels[ii]) {
						$($as[i]).addClass('pk-active');
					}
				}
			}
		}
		$('#forumlabel').outerWidth($w + 15);
		$('#forumlabel>a').click(function() {
			var $label = '';
			$(this).toggleClass('pk-active');
			var $url = location.href;
			var $as = $('#forumlabel>a');
			for (var i = 0; i < $as.length; i++) {
				if ($($as[i]).hasClass('pk-active')) {
					$label += ',' + $($as[i]).html();
				}
			}
			$label = $label.substr(1);
			//去除现有的label
			$url = $url.replace('&label=' + ($_GET('label') || ''), '');
			$url = $url.replace('?label=' + ($_GET('label') || ''), '');
			if ($url.indexOf('?') == -1) {
				$url = $url + '?label=' + encodeURIComponent($label);
			} else {
				$url = $url + '&label=' + encodeURIComponent($label);
			}
			ppp({
				type: 4,
				shade: 1,
				content: "正在加载..."
			});
			setTimeout(function() {
				location.href = $url;
			}, 1000);
		});
	}
	//列表图片高度处理
	var o = $('._p_c_listbox ._imgs>div');
	for (var i = 0; i < o.length; i++) {
		$(o[i]).height($(o[i]).width()).find('video').height($(o[i]).width());
	}
});
