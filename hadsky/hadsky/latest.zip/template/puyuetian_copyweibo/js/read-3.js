$(function() {
	//排序方式
	var t = $('._p_c-replyboxtitle a');
	var d = [{
		text: '默认',
		disable: typeof($_URI['ORDERFIELD']) == "undefined" && typeof($_URI['DESC']) == "undefined" ? true : false,
		onClick: function() {
			location.href = t.data('default') + '#replylist';
		}
	}, {
		text: '按热度',
		disable: $_URI['ORDERFIELD'] ? true : false,
		onClick: function() {
			location.href = t.data('hot') + '#replylist';
		}
	}, {
		text: '楼层正序',
		disable: !$_URI['ORDERFIELD'] && $_URI['DESC'] == "0" ? true : false,
		onClick: function() {
			location.href = t.data('zx') + '#replylist';
		}
	}, {
		text: '楼层倒序',
		disable: !$_URI['ORDERFIELD'] && $_URI['DESC'] == "1" ? true : false,
		onClick: function() {
			location.href = t.data('dx') + '#replylist';
		}
	}];
	for(var i = 0; i < d.length; i++) {
		if(d[i].disable) {
			t.append(' [' + d[i].text + ']');
		}
	}
	t.on('click', function() {
		iakit.actionsheet({
			options: d
		});
	});
	//自动加载文章
	var _divid = '_hs' + randomString(7);
	$('body').append('<div id="' + _divid + '" class="pk-hide"></div>');
	$('#loadmorereadlistbtn').click(function() {
		var This = $(this);
		if(This.hasClass('pk-active')) {
			return false;
		}
		var page = Cnum(This.data('page')) + 1;
		This.addClass('pk-active').html('<span class="fa fa-fw fa-spin fa-spinner"></span>正在加载...');
		$('#' + _divid).load('index.php?c=read&id=' + $_URI['ID'] + '&orderfield=' + ($_URI['ORDERFIELD'] || '') + '&desc=' + ($_URI['DESC'] || '') + '&page=' + page + ' #read-list>div', function(r, s, x) {
			if(s == "error") {
				ppp({
					type: 3,
					icon: 2,
					content: '加载出错'
				});
				This.removeClass('pk-active').html('查看更多');
			} else {
				var $html = $('#' + _divid).html();
				if($($html).find('>div').length) {
					This.data('page', page).removeClass('pk-active').html('查看更多');
					$('#read-list').append($html);
					$('._p_c-replybox  ._body:not(._viewer_loaded)').each(function() {
						$(this).addClass('_viewer_loaded').on({
							click: function(e) {
								e.stopPropagation();
							}
						}).viewer(_viewerOption);
					});
				} else {
					This.html('已无更多内容').unbind();
				}
			}
			$('#' + _divid).html('');
		});
	});
	$(window).scroll(function() {
		var obj = $('#loadmorereadlistbtn');
		var xh = $(window).height() - (obj.height() + obj.offset().top - $(window).scrollTop());
		if(xh >= 0 && !obj.hasClass('pk-active')) {
			obj.click();
		}
	});
	//发表评论相关
	//加载验证码
	if(_verifycodeOpen && !InArray($_USER['USERGROUPQUANXIAN'] || $_USER['QUANXIAN'], 'noverifycode')) {
		$('#_p_c_postrelybox ._verifycode').append('<div style="position:relative;margin-bottom:10px"><input name="verifycode" class="pk-textbox" placeholder="请输入验证码"><img src="index.php?c=app&a=verifycode:index&type=postreply" style="position:absolute;top:0;right:0;height:38px" onclick="this.src=\'index.php?c=app&a=verifycode:index&type=postreply&rnd=\'+randomString(7)"></div>');
	}
	$('#postreplysubmitbtn').click(function() {
		if(!trim(form_post.content.value)) {
			if(PytEditor.body) {
				PytEditor.body.focus();
			} else {
				form_post.content.focus();
			}
			return false;
		}
		form_post.content.value = form_post.content.value.replace(/\<div/g, '<p');
		form_post.content.value = form_post.content.value.replace(/\<\/div\>/g, '</p>');
		var pid = ppp({
			type: 4,
			content: "正在提交...",
			shade: 1
		});
		var formstring = FormDataPackaging('form[name="form_post"]:eq(0)');
		$.post($('form[name="form_post"]:eq(0)').attr('action'), formstring, function(data) {
			pkpopup.close(pid);
			if(data['state'] == 'ok') {
				ppp({
					type: 3,
					icon: 1,
					content: data['msg'],
					close: function() {
						location.href = "index.php?c=read&id=" + data['rid'] + "&page=1&cache=refresh&rnd=" + parseInt(Math.random() * 10000) + "#replylist";
					}
				});
			} else {
				$('form[name="form_post"] input[name="verifycode"]').val('');
				$('#_p_c_postrelybox ._verifycode img').click();
				ppp({
					icon: 2,
					content: data['msg'] || '未知错误'
				});
			}
		}, 'json');
	});
});