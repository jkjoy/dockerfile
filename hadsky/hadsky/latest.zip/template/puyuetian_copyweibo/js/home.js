$(function() {
	//幻灯片驱动
	var a = $('.swiper-container').data('data') || [];
	if(!a.length) {
		return false;
	}
	var h = '<div class="swiper-wrapper">';
	for(var i = 0; i < a.length; i++) {
		h += '<a class="swiper-slide" href="' + a[i].href + '"><img src="' + a[i].src + '" onerror="this.src=\'template/puyuetian_copyweibo/img/error-img.png\';this.onerror=\'\'" alt="Image"><p>' + a[i].title + '</p></a>';
	}
	h += '</div><div class="swiper-pagination"></div>';
	$('.swiper-container').removeClass('pk-hide').html(h);
	new Swiper('.swiper-container', {
		loop: true,
		autoplay: {
			delay: 5000,
			disableOnInteraction: false
		},
		pagination: {
			el: '.swiper-pagination'
		}
	});
});