function _p_c_focususer(uid, type, t) {
	if (!Cnum($_USER['ID'])) {
		ppp({
			type: 3,
			icon: 2,
			content: "请登录后再操作"
		});
		return false;
	}
	var _p = '';
	if (!t) {
		t = $('._p_c-focususerbtn-' + uid);
	} else {
		t = $(t);
		_p = ',this';
	}
	$.getJSON('index.php', {
		c: 'center',
		type: type + 'idol',
		uid: uid,
		chkcsrfval: $_USER['CHKCSRFVAL']
	}, function(data) {
		if (data['state'] == 'ok') {
			if (type == 'add') {
				t.addClass('_del').attr({
					onclick: '_p_c_focususer(' + uid + ',"del"' + _p + ');event.stopPropagation()'
				}).html('已关注');
				ppp({
					type: 3,
					icon: 1,
					content: "关注成功"
				});
			} else {
				t.removeClass('_del').attr({
					onclick: '_p_c_focususer(' + uid + ', "add"' + _p + ');event.stopPropagation()'
				}).html('关注');
				ppp({
					type: 3,
					icon: 1,
					content: "取关成功"
				});
			}
		} else {
			ppp({
				type: 3,
				icon: 2,
				content: data['datas']['msg']
			});
		}
	});
}

function _p_c_replybox(id, t) {
	var html = '<textarea class="pk-textarea" rows="2" style="resize:none"></textarea>';
	if (_verifycodeOpen && !InArray($_USER['USERGROUPQUANXIAN'] || $_USER['QUANXIAN'], 'noverifycode')) {
		html += '<div style="position:relative"><input class="pk-textbox" style="height:32px" placeholder="请输入验证码"><img src="index.php?c=app&a=verifycode:index&type=postreply" style="position:absolute;top:0;right:0;height:32px" onclick="this.src=\'index.php?c=app&a=verifycode:index&type=postreply&rnd=\'+randomString(7)"></div>';
	}
	ppp({
		type: 1,
		title: '评论',
		content: html,
		shade: 1,
		noclose: 1,
		submit: function(_id) {
			var content = $('#pkpopup_' + _id + ' .pk-popup-body textarea').val();
			var verifycode = $('#pkpopup_' + _id + ' .pk-popup-body input').val();
			$.post('index.php?c=post&type=reply&return=json', {
				rid: id,
				content: content,
				verifycode: verifycode,
				chkcsrfval: $_USER['CHKCSRFVAL']
			}, function(data) {
				if (data['state'] == 'ok') {
					pkpopup.close(_id);
					ppp({
						type: 3,
						icon: 1,
						content: '评论成功'
					});
					$(t).css({
						color: 'orangered'
					}).find('span._count').html(Cnum($(t).find('span._count').html()) + 1);
				} else {
					$('#pkpopup_' + _id + ' .pk-popup-body img').click();
					console.log(data);
					ppp({
						type: 3,
						icon: 2,
						content: data['msg']
					});
				}
			}, 'json');
		},
		complete: function(_id) {
			$('#pkpopup_' + _id + ' .pk-popup-submit').html('评论');
		}
	});
}

function _p_c_zanread(id, type, t) {
	$.getJSON('index.php', {
		c: 'ding',
		type: type,
		id: id,
		json: 1,
		chkcsrfval: $_USER['CHKCSRFVAL']
	}, function(data) {
		if (data['state'] == 'ok') {
			$(t).css({
				color: 'orangered'
			}).attr({
				onclick: 'event.stopPropagation()'
			});
			$(t).find('span._count').html(Cnum($(t).find('span._count').html()) + 1);
		} else {
			$(t).attr({
				onclick: 'event.stopPropagation()'
			});
			ppp({
				type: 3,
				icon: 2,
				content: "已经赞过啦~"
			});
		}
	});
}

$(function() {
	//加载顶部导航
	var dh = eval($('._p_c_nav ul').data('data')) || [];
	var h = '';
	for (var i = 0; i < dh.length; i++) {
		h += '<li><a' + (dh[i]['open'] ? ' target="_blank"' : '') + ' href="' + dh[i]['href'] + '">' + dh[i]['title'] + '</a></li>';

	}
	$('._p_c_nav ul').append(h);
	//导航滑动
	var _obj = $('._p_c_nav ul>li'),
		_zw = 0;
	for (var i = 0; i < _obj.length; i++) {
		if (location.href == $(_obj[i]).find('a')[0].href) {
			$(_obj[i]).find('a').addClass('pk-active');
		}
		_zw += $(_obj[i]).outerWidth();
	}
	$('._p_c_nav ul').width(Math.ceil(_zw) + 2);
	//头部导航按钮
	$('._p_c_nav>div:eq(0) a').on('click', function() {
		var type = $(this).data('type');
		if (type == 'more') {
			var data = eval($(this).data('data')) || [];
			iakit.actionsheet({
				options: data
			});
			return false;
		}
		if (type == 'focus') {
			if (!Cnum($_USER['ID'])) {
				ppp({
					type: 3,
					icon: 0,
					content: "请先登录"
				});
				return false;
			}
			location.href = 'index.php?c=focus';
			return false;
		}
		if (type == 'post') {
			if (!Cnum($_USER['ID'])) {
				ppp({
					type: 3,
					icon: 0,
					content: "请先登录"
				});
				return false;
			}
			location.href = 'index.php?c=edit&type=read&sortid=' + Cnum($_URI['SORTID']);
			return false;
		}
		if (type == 'search') {
			var o = $('._p_c_searchbox');
			o.removeClass('pk-hide').find('input[name="w"]').focus();
			if (/micromessenger/i.test(navigator.userAgent)) {
				var _tmp_xy;
				o.find('input').on({
					focus: function() {
						clearTimeout(_tmp_xy);
						o.css('padding-top', '44px');
						_tmp_xy = setTimeout(function() {
							o.css('padding-top', 0);
						}, 3500);
					}
				});
			}
			return false;
		}
	});
	//导航自动隐藏
	(function() {
		var h = $('._p_c_nav').height();
		var windowTop = 0,
			active = true;
		$(window).scroll(function() {
			var scrolls = $(this).scrollTop();
			if (scrolls < h) {
				$('._p_c_nav').removeClass('_pk-auto-hide').css({
					height: h
				});
			}
			if (!active && scrolls > h) {
				windowTop = scrolls;
				return;
			}
			if (scrolls >= windowTop && scrolls > h) {
				if (!$('._p_c_nav').hasClass('_pk-auto-hide')) {
					$('._p_c_nav').addClass('_pk-auto-hide').animate({
						height: 0
					}, 500);
				}
			} else {
				if ($('._p_c_nav').hasClass('_pk-auto-hide')) {
					$('._p_c_nav').removeClass('_pk-auto-hide').animate({
						height: h
					}, 500);
				}
			}
			windowTop = scrolls;
			active = false;
			setTimeout(function() {
				active = true;
			}, 1000);
		});
	})();
	//搜索历史
	var searchHistoryWords = getCookie('_p_c_searchwords') || '';
	var a = searchHistoryWords.split(','),
		h = '';
	var w = ($('._p_c_searchbox>ul').data('data') || '').split(',');
	for (var i = 0; i < w.length; i++) {
		if (w[i]) {
			h += '<li><a href="javascript:" style="color:red">' + w[i] + '</a></li>';
		}
	}
	for (var i = 0; i < a.length; i++) {
		if (a[i]) {
			h += '<li><a href="javascript:">' + a[i] + '</a><i></i></li>';
		}
	}
	$('._p_c_searchbox>ul').append(h);
	$('._p_c_searchbox form').on('submit', function() {
		var v = $(this).find('[name="w"]').val();
		v = v.replace(/,/, '，').replace(/\</, '&lt;').replace(/\>/, '&gt;');
		if (!InArray(searchHistoryWords, v)) {
			searchHistoryWords += ',' + v;
			if (searchHistoryWords.substr(0, 1) == ',') {
				searchHistoryWords = searchHistoryWords.substr(1);
			}
			setCookie('_p_c_searchwords', searchHistoryWords);
		}
	});
	$('._p_c_searchbox>ul li a').on('click', function() {
		var v = $(this).text();
		$('._p_c_searchbox input[name="w"]').val(v);
		$('._p_c_searchbox form').submit();
	});
	$('._p_c_searchbox>ul li i').on('click', function() {
		var a = searchHistoryWords.split(',');
		var v = $(this).parent().find('a').text();
		var h = '';
		for (var i = 0; i < a.length; i++) {
			if (a[i] != v) {
				h += ',' + v;
			}
		}
		if (h) {
			h = h.substr(1);
		}
		searchHistoryWords = h;
		$(this).parent().remove();
		setCookie('_p_c_searchwords', searchHistoryWords);
	});
	//图片点击预览
	if (InArray('read,focus,list', $_URI['C']) || !$_URI['C']) {
		$('._p_c_listbox,._p_c-replybox').find(((InArray('list,focus', $_URI['C']) || !$_URI['C']) ? '._imgs' : '._body') + ':not(._viewer_loaded)').each(function() {
			$(this).addClass('_viewer_loaded').on({
				click: function(e) {
					e.stopPropagation();
				}
			}).viewer(_viewerOption);
		});
	}
	//底部导航初始化
	var _bottomNavdata = eval($('._p_c-toolbar').data('data')) || [];
	var _bl = _bottomNavdata.length;
	if (_bl) {
		for (var i = 0; i < _bl; i++) {
			var d = _bottomNavdata[i];
			$('._p_c-toolbar ul').append('<li><a href="' + (d.href || 'javascript:') + '">' + d.title + '</a></li>').find('li:last').css({
				width: (100 / _bl) + '%'
			}).find('a').css({
				backgroundImage: d.icon ? 'url("' + d.icon + '")' : 'none',
				color: d.color || '#000'
			}).data('data', d).on('click', function() {
				var d = $(this).data('data');
				switch (typeof(d.click)) {
					case "function":
						d.click();
						break;
					case "string":
						eval(d.click);
						break;
				}
				if (typeof(d.actionsheet) == "object") {
					iakit.actionsheet({
						options: d.actionsheet
					});
				}
			});
			var o = $('._p_c-toolbar ul li:last a');
			if (o[0].href == location.href) {
				o.css({
					backgroundImage: d.icon2 ? 'url("' + d.icon2 + '")' : 'none',
					color: d.color2 || '#000'
				});
			}
		}
		$('._p_c-toolbar,._p_c-toolbar2').removeClass('pk-hide');
	}
});
