$(function() {
	var other_login_i = setInterval(function() {
		if ($('#hadsky-loginbox-other').html()) {
			if (!$('#di3fangyundenglu').html() && $('#hadsky-loginbox-other>div').length === 1) {
				return false;
			}
			$('.logintext div[data-id="hadsky-loginbox-other"]').removeClass('pk-hide');
			clearInterval(other_login_i);
		}
	}, 200);
	setTimeout(function() {
		clearInterval(other_login_i);
	}, 9000);
	$('.logintext>div').on('click', function() {
		$(this).siblings().removeClass('pk-active');
		$(this).addClass('pk-active');
		$('#hadsky-loginbox,#hadsky-loginbox-other').addClass('pk-hide');
		$('#' + $(this).data('id')).removeClass('pk-hide');
	});

	$('#hadsky-loginbox input').keydown(function(e) {
		if (e.keyCode == 13) {
			$('#loginbtn').click();
		}
	});

	$('#loginbtn').on('click', function() {
		if (!$('#hadsky-loginbox input[name="username"]').val()) {
			ppp({
				type: 3,
				content: '请输入用户名',
				icon: 0,
				close: function() {
					$('#hadsky-loginbox input[name="username"]').focus();
				}
			});
			return false;
		}

		if (!$('#hadsky-loginbox input[name="password"]').val()) {
			ppp({
				type: 3,
				content: '请输入密码',
				icon: 0,
				close: function() {
					$('#hadsky-loginbox input[name="password"]').focus();
				}
			});
			return false;
		}

		$(this).prop('disabled', true).html('登录中...');
		//数据打包
		if (Cnum(form_login.enpw.value)) {
			form_login.code.value = randomString(32);
			$(form_login.password).attr({
				maxLength: 32
			}).val(md5(md5(form_login.password.value) + form_login.code.value));
		}
		var loginapiurl = $('form[name="form_login"]:eq(0)').attr('action'),
			formstring = FormDataPackaging('form[name="form_login"]:eq(0)');
		$.post(loginapiurl, formstring, function(data) {
			if (data['state'] != 'ok') {
				$('form[name="form_login"] input[name="password"]').val('');
				$('form[name="form_login"] input[name="verifycode"]').val('');
				$('#verifycodeimageobject').click();
				ppp({
					content: (data['msg'] || '未知错误'),
					icon: 2,
					close: function() {
						$('#loginbtn').prop('disabled', false).html('登录');
					}
				});
				return false;
			}
			ppp({
				type: 4,
				content: '登录成功，正在跳转...'
			});
			location.href = (data['referer'] || 'index.php');
		}, 'json');
	});
});
