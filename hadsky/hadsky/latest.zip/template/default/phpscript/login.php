<?php
if (!defined('puyuetian')) {
	exit('403');
}

$_G['TEMPLATE']['HEAD'] = 'null';
$_G['TEMPLATE']['FOOT'] = 'null';
$_G['TEMPLATE']['BODY'] = 'output';
