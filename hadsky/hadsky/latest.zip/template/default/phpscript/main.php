<?php
if (!defined('puyuetian')) {
    exit('403');
}

if ($_G['SET']['GLOBALCDN'] && !('app' == $_G['GET']['C'] && InArray('superadmin:index,superadmin', $_GET['a']))) {
    $cdn = '<link href="https://cdn.staticfile.net/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
		<script src="https://cdn.staticfile.net/jquery/3.3.1/jquery.min.js"></script>
		<!--[if lt IE 9]>
			<script src="https://cdn.staticfile.net/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
		';
} else {
    $cdn = '<link rel="stylesheet" href="template/puyuetianUI/css/font-awesome.min.css" />
		<script src="template/puyuetianUI/js/jquery-3.3.1.min.js"></script>
		<!--[if lt IE 9]>
			<script src="template/puyuetianUI/js/respond.js"></script>
		<![endif]-->
		';
}
$cdn .= '<link href="template/puyuetianUI/v8/css/puyuetian.css" rel="stylesheet" />
		<link href="template/puyuetianUI/css/puyuetian.css" rel="stylesheet" />
		<script src="template/puyuetianUI/js/puyuetian.js"></script>
		<script src="template/puyuetianUI/v8/js/puyuetian.js"></script>
		<script>K.uploadURL = "index.php?c=upload";</script>
		';
$_G['SET']['EMBED_HEADMARKS'] = $cdn . $_G['SET']['EMBED_HEADMARKS'];
