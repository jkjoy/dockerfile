function ReplyReplyNF(me) {
    me = $(me);
    var uid = parseInt(me.data('uid')) || 0,
        nn = me.data('username');
    me.parents('.reply-reply-box').find('.reply-reply-textbar a.reply').data({
        content: uid ? '@' + uid + ':[' + nn + ']&nbsp;' : ''
    }).trigger('click');
}
function ReplyReplyDel(me) {
    me = $(me);
    var id = parseInt(me.data('id'));
    ppp({
        type: 1,
        title: '提示',
        content: '确认删除该回复[ID:' + id + ']吗？',
        submit: function () {
            $.getJSON('index.php', {
                c: 'replyreply',
                type: 'del',
                id: id
            }, function (rd) {
                if (!rd['code']) {
                    ppp({
                        icon: 2,
                        content: rd['msg']
                    });
                    return false;
                }
                ppp({
                    type: 3,
                    icon: 1,
                    content: '删除成功'
                });
                me.parents('div.reply-reply').remove();
            });
        }
    });
}
$(function () {
    // 楼中楼
    var loadReplylist = function (datas, div, prepend) {
        var h = '';
        for (var i = 0; i < datas.length; i++) {
            var url = parseInt($_SET['REWRITEURL']) ? 'center-' + datas[i]['uid'] + '.html' : 'index.php?c=center&uid=' + datas[i]['uid'];
            h += [
                '<div class="reply-reply">',
                '<div class="reply-reply-head"><a target="_blank" href="',
                url,
                '">',
                '<img src="',
                datas[i]['user']['userhead'],
                '" onerror="this.src=\'userhead/0.png\';this.onerror=\'\'"><span>',
                datas[i]['user']['username'],
                '</span></a>',
                datas[i]['usergroup'] && datas[i]['usergroup']['usergroupname'] ? '&nbsp;<span class="pk-text-danger">' + datas[i]['usergroup']['usergroupname'] + '</span>' : '',
                datas[i]['user']['title'] ? '&nbsp;<span class="pk-text-primary">' + datas[i]['user']['title'] + '</span>' : '',
                '</div>',
                '<div class="reply-reply-body">',
                datas[i]['content'],
                '</div>',
                '<div class="reply-reply-foot">',
                datas[i]['datetime'],
                (datas[i]['uid'] == $_USER['ID'] || datas[i]['noreply']) ? '' : '<a class="pk-float-right" href="javascript:;" onclick="ReplyReplyNF(this)" data-uid="' + datas[i]['uid'] + '" data-username="' + datas[i]['user']['username'] + '" style="margin-left:7px">回复</a>',
                datas[i]['del'] ? '<a class="pk-float-right" href="javascript:;" onclick="ReplyReplyDel(this)" data-id="' + datas[i]['id'] + '">删除</a>' : '',
                '</div>',
                '</div>'
            ].join('');
        }
        if (!prepend) {
            div.append(h);
        } else {
            div.prepend(h);
        }
        div.find('.reply-reply-body img[alt!="emotion"]').addClass('pk-cursor-pointer').attr({
            onclick: 'LookImage(this)'
        });
    };
    $('.reply-reply-box .reply-reply-textbar a.show').on('click', function () {
        var me = $(this),
            p = me.parent(),
            page = me.data('page');
        if (page == 1) {
            p.find('span,a:eq(0)').hide().end().append('<span><i class="fa fa-fw fa-spinner fa-spin"></i>正在加载...</span>');
        } else {
            p.next().next().find('span,a').toggleClass('pk-hide');
        }
        $.getJSON('index.php', {
            c: 'replyreply',
            rid: me.data('rid'),
            page: page,
            type: 'get',
            limit: 10
        }, function (rd) {
            if (!rd['code']) {
                return false;
            }
            if (page == 1) {
                p.next().after([
                    '<div class="reply-reply-more">',
                    '<a href="javascript:;">加载更多</a>',
                    '<span class="pk-hide"><i class="fa fa-fw fa-spinner fa-spin"></i>正在加载...</span>',
                    '</div>'
                ].join('')).end().find('span:eq(0)').show().end().find('span:eq(1)').hide().end().next().next().find('a').on('click', function () {
                    me.data('page', me.data('page') + 1);
                    me.trigger('click');
                });
            }
            var list = rd['data']['list'];
            if (list.length) {
                if (page != 1) {
                    p.next().next().find('span,a').toggleClass('pk-hide');
                }
                loadReplylist(rd['data']['list'], p.next());
            } else {
                p.next().next().html('已无更多回复');
            }
        });
    });

    $('.reply-reply-box .reply-reply-textbar a.reply').on('click', function () {
        var me = $(this),
            content = me.data('content') || '';
        me.data('content', '');
        $('body').append([
            '<div class="reply-reply-postbox-bg"></div>',
            '<div class="pk-hadsky reply-reply-postbox">',
            '<div class="reply-reply-postbox-head-navbar pk-text-truncate pk-hide-md">',
            '<img class="back" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAATFJREFUSEutlqtSA0EQRU8s0Wg0Hh3NRwSNBglI8Fhi4R9Ao/FoPiJo6lTNVDWbnWzvo12qUuf27bk9syvm1xlwA/wCd13caiZf+D2wLpxH4Dsy5whsgG2AfwIvSzkQfh1gH8Br3zSmOLgCLgPMru2+t8YK2LXdWx6qXTfh/ikrcFJGchHgHujPUEgyAsIfABNTO0/BMw6EOpYKt2PhjidVxxx0Mz4afszBednOukC9Gc9Y6HNwCjwNLVAG3nKgwHMAvANvWWB2k826C2WCrEVHVJvwkI1nFfkqd006QdmYRpHRSZqyaIp4/wxuccZBHVd3m/claYMiGQcxGPGyU2QHeDbNGisgKIr4e9HrunbafXC8tn10DmqKg5bIok9ma1f8qvh38HMcRJFbwEM/+Gz5A1syOhllftjmAAAAAElFTkSuQmCC" alt="" onclick="$(\'.reply-reply-postbox-bg\').trigger(\'click\')" />',
            '<span class="title">回复评论</span>',
            '</div>',
            '<i class="fa fa-times-circle-o v8-hide-sm" onclick="$(\'.reply-reply-postbox-bg\').trigger(\'click\')"></i>',
            '<form id="replyreplyform" method="post" action="index.php?c=post&type=reply_reply&return=json">',
            '<input type="hidden" name="rid" value="',
            me.data('rid'),
            '" />',
            '<div class="pk-row pk-margin-bottom-15 pk-hide-sm">',
            '<div class="pk-w-sm-12 pk-padding-0">',
            '<p class="pk-text-truncate">',
            '<span>回复：</span>',
            '<span>',
            me.data('fnum'),
            '#</span>',
            '</p>',
            '</div>',
            '</div>',
            '<div class="pk-row pk-margin-bottom-15">',
            '<div class="pk-w-sm-12 pk-padding-0">',
            '<div class="reply-reply-editbox-loadtext" style="height:360px">',
            '<i class="fa fa-fw fa-spinner fa-spin"></i>编辑器加载中...</div>',
            '<input type="hidden" id="replyreplycontent" name="content">',
            '<iframe id="replyreplyiframe" src="index.php?c=replyreply&content=',
            encodeURIComponent(content),
            '" style="height:360px;border:none;width:100%"></iframe>',
            '</div>',
            '</div>',
            '<input type="hidden" id="replyreplyverifycode" name="verifycode">',
            '<div class="pk-row pk-margin-bottom-15">',
            '<div class="pk-w-sm-12 pk-padding-0">',
            '<button id="postreplyreplysubmitbtn" type="button" class="pk-btn">',
            '<span>回复</span>',
            '</button>',
            '</div>',
            '</div>',
            '</form>',
            '</div>'
        ].join(''));
        $('.reply-reply-postbox-bg').on('click', function () {
            $('.reply-reply-postbox,.reply-reply-postbox-bg').remove();
        });
        $('#postreplyreplysubmitbtn').on('click', function () {
            var form = $('#replyreplyform'),
                url = form.attr('action'),
                data = FormDataPackaging(form),
                content = trim($('#replyreplyform').find('[name="content"]').val());
            if (!content) {
                ppp({
                    icon: 0,
                    type: 3,
                    content: '请输入回复内容'
                });
                return false;
            }
            $(this).prop('disabled', true).find('span').html('回复中...');
            $.post(url, data, function (rd) {
                $('#postreplyreplysubmitbtn').prop('disabled', false).find('span').html('回复评论');
                if (rd['state'] != 'ok') {
                    $("#replyreplyiframe", parent.document).contents().find('#verifycodeimageobject').trigger('click').end().find('[name="verifycode"]').val('').focus();
                    ppp({
                        icon: 2,
                        type: 0,
                        content: rd['msg']
                    });
                    return false;
                }
                ppp({
                    icon: 1,
                    type: 3,
                    content: rd['msg']
                });
                $('.reply-reply-postbox-bg').trigger('click');
                loadReplylist([{
                    id: 0,
                    uid: $_USER['ID'],
                    user: {
                        userhead: 'userhead/' + $_USER['ID'] + '.png',
                        username: '我'
                    },
                    content: content,
                    datetime: '刚刚'
                }], $('.reply-reply-list[data-rid="' + me.data('rid') + '"]'), 1);
            }, 'json');
        });
    });
});