$(function () {
    // 整理位置
    (function () {
        var top = $('.pk-searchbox-bg').offset().top,
            bottom = $('body').outerHeight() - $('.pk-searchbox-bg').outerHeight() - top;
        $('.pk-searchbox-bg').height($(window).height() - top - bottom);
        $('.searchloading').remove();
    })();
    // 搜索热词
    var hotwords = $('#searchHotWords').data('hotwords') || '';
    if (hotwords) {
        hotwords = hotwords.split(',');
        var o = $('#searchHotWords'),
            url = '',
            w = '';
        for (var i = 0; i < hotwords.length; i++) {
            w = hotwords[i];
            if (parseInt($_SET['REWRITEURL'])) {
                url = 'search-' + encodeURIComponent(w) + '-1.html';
            } else {
                url = 'index.php?c=app&a=puyuetian_search&w=' + encodeURIComponent(w);
            }
            o.append([
                '<a class="pk-text-primary pk-hover-underline" href="' + url + '">' + w + '</a>',
                '&nbsp;&nbsp;'
            ].join(''));
        }
        o.removeClass('pk-hide');
    }
    $('#searchBtn').on('click', function () {
        if (!$('#searchTxt').val()) {
            $('#searchTxt').focus();
            return false;
        }
        app_puyuetian_search($('#searchTxt'));
    });
    $('#searchTxt').on('keydown', function (e) {
        if (e.keyCode == 13) {
            $('#searchBtn').click();
        }
    });
});