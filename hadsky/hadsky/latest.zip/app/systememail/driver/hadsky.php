<?php
if (!defined('puyuetian')) {
	exit('403');
}

function sendmail($mailto, $mailtitle, $mailcontent, $timeout = false)
{
	global $_G;
	if (!filter_var($mailto, FILTER_VALIDATE_EMAIL)) {
		return false;
	}
	$timeout = Cnum($_G['SET']['APP_SYSTEMEMAIL_TIMEOUTSECONDS'], 10, true, 1, 60);
	$nickname = strip_tags($_G['SET']['APP_SYSTEMEMAIL_NAME']);
	if (!$nickname) {
		$nickname = $_G['SYSTEM']['DOMAIN'];
	}
	$_apiurl = "https://api.hadsky.com/zz/v3/sendemail?domain={$_G['SYSTEM']['DOMAIN']}&sitekey=" . md5($_G['SET']['APP_HADSKYCLOUDSERVER_SITEKEY'] . $_G['SYSTEM']['DOMAIN']);
	$_data = 'email=' . urlencode($mailto);
	$_data .= '&title=' . urlencode($mailtitle);
	$_data .= '&content=' . urlencode($mailcontent);
	$_data .= '&nickname=' . urlencode($nickname);
	$r = json_decode(GetPostData($_apiurl, $_data, $timeout), true);
	if ($r['state'] != 'ok') {
		if ($_G['SET']['APP_SYSTEMEMAIL_DEBUG']) {
			NewMessage(1, '<b>[云邮件]</b>' . ($r['msg'] ? $r['msg'] : "请求失败:{$_apiurl}"), 0, 2);
		}
		return false;
	}
	return true;
}
