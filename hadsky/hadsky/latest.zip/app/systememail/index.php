<?php
if (!defined('puyuetian')) {
    exit('403');
}

if (user('id') != 1) {
    v8Error('403');
}

if (input('get.submit/d')) {
    $emails  = input('post.email/s');
    $title   = input('post.title/s');
    $content = input('post.content/s');

    if (!$emails) {
        v8Error('发送地址不能为空');
    }
    if (!$title) {
        $title = '测试发信标题';
    }
    if (!$content) {
        $content = '测试发信内容';
    }
    $emails = explode(',', $emails);

    $err = '';
    foreach ($emails as $email) {
        if (!sendmail($email, $title, $content, 5)) {
            $err .= $email . ',';
        }
    }
    $err = trim($err, ',');

    $txt = '发送完成';
    if ($err) {
        $txt .= '<p class="pk-text-xs">发送失败：' . $err . '</p>';
    }
    v8Success($txt);
}

g('template.head', 'null');
g('template.foot', 'null');
g('template.body', 'systememail:index');
