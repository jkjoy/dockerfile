<?php
if (!defined('puyuetian')) {
    exit('403');
}

if (input('get.c/s') == 'login') {
    //写入忘记密码按钮
    setConcat('embed_foot', template('systememail:load', true));
}

if (aSet('systememail', 'driver') == 'hadsky') {
    require PK_APP_PATH . 'systememail/driver/hadsky.php';
} else {
    require PK_APP_PATH . 'systememail/driver/default.php';
}

//新用户邮箱验证
if (aSet('systememail', 'emailverify') && (input('get.c/s') != 'login' && !(input('get.c/s') == 'app' && input('get.a/s' == 'systememail:emailverify')))) {
    if (!user('id') && input('get.c/s') == 'savereg') {
        //添加验证码
        $regarray['data'] = JsonData($regarray['data'], 'systememail_emailverify', CreateRandomString(7));
    }
    $emailverify = JsonData(user('data'), 'systememail_emailverify');
    if (user('id') && user('email') && $emailverify) {
        $sendtime = Cnum(JsonData(user('data'), 'systememail_emailverify_sendtime'), 0, true, 0);
        if (time() - $sendtime > 60) {
            sendmail(user('email'), '邮箱验证码-' . set('logotext'), '您的验证码为：<span style="color:#f60;font-weight:bold">' . $emailverify . '</span>');
            table('user')->update([
                'id'   => user('id'),
                'data' => JsonData(user('data'), 'systememail_emailverify_sendtime', time()),
            ]);
        }
        $_G['TEMP']['SVF'] = md5($_G['SET']['KEY'] . $emailverify);
        $_G['HTMLCODE']['MAIN'] .= template('systememail:emailverify', true);
        template($_G['TEMPLATE']['MAIN']);
        exit();
    }
}
