var PytConfig;
//全部加载
PytConfig = 'Html,Bold,Italic,Underline,Emotion,Image';