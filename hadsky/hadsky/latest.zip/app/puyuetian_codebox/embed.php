<?php
if (!defined('puyuetian')) {
    exit('403');
}

if ('read' == $_G['GET']['C']) {
    $_G['SET']['EMBED_FOOT'] .= template('puyuetian_codebox:embed', 1);
}
