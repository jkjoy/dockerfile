function _puyuetian_copytext(options) {
    options = options || '';
    if (typeof (options) == "string" || typeof (options) == "number") {
        options['text'] = options;
    }
    if (typeof (options.text) != "string" && typeof (options.text) != "number") {
        if (typeof (options.error) == "function") {
            options.error('复制对象仅限文本内容');
        }
        return false;
    }
    options['text'] = options.text.toString();
    try {
        navigator.clipboard.writeText(options.text).then(function () {
            if (typeof (options.success) == "function") {
                options.success(options.text);
            }
        });
    } catch {
        try {
            var a = $('<textarea></textarea>').css({
                width: 0,
                height: 0
            }).val(options.text);
            $('body').append(a);
            a.select();
            var r = document.execCommand('copy');
            a.remove();
            if (!r) {
                if (typeof (options.error) == "function") {
                    options.error('复制失败');
                }
                return false;
            }
            if (typeof (options.success) == "function") {
                options.success(options.text);
            }
        } catch {
            if (typeof (options.error) == "function") {
                options.error('复制失败');
            }
            return false;
        }
    }
    return true;
}

function _puyuetian_codebox(options) {
    options = options || {
        selector: 'code,pre'
    };
    if (typeof (options) == "string") {
        options = $(options);
    }
    options['selector'] = options.selector || options;
    options['theme'] = options.theme || '';
    options['edit'] = options.edit || false;
    if (typeof (options.copy) == "undefined") {
        options['copy'] = 1;
    }
    var o = $(options.selector);
    if (!o.length) {
        return false;
    }
    for (var i = 0; i < o.length; i++) {
        var o2 = $(o[i]),
            code = o2.text(),
            codes = code.split(/\n/g),
            length = codes.length;
        length = length.toString();
        length = length.length;
        if (options.edit) {
            length = 5;
        }
        var width = length * 10 + 20,
            id = 'pkcodebox_' + i;
        $('head').append([
            '<style>#',
            id,
            '.pk-code>ul>li::before{width:',
            width,
            'px}</style>'
        ].join(''));
        o2.after([
            '<div id="',
            id,
            '" class="pk-code ',
            options.edit ? '' : options.theme,
            '"><ul style="padding-left:',
            width,
            'px" ',
            options.edit ? 'contenteditable="true"' : '',
            '></ul>',
            options.copy ? '<span>复制</span>' : '',
            '</div>'
        ].join('')).remove();
        var o3 = $('#' + id);
        for (var j = 0; j < codes.length; j++) {
            o3.find('>ul').append('<li></li>').find('li:last').text(codes[j] || ' ');
        }
        options.copy && o3.find('>span').data({
            code
        }).on('click', function () {
            var me = $(this);
            _puyuetian_copytext({
                text: me.data('code'),
                success: function () {
                    me.html('√复制成功');
                },
                error: function () {
                    me.html('×复制失败');
                }
            });
            setTimeout(function () {
                me.html('复制');
            }, 2000);
        });
    }
    options.edit && options.copy && setInterval(function () {
        var a = $('.pk-code').find('>ul[contenteditable="true"]');
        for (var i = 0; i < a.length; i++) {
            var o = $(a[i]);
            if (!o.find('>li').length) {
                o.html('<li></li>');
            }
            var os = o.parent().find('>span');
            if (!os.length) {
                continue;
            }
            var code = '',
                b = o.find('>li');
            for (var j = 0; j < b.length; j++) {
                code += $(b[j]).text() + "\n";
            }
            if (os.data('code') != code) {
                os.data('code', code);
            }
        }
    }, 200);
}