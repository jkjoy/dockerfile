<?php
if (!defined('puyuetian')) {
    exit('403');
}

if ('refresh' == $_G['GET']['DO']) {
    $path  = $_G['SYSTEM']['PATH'] . '/cache/html/';
    $files = scandir($path);
    foreach ($files as $file) {
        $file = $path . $file;
        if (is_file($file)) {
            unlink($file);
        }
    }
    $r = true;
} elseif ('php_refresh' == $_G['GET']['DO']) {
    $path  = $_G['SYSTEM']['PATH'] . '/cache/php/';
    $files = scandir($path);
    foreach ($files as $file) {
        $file = $path . $file;
        if (is_file($file)) {
            unlink($file);
        }
    }
    $r = true;
} elseif ('mysql_refresh' == $_G['GET']['DO']) {
    // mysql_query("truncate `{$_G['MYSQL']['PREFIX']}cache`");
    $path  = $_G['SYSTEM']['PATH'] . '/cache/sql/';
    $files = scandir($path);
    foreach ($files as $file) {
        $file = $path . $file;
        if (is_file($file)) {
            unlink($file);
        }
    }
    $r = true;
} elseif ('getcachesize' == $_G['GET']['DO']) {
    ExitJson(formatBytes(dirSize(PK_CACHE_PATH . $_G['GET']['TYPE'])), true);
} else {
    //保存数据库缓存
    //mysql_query("update `{$_G['MYSQL']['PREFIX']}set` `setvalue`='" . mysqlstr($_POST['mysqlcachecycle'], FALSE) . "' where `setname`='mysqlcachecycle'");
    //mysql_query("update `{$_G['MYSQL']['PREFIX']}set` `setvalue`='" . mysqlstr($_POST['mysqlcachetables'], FALSE) . "' where `setname`='mysqlcachetables'");
    //保存文件缓存
    $value = "<?php
define('HADSKY_CACHELIFE', " . Cnum($_POST['cachelife']) . ");
define('HADSKY_CACHEPAGES', '" . Cstr(strtolower($_POST['cachepages']), 'home,forum,list,read', $_G['STRING']['LOWERCASE'] . ',', 1, 255) . "');
define('HADSKY_CACHEREFRESH', " . Cnum($_POST['cacherefresh']) . ");
";
    $r = file_put_contents($_G['SYSTEM']['PATH'] . 'puyuetian/cache/config.php', $value);
    //保存访问控制设置
    file_put_contents($_G['SYSTEM']['PATH'] . 'puyuetian/access.php', str_replace('define("HADSKY_ACCESS", ' . HADSKY_ACCESS . ');', 'define("HADSKY_ACCESS", ' . Cnum($_POST['access_open'], 0, true, 0, 1) . ');', file_get_contents($_G['SYSTEM']['PATH'] . 'puyuetian/access.php')));
    file_put_contents($_G['SYSTEM']['PATH'] . 'puyuetian/access.php', str_replace('define("HADSKY_ACCESS_MAXFILESIZE", ' . HADSKY_ACCESS_MAXFILESIZE . ');', 'define("HADSKY_ACCESS_MAXFILESIZE", ' . Cnum($_POST['access_maxfilesize'], 0, true, 0) . ');', file_get_contents($_G['SYSTEM']['PATH'] . 'puyuetian/access.php')));
}
if ($_G['GET']['JSON']) {
    $r = $r ? '操作成功' : '操作失败';
    ExitJson($r, true);
} else {
    header("Location:index.php?c=app&a=superadmin:index&s=home&t=cache&pkalert=show&alert=" . urlencode('操作成功！') . "&rnd={$_G['RND']}");
}
exit();
