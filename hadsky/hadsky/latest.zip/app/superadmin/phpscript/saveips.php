<?php
if (!defined('puyuetian')) {
	exit('403');
}

if (InArray($_POST['ips'], $_G['SYSTEM']['CLIENTIP'])) {
	ExitJson('不能把自己IP设置进去');
}

if (file_put_contents($_G['SYSTEM']['PATH'] . 'puyuetian/ips/config.hst', $_POST['ips']) === false) {
	ExitJson('保存失败');
}

ExitJson('保存成功', true);
