<?php
if (!defined('puyuetian')) {
    exit('403');
}

$path = sys('path') . 'puyuetian/redis/config.php';

if (input('get.submit/s') == 'save') {
    $open    = input('post.open/d');
    $host    = input('post.host/s');
    $pass    = input('post.pass/s');
    $pass    = str_replace('\'', '\\\'', $pass);
    $port    = input('post.port/d');
    $dbno    = input('post.dbno/d');
    $timeout = input('post.timeout/d');
    $expire  = input('post.expire/d');
    $prefix  = input('post.prefix/s');
    $prefix  = str_replace('\'', '\\\'', $prefix);
    $tables  = input('post.tables/s');

    if ($open) {
        $redis = new KRedis(input('post.'));
        if (!$redis->connect()) {
            v8Error($redis->error());
        }
    }

    $content = "<?php
    if (!defined('puyuetian')) {
        exit('403');
    }

    g([
        'redis' => [
            'open'    => {$open},
            'host'    => '{$host}',
            'pass'    => '{$pass}',
            'port'    => {$port},
            'dbno'    => {$dbno},
            'timeout' => {$timeout},
            'expire'  => {$expire},
            'prefix'  => '{$prefix}',
            'tables'  => '{$tables}'
        ],
    ]);
";
    if (file_put_contents($path, $content) === false) {
        v8Error('配置文件保存失败');
    }
    v8Success('保存成功');
}

if (InArray('getinfo,del', input('get.submit/s'))) {
    if (!g('redis.open')) {
        v8Error('请先开启该功能');
    }
    $redis = new KRedis();
    if (!$redis->connect()) {
        v8Error($redis->error());
    }
    if (input('get.submit/s') == 'del') {
        if (input('get.type/s') == 'hs') {
            $redis->del();
        } else {
            $redis->flushAll();
        }
        $info = true;
    } else {
        // 获取使用情况
        $redis             = $redis->redis();
        $info              = $redis->info();
        $info['key_count'] = count($redis->keys('*'));
        $info['dbno']      = g('redis.dbno');
    }
    $redis->close();
    v8Success('ok', $info);
}

// 读取表列表
$tables = table()->table_names();
// 系统表信息
$tn = [
    'set'                                      => '设置表',
    'user'                                     => '用户表',
    'read'                                     => '文章表',
    'reply'                                    => '回复表',
    'reply_reply'                              => '楼中楼表',
    'app_hadskycloudserver_cloudpay_record'    => '云支付记录表',
    'app_hadskycloudserver_weixinlogin_record' => '云微信登录记录表',
    'app_puyuetian_sms_record'                 => '云短信发送记录表',
    'audit'                                    => '贴子审核表',
    'cycle'                                    => '回收站表',
    'jtrecord'                                 => '积分变动记录表',
    'readsort'                                 => '版块表',
    'user_message'                             => '用户消息表',
    'upload'                                   => '附件上传表',
    'usergroup'                                => '用户组表',
    'download_record'                          => '附件下载表',
];
foreach ($tn as $k => $v) {
    $tn[$k] = "<span class=pk-text-primary>{$v}</span>";
}
// 插件表信息
$apps   = scandir(PK_APP_PATH);
$app_tn = [];
foreach ($apps as $app) {
    $config = PK_APP_PATH . $app . '/config.json';
    if (!is_file($config)) {
        continue;
    }
    $config               = json_decode(file_get_contents($config), true);
    $app_tn["app_{$app}"] = $config['title'] . '插件表';
}
// 模板表信息
$apps  = scandir(PK_TEMPLATE_PATH);
$tl_tn = [];
foreach ($apps as $app) {
    $config = PK_TEMPLATE_PATH . $app . '/config.json';
    if (!is_file($config)) {
        continue;
    }
    $config                   = json_decode(file_get_contents($config), true);
    $tl_tn["template_{$app}"] = $config['title'] . '模板表';
}
$tns  = array_merge($tn, $app_tn, $tl_tn);
$data = [];
foreach ($tables as $table) {
    $show = false;
    $at   = (strpos($table, 'app_') === 0 || strpos($table, 'template_') === 0);
    foreach ($tns as $tn => $title) {
        if (!($at && strpos($table, $tn) === 0) && $table != $tn) {
            continue;
        }
        $n++;
        $show   = true;
        $data[] = [
            "title" => '<span style="white-space:nowrap;max-width:100%;overflow:hidden" title="' . $table . '">' . $title . '</span>',
            "value" => $table,
        ];
    }
    if (!$show) {
        $data[] = [
            "title" => $table,
            "value" => $table,
        ];
    }
}
// 重复数据整理
foreach ($data as $i => $v) {
    $n = 1;
    for ($j = $i + 1; $j < count($data); $j++) {
        if (strip_tags($v['title']) == strip_tags($data[$j]['title'])) {
            $n++;
            $data[$j]['title'] .= "<sup style='font-weight:bold;color:red;position:absolute;top:3px;margin-left:3px' title='包含多张表，请用鼠标悬浮至名称处查看表名'>{$n}</sup>";
        }
    }
}
g('temp.data', $data);

$contenthtml = template('superadmin:redis-' . $_G['GET']['T'], true);
