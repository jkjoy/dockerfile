<?php
if (!defined('puyuetian')) {
    exit('403');
}

if (input('get.do/s') == 'get') {
    $page  = cnum(input('get.page/d'), 1, true, 1);
    $limit = input('get.limit/d');
    $data  = [];
    $datas = table('audit')->where('tn', input('get.type/s'))->page($page, $limit)->order('id', 'asc')->select();
    $count = table('audit')->where('tn', input('get.type/s'))->count();
    foreach ($datas as $v) {
        $d             = json_decode($v['data'], true);
        $d['username'] = table('user')->where($d['uid'])->find('username');
        $d['id']       = $v['id'];
        if (input('get.type/s') == 'reply_reply') {
            $reply       = table('reply')->where($d['rid'])->find();
            $d['readid'] = $reply['rid'];
            $d['replyf'] = $reply['fnum'];
        }
        $data[] = $d;
    }
    v8Success('ok', [
        'list'  => $data,
        'count' => $count,
    ]);
}
if (input('get.do/s') == 'pass') {
    restoreCycle(input('get.ids/s'), 'audit');
    v8Success('ok');
}
if (input('get.do/s') == 'delete') {
    table('audit')->where('id', 'IN', input('get.ids/s'))->delete();
    v8Success('ok');
}
