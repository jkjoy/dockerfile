<?php
if (!defined('puyuetian')) {
    exit('403');
}

if (input('get.do/s') == 'clearphp') {
    unDir(PK_CACHE_PATH . 'php', false);
    success('ok');
}
$_G['TEMP']['TOTAL_CACHE']    = formatBytes(dirSize(PK_CACHE_PATH . 'php'));
$_G['TEMP']['TOTAL_USER']     = $_G['TABLE']['USER']->getCount();
$_G['TEMP']['TOTAL_READ']     = $_G['TABLE']['READ']->getCount();
$_G['TEMP']['TOTAL_REPLY']    = $_G['TABLE']['REPLY']->getCount() + $_G['TABLE']['REPLY_REPLY']->getCount();
$_G['TEMP']['SH_READ']        = $_G['TABLE']['AUDIT']->getCount(array('tn' => 'read'));
$_G['TEMP']['SH_REPLY']       = $_G['TABLE']['AUDIT']->getCount(array('tn' => 'reply'));
$_G['TEMP']['SH_REPLY_REPLY'] = $_G['TABLE']['AUDIT']->getCount(array('tn' => 'reply_reply'));
$_G['TEMP']['TOTAL_UPLOAD']   = $_G['TABLE']['UPLOAD']->getCount();
$_G['TEMP']['TOTAL_BK']       = $_G['TABLE']['READSORT']->getCount();
$_G['SET']['TODAY_READ']      = $_G['TABLE']['READ']->getCount('where `posttime`>' . strtotime(date('Y-m-d 00:00:00', time())));
$_G['SET']['TODAY_REPLY']     = $_G['TABLE']['REPLY']->getCount('where `posttime`>' . strtotime(date('Y-m-d 00:00:00', time())));
$_G['SET']['TODAY_USER']      = $_G['TABLE']['USER']->getCount('where `regtime`>' . strtotime(date('Y-m-d 00:00:00', time())));
$_G['SET']['TODAY_UPLOAD']    = $_G['TABLE']['UPLOAD']->getCount('where `uploadtime`>' . strtotime(date('Y-m-d 00:00:00', time())));

$_G['TEMP']['PHP_VERSION'] = PHP_VERSION;
//PHP版本检测
if (PHP_VERSION_ID >= 70000) {
    //true
    $_G['TEMP']['PHP_VERSION'] = PHP_VERSION;
} else {
    //false
    $_G['TEMP']['PHP_VERSION'] = PHP_VERSION . "<span class='pk-text-warning fa fa-fw fa-exclamation-circle pk-cursor-pointer' title='HS7系列产品基于php7.0开发且不再保证对php5.x版本完全兼容，建议您升级php至7.0或着更高。'></span>";
}
//magic_quotes_gpc()函数关闭
if (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc()) {
    //true
    $_G['TEMP']['MAGIC_QUOTES_GPC'] .= "magic_quotes_gpc()函数未关闭<span class='pk-text-danger fa fa-fw fa-close pk-cursor-pointer' title='HS建议关闭该函数，否则部分功能或插件将无法正常运行'></span><a target='_blank' class='pk-hover-underline pk-text-primary' href='http://www.hadsky.com/read-1320-1.html'>magic_quotes_gpc()函数关闭方法</a>";
} else {
    //false
    $_G['TEMP']['MAGIC_QUOTES_GPC'] .= "<span class='pk-text-success fa fa-fw fa-check-circle-o'></span>正常";
}
switch ($_G['SQL']['TYPE']) {
    case 'sqlite':
        $_G['TEMP']['SQLV'] = 'SQLite ' . sqlQuery('SELECT sqlite_version()', 1);
        break;

    default:
        $_G['TEMP']['SQLV'] = 'MySQL ' . sqlQuery('select VERSION()', 1);
        break;
}
//==========================获取本地插件/模板信息======================================
$a                           = getAT('app');
$b                           = getAT('template');
$c                           = array_merge($a, $b);
$_G['TEMP']['APPCOUNT']      = count($a);
$_G['TEMP']['TEMPLATECOUNT'] = count($b);
$_G['TEMP']['PLUGDATA']      = htmlspecialchars(json_encode($c), ENT_QUOTES);
