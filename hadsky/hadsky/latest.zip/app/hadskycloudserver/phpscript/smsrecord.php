<?php
if (!defined('puyuetian')) {
    exit('403');
}

if (user('id') != 1 && !InArray(set('app_superadmin_adminuids'), user('id'))) {
    v8error('无权操作');
}
$page  = Cnum(input('get.page/d'), 1, true, 1);
$limit = Cnum(input('get.limit/d'), 100, true, 1);
$datas = table('app_puyuetian_sms_record')->page($page, $limit)->order('id desc')->select();
v8success('ok', [
    'list'  => $datas,
    'count' => table('app_puyuetian_sms_record')->count(),
]);
