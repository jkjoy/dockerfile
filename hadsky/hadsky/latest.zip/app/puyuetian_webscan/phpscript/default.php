<?php
if (!defined('puyuetian'))
	exit('403');

if ($_G['USER']['ID'] != 1) {
	PkPopup('{title:"提示",content:"仅创始人可以使用该插件",icon:0,close:function(){location.href="index.php"},hideclose:true,shade:true}');
}

$_G['TEMP']['DANGERCODES'] = 'system|passthru|shell_exec|exec|popen|proc_open|eval|assert|call_user_func|base64_decode|gzinflate|gzuncompress|gzdecode|str_rot13|file_get_contents|file_put_contents|fputs|fwrite';

$_G['TEMP']['FILES'] = array();
$_G['TEMP']['FILES_COUNT'] = 0;
function _scanFile($path) {
	global $_G;
	$files = scandir($path);
	foreach ($files as $file) {
		if ($file != '.' && $file != '..') {
			if (is_dir($path . '/' . $file)) {
				_scanFile($path . '/' . $file);
			} else {
				if (end(explode('.', $file)) == 'php') {
					$_G['TEMP']['FILES_COUNT']++;
					$_G['TEMP']['FILES'][] = iconv('GB2312//IGNORE', 'UTF-8', $path . '/' . $file);
				}
			}
		}
	}
}

switch ($_G['GET']['CMD']) {
	case '' :
		break;
	case 'getfiles' :
		_scanFile(str_replace('\\', '/', substr($_G['SYSTEM']['PATH'], 0, strlen($_G['SYSTEM']['PATH']) - 1)));
		//print_r($_G['TEMP']['FILES']);
		ExitJson(array('count' => $_G['TEMP']['FILES_COUNT'], 'files' => $_G['TEMP']['FILES']), TRUE);
		break;
	case 'startscan' :
		$files = json_decode($_POST['files'], TRUE);
		if (!$files) {
			ExitJson('数据异常');
		}
		$_files = array();
		$i = 0;
		foreach ($files as $file) {
			if (end(explode('.', $file)) == 'php') {
				$str = file_get_contents($file);
				if (preg_match_all("/({$_G['TEMP']['DANGERCODES']})[ \r\n\t]{0,}([\[\(])/i", $str, $out)) {
					//print_r($out);
					$i++;
					$_files[] = iconv('GB2312//IGNORE', 'UTF-8', $file);
				}
			}
		}
		ExitJson(array('count' => $i, 'files' => $_files), TRUE);
		break;
	case 'cloudscan' :
		$files = json_decode($_POST['files'], TRUE);
		if (!$files) {
			ExitJson('数据异常');
		}
		$_files = array();
		foreach ($files as $file) {
			if (end(explode('.', $file)) == 'php') {
				$_files[] = array('path' => substr($file, strlen($_G['SYSTEM']['PATH'])), 'md5' => md5(str_replace(array(" ", "\t", "\r", "\n", "\r\n"), '', php_strip_whitespace($file))));
			}
		}
		$json_text = GetPostData("http://www.hadsky.com/index.php?c=app&a=zhanzhang:index6&s=cloudscan&domain={$_G['SYSTEM']['DOMAIN']}&sitekey=" . md5($_G['SET']['APP_HADSKYCLOUDSERVER_SITEKEY']) . "&rnd={$_G['RND']}", 'files=' . urlencode(json_encode($_files)), 5);
		$json = json_decode($json_text, true);
		if (!$json) {
			ExitJson('云检测失败：未获取到数据');
		}
		if ($json['state'] != 'ok') {
			//ExitJson(array('count' => 1, 'files' => array('H:/WWW/hadsky3/app/puyuetian_qiniucloud/upok.php')), TRUE);
			ExitJson($json['datas']['msg']);
		}
		ExitJson($json['datas'], TRUE);
		break;
	default :
		ExitJson('错误的操作指令');
		break;
}

$_G['SET']['WEBTITLE'] = '网站木马扫描器（HadSky专用版）';
$_G['HTMLCODE']['OUTPUT'] .= template('puyuetian_webscan:default', TRUE);
