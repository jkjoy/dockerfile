function _getHM() {
	var mydate = new Date();
	var h = mydate.getHours();
	if(h < 10) {
		h = '0' + h;
	}
	var m = mydate.getMinutes();
	if(m < 10) {
		m = '0' + m;
	}
	return h + ':' + m;
}

function _sb(text, bwei) {
	$('#statusbox>div:eq(0)').append('<p class="pk-text-nowrap">' + (bwei ? '<i style="color:transparent">' + _getHM() + '</i>' : _getHM()) + ' ' + text + '<p>');
}

function _Init() {
	$.getJSON('index.php?c=app&a=puyuetian_webscan&cmd=getfiles', function(data) {
		if(data['state'] != 'ok') {
			_sb('初始化失败！');
			_complete(true);
			return false;
		}
		//获取待扫描文件
		_sb('待扫描文件列表：');
		var files = JSON.stringify(data['datas']['files']);
		for(var i in data['datas']['files']) {
			_sb(data['datas']['files'][i], true);
		}
		//开始扫描
		_sb('共' + data['datas']['count'] + '个文件，正在扫描...');
		$("#statusbox").scrollTop($("#statusbox>div:eq(0)").height());
		$.post('index.php?c=app&a=puyuetian_webscan&cmd=startscan', {
			files: files
		}, function(_data) {
			if(_data['state'] != 'ok') {
				_sb('文件扫描出错！');
				_complete(true);
				return false;
			}
			//获取可疑文件
			_sb('待云检测文件列表：');
			var _files = JSON.stringify(_data['datas']['files']);
			for(var i in _data['datas']['files']) {
				_sb(_data['datas']['files'][i], true);
			}
			//云检测
			_sb('共' + _data['datas']['count'] + '个文件，正在进行云检测...');
			$("#statusbox").scrollTop($("#statusbox>div:eq(0)").height());
			$.post('index.php?c=app&a=puyuetian_webscan&cmd=cloudscan', {
				files: _files
			}, function(__data) {
				if(__data['state'] != 'ok') {
					_sb(__data['datas']['msg'] || '云检测扫描出错！');
					_complete(true);
					return false;
				}
				//获取云检测可疑文件
				//console.log(__data);
				if(__data['datas']['count'] > 0) {
					_sb('可疑文件列表：');
					for(var i in __data['datas']['files']) {
						_sb(__data['datas']['files'][i] + '&nbsp;&nbsp;&nbsp;<a target="_blank" class="pk-text-secondary pk-hover-underline" href="index.php?c=app&a=filesmanager:index&type=edit&path=' + encodeURIComponent(__data['datas']['files'][i]) + '#workarea">编辑</a>', true);
					}
					_sb('扫描完成，共发现<b style="color:red">' + __data['datas']['count'] + '个</b>可疑文件，请自行排查风险，参考方法：<a target="_blank" class="pk-text-success pk-hover-underline" href="//www.hadsky.com/read-3577-1.html">http://www.hadsky.com/read-3577-1.html</a>。');
				} else {
					_sb('<b style="color:green">扫描完成，您的网站没有发现木马。</b>');
				}
				_complete();
			}, 'json');
		}, 'json');
	});
}

function _complete(t) {
	if(t) {
		_sb('<b style="color:red">扫描被意外终止。</b>');
		_sb('错误参考地址：<a class="pk-text-success pk-hover-underline" target="_blank" href="//www.hadsky.com/read-3576-1.html">http://www.hadsky.com/read-3576-1.html</a>');
	}
	$("#statusbox").scrollTop($("#statusbox>div:eq(0)").height());
	$('#startscanbtn').parent().removeClass('pk-hide').next().addClass('pk-hide');
}

$(function() {
	var sb = $('#statusbox>div:eq(0)');
	_sb('准备就绪...');
	$('#startscanbtn').on('click', function() {
		$(this).parent().addClass('pk-hide').next().removeClass('pk-hide');
		_sb('正在初始化...');
		_Init();
		$("#statusbox").scrollTop($("#statusbox>div:eq(0)").height());
	});
	$('.statusbar>span:eq(0)').on('click', function() {
		if($('#startscanbtn').parent().hasClass('pk-hide')) {
			ppp({
				title: "提示",
				type: 1,
				content: "将会终止扫描，确认退出？",
				submit: function(id) {
					window.close();
				}
			});
		} else {
			window.close();
		}
	});
});