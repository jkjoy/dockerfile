DROP TABLE IF EXISTS `pk_app_hadskycloudserver_cloudpay_record`;
CREATE TABLE `pk_app_hadskycloudserver_cloudpay_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hs_id` bigint(20) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `rmb` int(11) NOT NULL DEFAULT '0',
  `tiandou` int(11) NOT NULL DEFAULT '0',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `finishtime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
DROP TABLE IF EXISTS `pk_app_hadskycloudserver_weixinlogin_record`;
CREATE TABLE `pk_app_hadskycloudserver_weixinlogin_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `idcode` varchar(255) NOT NULL DEFAULT '',
  `regtime` int(11) NOT NULL DEFAULT '0',
  `logtime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
DROP TABLE IF EXISTS `pk_app_puyuetian_sms_record`;
CREATE TABLE `pk_app_puyuetian_sms_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pn` varchar(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` int(8) NOT NULL,
  `state` varchar(255) NOT NULL DEFAULT 'no',
  `msg` text,
  `datetime` datetime NOT NULL,
  `code` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
DROP TABLE IF EXISTS `pk_audit`;
CREATE TABLE `pk_audit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tn` varchar(255) NOT NULL DEFAULT '' COMMENT '表名称',
  `data` longtext NOT NULL COMMENT '数据',
  `time` bigint(20) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
DROP TABLE IF EXISTS `pk_cycle`;
CREATE TABLE `pk_cycle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tn` varchar(255) NOT NULL DEFAULT '' COMMENT '表名称',
  `data` longtext NOT NULL COMMENT '数据',
  `time` bigint(20) NOT NULL DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
DROP TABLE IF EXISTS `pk_download_record`;
CREATE TABLE `pk_download_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `downloadid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `tiandou` int(11) NOT NULL DEFAULT '0',
  `datetime` bigint(20) NOT NULL DEFAULT '20000101000000',
  `leixing` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
DROP TABLE IF EXISTS `pk_jtrecord`;
CREATE TABLE `pk_jtrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户id',
  `jifen` int(11) NOT NULL DEFAULT '0' COMMENT '积分变动量',
  `tiandou` int(11) NOT NULL DEFAULT '0' COMMENT '天豆变动量',
  `content` text COMMENT '变动说明',
  `time` bigint(20) NOT NULL DEFAULT '0' COMMENT '变动时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
DROP TABLE IF EXISTS `pk_read`;
CREATE TABLE `pk_read` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章的id',
  `sortid` int(11) NOT NULL DEFAULT '0' COMMENT '文章所属版块id',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发布人uid',
  `title` text NOT NULL COMMENT '文章标题',
  `content` longtext NOT NULL COMMENT '文章内容',
  `looknum` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `zannum` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '被赞次数',
  `posttime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发布时间',
  `readlevel` int(11) NOT NULL DEFAULT '0' COMMENT '文章阅读权限',
  `replyuid` int(11) unsigned NOT NULL DEFAULT '2' COMMENT '最后回复人uid',
  `replycontent` text COMMENT '最新回复内容',
  `replytime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后回复时间',
  `replyip` varchar(255) DEFAULT NULL COMMENT '最后回复人的ip',
  `postip` varchar(255) DEFAULT NULL COMMENT '发布人的ip',
  `top` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文章置顶',
  `high` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文章精华',
  `locked` tinyint(3) NOT NULL DEFAULT '0',
  `replyafterlook` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '回复后可见',
  `lookonlyme` int(11) NOT NULL DEFAULT '0',
  `data` longtext COMMENT '文章其他数据',
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1为删除，0为正常',
  `activetime` int(11) NOT NULL DEFAULT '0' COMMENT '最后活动时间',
  `replyid` int(11) NOT NULL DEFAULT '0' COMMENT '回复的id',
  `fs` int(11) NOT NULL DEFAULT '1' COMMENT '回复的楼层数',
  `label` text COMMENT '标签',
  `jvhuo_gid` int(11) NOT NULL DEFAULT '0',
  `lastedituid` int(11) NOT NULL DEFAULT '0',
  `lastedittime` int(11) NOT NULL DEFAULT '0',
  `image` text COMMENT '文章图片',
  `video` text COMMENT '文章视频',
  `audio` text COMMENT '文章音频',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT COMMENT='文章表';
DROP TABLE IF EXISTS `pk_readsort`;
CREATE TABLE `pk_readsort` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '版块的id',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属父版块的id',
  `rank` int(11) NOT NULL DEFAULT '0' COMMENT '版块排序，从小到大',
  `title` text NOT NULL COMMENT '版块名称',
  `content` text COMMENT '版块说明',
  `url` text COMMENT '点击分类跳转的url',
  `logourl` text COMMENT '版块logo图片地址',
  `postlevel` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户发帖需要的阅读权限',
  `replylevel` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户回复需要的阅读权限',
  `adminuids` text COMMENT '管理员uid',
  `looklevel` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户看帖需要的阅读权限',
  `show` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1:显示 0:隐藏',
  `showchildlist` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否显示想下级版块文章',
  `label` text COMMENT '标签',
  `banpostread` int(11) NOT NULL DEFAULT '0' COMMENT '该板块是否允许发帖',
  `allowgroupids` text COMMENT '允许进入的用户组',
  `postreadjifen` int(11) NOT NULL DEFAULT '0' COMMENT '发文章奖励积分数',
  `postreadtiandou` int(11) NOT NULL DEFAULT '0' COMMENT '发文章奖励天豆数',
  `postreplyjifen` int(11) NOT NULL DEFAULT '0' COMMENT '发回复奖励积分数',
  `postreplytiandou` int(11) NOT NULL DEFAULT '0' COMMENT '发回复奖励天豆数',
  `webtitle` text,
  `webkeywords` text,
  `webdescription` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT COMMENT='版块分类表';
INSERT INTO `pk_readsort` VALUES (1,0,0,'新版块','','','',0,0,'',0,1,0,'原创,爆料',0,NULL,0,0,0,0,NULL,NULL,NULL),(2,1,0,'子版块','','','',0,0,'',0,1,0,'',0,'',0,0,0,0,'','','');DROP TABLE IF EXISTS `pk_reply`;
CREATE TABLE `pk_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '回复的id',
  `rid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '回复的文章id',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '回复人uid',
  `content` text NOT NULL COMMENT '回复内容',
  `posttime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '回复时间',
  `postip` varchar(255) DEFAULT NULL COMMENT '发布人的ip',
  `zannum` int(11) NOT NULL DEFAULT '0' COMMENT '赞数',
  `top` tinyint(3) NOT NULL DEFAULT '0' COMMENT '置顶',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1删除，0正常',
  `fnum` int(11) NOT NULL DEFAULT '0' COMMENT '当前回复的楼层数',
  `data` longtext,
  `replycount` int(11) NOT NULL DEFAULT '0' COMMENT '楼中楼回复数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='回复表';
DROP TABLE IF EXISTS `pk_reply_reply`;
CREATE TABLE `pk_reply_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL DEFAULT '0' COMMENT '回复的id',
  `uid` bigint(20) NOT NULL DEFAULT '0' COMMENT '发布楼中楼的用户id',
  `content` text COMMENT '回复内容',
  `posttime` bigint(20) NOT NULL DEFAULT '0' COMMENT '回复时间',
  `postip` varchar(255) NOT NULL DEFAULT '' COMMENT '回复ip',
  `del` int(11) NOT NULL DEFAULT '0' COMMENT '已弃用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
DROP TABLE IF EXISTS `pk_set`;
CREATE TABLE `pk_set` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '基本设置id',
  `setname` varchar(200) NOT NULL DEFAULT '' COMMENT '变量名称',
  `setvalue` text COMMENT '变量值',
  `noload` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `setname` (`setname`)
) ENGINE=MyISAM AUTO_INCREMENT=328 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT COMMENT='系统设置表';
INSERT INTO `pk_set` VALUES (2,'bbcodemarks','<b><i><u><strong><font><pre><code><p><span><table><thead><tbody><tfoot><tr><td><th><a><em><h1><h2><h3><h4><h5><h6><img><label><ul><ol><li><br><audio><embed><video>',0),(3,'footerhtmlcode','<a target=\"_blank\" href=\"https://www.hadsky.com\" class=\"\" onclick=\"\">HadSky轻论坛</a>\n\n\t\t\t',0),(4,'headerhtmlcode','<a href=\"javascript:;\" class=\"\" target=\"\" onclick=\"app_puyuetian_traditional_jfxz()\">简/繁体中文 </a><a target=\"_blank\" href=\"https://www.hadsky.com\" class=\"\" onclick=\"\">官方论坛</a>',0),(5,'quotes','支持原创软件，抵制盗版，共创美好明天！',0),(6,'templatename','puyuetian_changable',0),(7,'webdescription','',0),(8,'webkeywords','',0),(9,'weblogo','template/default/img/logo.png',0),(10,'webname','有天轻论坛',0),(11,'reg','1',0),(12,'reguserquanxian','bbcode,login,lookuser,postreply,uploadfile,uploadhead,search,postread,lookread,download',0),(13,'readlistnum','10',0),(14,'replylistnum','10',0),(15,'logotext','HadSky',0),(16,'qiandaojifen','10',0),(17,'qiandaotiandou','10',0),(18,'readsort','',0),(19,'navhtmlcode','<li><a href=\"index.php?c=home\">首页</a></li>\n<li><a href=\"index.php?c=list\">动态</a></li>\n<li><a href=\"index.php?c=forum\">版块</a></li>\n\n\n\n',0),(20,'uploadfiletypes','jpg|jpeg|gif|bmp|png|zip|rar|txt|doc|apk|pdf|webp|ico|docx|mp3|mp4',0),(21,'uploadfilesize','50000',0),(22,'postreadjifen','5',0),(23,'postreadtiandou','5',0),(24,'postreplyjifen','2',0),(25,'postreplytiandou','2',0),(27,'defaultpage','list',0),(29,'rewriteurl','0',0),(30,'downloadfilernd','258',0),(31,'openverifycode','0',0),(32,'phonetemplatename','puyuetian_copyweibo',0),(33,'regmessage','恭喜您注册成功！',0),(44,'jifenname','经验',0),(45,'tiandouname','金钱',0),(46,'regjifen','0',0),(47,'regtiandou','0',0),(48,'friendlinks','<a target=\"_blank\" href=\"https://www.hadsky.com\" class=\"\" onclick=\"\">HadSky轻论坛</a>',0),(49,'postingtimeinterval','30',0),(50,'postaudit','0',0),(51,'newuserpostwaittime','0',0),(52,'beianhao','',0),(53,'bbcodeattrs','class,style,href,target,src,width,height,title,alt,border,align,valign,color,size,controls,autoplay,loop,type,face,id,lang,cellpadding,cellspacing,poster',0),(54,'readtitlemin','1',0),(55,'readtitlemax','1250',0),(56,'readcontentmin','1',0),(57,'readcontentmax','999999',0),(58,'replycontentmin','1',0),(59,'replycontentmax','999999',0),(60,'replyorder','1',0),(61,'readtopnum','3',0),(62,'webtitle','无标题',0),(63,'template_default_headhtml','',0),(64,'template_default_banner','<div class=\"pk-padding-top-30 pk-padding-bottom-30\"><a title=\"HadSky轻论坛\" href=\"/\"><img src=\"template/default/img/logo.png\" alt=\"HadSky\"></a></div>',0),(65,'template_default_searchrighthtml','<div class=\"pk-text-right pk-text-xs pk-text-default\">支持原创软件，共创美好明天！</div>',0),(66,'template_default_tjwzids','',0),(67,'template_default_jhnum','0',0),(68,'template_default_rtnum','0',0),(69,'defaulttemplates','default',0),(70,'runerrordisplay','1',0),(71,'openreg','1',0),(85,'app_superadmin_load','1',0),(88,'app_puyuetianeditor_load','embed',0),(89,'template_default_ad1htmlcode','',0),(90,'template_default_ad2htmlcode','',0),(91,'template_default_ad3htmlcode','',0),(92,'guestdata','{\"username\":\"guest\",\"nickname\":\"游客\",\"quanxian\":\"bbcode,lookuser,postreply,search,lookread,download,nopostingtimeinterval,nopostmsg\",\"readlevel\":\"0\",\"data\":\"{\\\"htmlcodemarks\\\":\\\"\\\",\\\"htmlcodeattrs\\\":\\\"\\\",\\\"uploadsize\\\":\\\"\\\"}\"}',0),(93,'template_default_randheadcount','24',0),(95,'novicetraineetime','2',0),(96,'postreadcheck','0',0),(97,'postreplycheck','0',0),(107,'app_puyuetian_search_load','embed',0),(108,'app_puyuetian_search_showcount','20',0),(109,'readlistorder','posttime',0),(110,'showmessagecount','50',0),(111,'closeregtip','本站暂未开启注册功能！',0),(112,'uploadheadsize','1000',0),(113,'trylogincount','10',0),(114,'changeuserinfoverify','0',0),(115,'app_puyuetianeditor_pceditconfig','var PytConfig = \'Html,Bold,Italic,Underline,Strikethrough,Removemarks,Fontname,Fontsize,Forecolor,Backcolor,Justifyleft,Justifycenter,Justifyright,Link,Unlink,Table,Emotion,Image,File,Video,Music,Myfiles,Code,Replylook,Undo,Redo\';',0),(116,'app_puyuetianeditor_pcreadconfig','var PytConfig = \'Html,Bold,Italic,Underline,Emotion,Image,Code\';',0),(117,'app_puyuetianeditor_phoneeditconfig','var PytConfig = \'Emotion,Image,File,Link,Code,Replylook\';',0),(118,'app_puyuetianeditor_phonereadconfig','var PytConfig = \'Emotion,Image,Code\';',0),(119,'yunserver','1',0),(120,'phonedomains','',0),(121,'ifpccomephonego','1',0),(122,'phonedefaulttemplates','default',0),(123,'readlistshowbks','',0),(124,'readlisthiddenbks','',0),(125,'usernameeverychars','1',0),(126,'regway','normal',0),(127,'regreadlevel','10',0),(128,'reguserdata','{\"privacysettings\":\"1\"}',0),(129,'app_puyuetianeditor_quickpost','1',0),(130,'app_puyuetianeditor_quickeditconfig','var PytConfig = \'Html,Bold,Italic,Underline,Strikethrough,Justifyleft,Justifycenter,Justifyright,Link,Unlink,Emotion,Image,Code,Replylook,Undo,Redo\';',0),(131,'chkcsrfval','5902d77bf7dcfa64979ee9b998b6a6c9',0),(132,'uploadfilecount','5',0),(133,'dayuploadfilesize','100000',0),(134,'downloadedrecord','1',0),(147,'key','67uM8JBOIV1IDzb2vg8TChryyVkpwE0V',0),(148,'chkcsrf','0',0),(149,'chkcsrfpages','',0),(150,'sitestatus','0',0),(151,'siteclosedtip','维护中...',0),(152,'usercookieslife','31536000',0),(153,'userloginemailtip','0',0),(154,'regusergroupid','1',0),(155,'app_verifycode_load','1',0),(156,'app_verifycode_page','',0),(157,'app_verifycode_chars','1234567890',0),(158,'app_verifycode_length','',0),(159,'app_verifycode_width','',0),(160,'app_verifycode_height','',0),(161,'app_verifycode_fontsize','',0),(162,'app_puyuetianeditor_watermark_text','',0),(163,'app_puyuetianeditor_watermark_textcolor_r','255',0),(164,'app_puyuetianeditor_watermark_textcolor_g','255',0),(165,'app_puyuetianeditor_watermark_textcolor_b','255',0),(166,'app_puyuetianeditor_watermark_pp','0',0),(167,'app_puyuetianeditor_watermark_px','5',0),(168,'app_puyuetianeditor_watermark_py','24',0),(169,'app_puyuetianeditor_watermark_fontsize','14',0),(170,'defaultlabel','原创,爆料',0),(171,'app_hadskycloudserver_load','embed',0),(172,'app_hadskycloudserver_sitekey','',0),(173,'app_hadskycloudserver_qqlogin_openreg','0',0),(174,'app_hadskycloudserver_weibologin_openreg','0',0),(175,'app_hadskycloudserver_baidulogin_openreg','0',0),(176,'app_hadskycloudserver_tiandouduihuanshu','10',0),(177,'phonedefaultpage','list',0),(178,'mysqlcachecycle','0',0),(179,'mysqlcachetables','read',0),(180,'safe_request_uri','0',0),(181,'_webos','HadSky',0),(182,'oldusercentertonewusercenter','1',0),(183,'postmessagemaxnum','1000',0),(184,'postreadtitlecolorusergroup','',0),(185,'banpostwords','',0),(186,'regfriends','_1_',0),(187,'regagreement','请在后台 - 全局 - 注册相关 - 用户注册协议处设置内容',0),(188,'banregwords','',0),(189,'webaddedwords','',0),(190,'mustrewriteurl','1',0),(191,'cookie_domain','',0),(192,'usermultipleonline','1',0),(193,'supermanloginemailtip','0',0),(194,'app_verifycode_opensliding','0',0),(195,'app_puyuetianeditor_pcheight','500px',0),(196,'app_puyuetianeditor_phoneheight','200px',0),(197,'app_puyuetianeditor_compress_wh','1366,0',0),(198,'app_puyuetianeditor_showfile_ad1','',0),(199,'app_puyuetianeditor_showfile_ad2','',0),(200,'app_hadskycloudserver_nodes','{\"shanghai\":\"\\u534e\\u4e1c\\uff08\\u4e0a\\u6d77\\uff09\",\"guangzhou\":\"\\u534e\\u5357\\uff08\\u5e7f\\u5dde\\uff09\",\"hk\":\"\\u9999\\u6e2f\"}',0),(201,'app_hadskycloudserver_node','auto',0),(202,'app_hadskycloudserver_weixinlogin_openreg','0',0),(203,'app_hadskycloudserver_sms_open','1',0),(204,'app_puyuetian_sms_verifycode','1',0),(205,'app_puyuetian_sms_mustreg','0',0),(206,'app_puyuetian_sms_pnmax','',0),(207,'app_puyuetian_sms_ipmax','',0),(208,'app_filesmanager_load','1',0),(209,'app_jvhuo_load','1',0),(210,'app_jvhuo_apiuid','',0),(211,'app_jvhuo_apicode','',0),(212,'app_jvhuo_postuids','',0),(213,'app_jvhuo_postbkid','',0),(214,'app_jvhuo_postlabel','',0),(215,'app_mysqlmanager_load','1',0),(216,'securelogin','1',0),(217,'template_puyuetian_fly_hotreadsortids','',0),(218,'template_puyuetian_fly_hotreadcount','10',0),(219,'template_puyuetian_fly_hotreaddays','',0),(220,'template_puyuetian_fly_ad_yc1','<!--\n<div class=\"fly-panel\">\n\t<h3 class=\"fly-panel-title\">后台 - 应用 - 本地模板 - FlyTemplate设置 - 右侧广告位1</h3>\n\t<ul class=\"fly-panel-main fly-list-static\">\n\t\t<li><a target=\"_blank\" href=\"https://www.hadsky.com\">HadSky轻论坛</a></li>\n\t</ul>\n</div>\n-->',0),(221,'template_puyuetian_fly_ad_yc2','<!--\n<div class=\"fly-panel\">\n\t<div class=\"fly-panel-main\">\n\t\t<a href=\"#\"><img src=\"template/puyuetian_fly/res/images/350ad.png\" alt=\"ad\"></a>\n\t</div>\n</div>\n-->',0),(222,'template_puyuetian_fly_ad_yc3','<!--\n<div class=\"fly-panel\">\n\t<div class=\"fly-panel-title\">后台 - 应用 - 本地模板 - FlyTemplate设置 - 右侧广告位3</div>\n\t<div class=\"fly-panel-main\">\n\t\t<a target=\"_blank\" href=\"https://www.hadsky.com/read-4673-1.html\">HS建站攻略，花最少的钱，建最“骚”的站！</a>\n\t</div>\n</div>\n-->',0),(223,'template_puyuetian_fly_ad_yc4','<!--\n<div class=\"fly-panel\">\n\t<a href=\"#\"><img src=\"template/puyuetian_fly/res/images/380ad.png\" alt=\"ad\"></a>\n</div>\n-->',0),(224,'template_puyuetian_fly_listshowvideo','1',0),(225,'template_puyuetian_fly_readimgnum','3',0),(226,'admin_login_notice_phone','1',0),(227,'app_puyuetian_sms_signname','',0),(228,'globalcdn','0',0),(229,'app_systememail_load','0',0),(230,'app_systememail_phpmailer','0',0),(231,'app_systememail_debug','0',0),(232,'app_systememail_timeoutseconds','',0),(233,'app_systememail_smtp','',0),(234,'app_systememail_port','',0),(235,'app_systememail_user','',0),(236,'app_systememail_pass','',0),(237,'app_systememail_emailverify','0',0),(238,'app_systememail_regsendemail','0',0),(239,'app_systememail_replysendemail','0',0),(240,'app_puyuetianeditor_pceasypostread','0',0),(241,'app_puyuetianeditor_pceasypostreply','0',0),(242,'app_puyuetianeditor_phoneeasypostread','0',0),(243,'app_puyuetianeditor_phoneeasypostreply','1',0),(244,'app_puyuetianeditor_editconfig','',0),(245,'app_puyuetianeditor_readconfig','',0),(246,'activetopreadids','',0),(247,'forumshowids','',0),(248,'deletedreadshowtype','404',0),(249,'showreadlastedittime','1',0),(250,'downloadfilepreview','1',0),(251,'attachmenttimeout','',0),(252,'smartupload','1',0),(253,'template_default_listcontenttype','0',0),(254,'template_default_colorstyle','0',0),(255,'template_default_hiderightdiv','0',0),(256,'template_default_showbkdh','0',0),(257,'template_default_listshowvideo','1',0),(258,'template_default_homesliderlistcount','',0),(259,'template_default_homeslidercode','',0),(260,'template_default_homearticlelistcount','',0),(261,'template_default_homeforumlistcount','',0),(262,'template_default_homeforumids','',0),(263,'app_puyuetian_search_ordertype','posttime',0),(264,'app_puyuetian_search_showinputbox','1',0),(265,'app_puyuetian_search_hotwords','',0),(266,'app_puyuetian_search_logourl','template/default/img/logo.png',0),(267,'app_puyuetian_search_nobkids','',0),(268,'delrrnojt','1',0),(269,'reguserheadauto','0',0),(270,'readlooknumaddtype','1',0),(271,'mweblogo','template/default/img/logo.png',0),(272,'readseoaddwords','1',0),(273,'readseokeywordsaddtitle','1',0),(274,'template_puyuetian_fly_logo','template/puyuetian_fly/res/images/logo.png',0),(275,'app_superadmin_homepluglist',',filesmanager,mysqlmanager,puyuetian_webscan,puyuetian_search,puyuetianeditor,superadmin,systememail,verifycode,puyuetian_codebox,puyuetian_traditional,puyuetian_changable,puyuetian_copyweibo',0),(276,'globaltopreadids','',0),(277,'replyreplyopen','1',0),(278,'regnoemail','1',0),(279,'jifentitle','0|萌新驾到,10|入门新人,50|初出茅庐,100|小有资质,200|网站元老',0),(280,'app_puyuetian_codebox_theme','',0),(281,'app_puyuetian_codebox_load','embed',0),(282,'app_puyuetian_codebox_copy','1',0),(283,'app_puyuetian_codebox_edit','0',0),(284,'template_puyuetian_copyweibo_topmoredata','[{\n\ttext: \'刷新\',\n\tonClick: function() {\n\t\tvar pid = ppp({\n\t\t\ttype: 4,\n\t\t\tshade: 1,\n\t\t\tcontent: \"正在刷新...\"\n\t\t});\n\t\tsetTimeout(function() {\n\t\t\tlocation.reload(true);\n\t\t}, 1500);\n\t}\n}, {\n\ttext: \'分享\',\n\tonClick: function() {\n\t\tvar pid = ppp({\n\t\t\ttype: 4,\n\t\t\tshade: 1,\n\t\t\tcontent: \"正在加载...\"\n\t\t});\n\t\tvar _make_qrcode = function() {\n\t\t\tpkpopup.close(pid);\n\t\t\tvar rnd = \'_\' + randomString(7);\n\t\t\tvar url = location.protocol + \'//\' + location.host + location.pathname + location.search + location.hash;\n\t\t\tppp({\n\t\t\t\ttype: 0,\n\t\t\t\tshade: 1,\n\t\t\t\ttitle: \"分享页面\",\n\t\t\t\tcontent:\'<div id=\"\' + rnd + \'\" style=\"text-align:center;padding:10px;height:192px;width:100%\"></div><input type=\"text\" class=\"pk-textbox\" value=\"\'+url+\'\" readonly><p class=\"pk-text-center pk-text-xs pk-text-danger pk-padding-10\">请保存二维码或URL链接进行分享</p>\',\n\t\t\t\tcomplete: function(_id, _v) {\n\t\t\t\t\t$(\'#pkpopup_\' + _id).find(\'.pk-popup-submit\').html(\'好哒\');\n\t\t\t\t\t$(\'#\' + rnd).qrcode({\n\t\t\t\t\t\twidth: 168,\n\t\t\t\t\t\theight: 168,\n\t\t\t\t\t\ttext: url\n\t\t\t\t\t});\n\t\t\t\t}\n\t\t\t});\n\t\t}\n\t\tif(typeof($.qrcode) == \"undefined\") {\n\t\t\t$.getScript(\'https://cdnjs.cloudflare.com/ajax/libs/jquery.qrcode/1.0/jquery.qrcode.min.js\', function() {\n\t\t\t\t_make_qrcode();\n\t\t\t});\n\t\t} else {\n\t\t\t_make_qrcode();\n\t\t}\n\t}\n}]',0),(285,'template_puyuetian_copyweibo_navdata','<li><a href=\"index.php?c=home\" class=\"\" target=\"\" onclick=\"\">首页</a></li><li><a href=\"index.php?c=list\" class=\"\" target=\"\" onclick=\"\">动态</a></li><li><a href=\"index.php?c=forum\" class=\"\" target=\"\" onclick=\"\">版块</a></li>',0),(286,'template_puyuetian_copyweibo_searchdata','',0),(287,'template_puyuetian_copyweibo_bottomnavdata','[{\n\ttitle: \"首页\",\n\ticon: \"template/puyuetian_copyweibo/img/toolbar/home.png\",\n\ticon2: \"template/puyuetian_copyweibo/img/toolbar/home2.png\",\n\tcolor: \"#000000\",\n\tcolor2: \"#1296db\",\n\thref: \"index.php?c=home\",\n\tclick: function() {},\n\tactionsheet: false\n},{\n\ttitle: \"动态\",\n\ticon: \"template/puyuetian_copyweibo/img/toolbar/list.png\",\n\ticon2: \"template/puyuetian_copyweibo/img/toolbar/list2.png\",\n\tcolor: \"#000000\",\n\tcolor2: \"#1296db\",\n\thref: \"index.php?c=list\",\n\tclick: function() {},\n\tactionsheet: false\n},{\n\ttitle: \"版块\",\n\ticon: \"template/puyuetian_copyweibo/img/toolbar/forum.png\",\n\ticon2: \"template/puyuetian_copyweibo/img/toolbar/forum2.png\",\n\tcolor: \"#000000\",\n\tcolor2: \"#1296db\",\n\thref: \"index.php?c=forum\",\n\tclick: function() {},\n\tactionsheet: false\n},{\n\ttitle: \"我的\",\n\ticon: \"template/puyuetian_copyweibo/img/toolbar/user.png\",\n\ticon2: \"template/puyuetian_copyweibo/img/toolbar/user2.png\",\n\tcolor: \"#000000\",\n\tcolor2: \"#1296db\",\n\thref: \"index.php?c=center\",\n\tclick: function() {},\n\tactionsheet: false\n}]',0),(288,'template_puyuetian_copyweibo_listmaxwords','67',0),(289,'template_puyuetian_copyweibo_listmaximgs','9',0),(290,'template_puyuetian_copyweibo_homeshowbkids','1,2',0),(291,'template_puyuetian_copyweibo_homeslidenum','7',0),(292,'template_puyuetian_copyweibo_homeshowbkreadnum','10',0),(293,'template_puyuetian_copyweibo_homeslidedata','',0),(294,'template_puyuetian_copyweibo_showlabel','1',0),(295,'template_puyuetian_copyweibo_showchildforum','1',0),(296,'template_puyuetian_changable_slidenum','5',0),(297,'template_puyuetian_changable_defaultcolor','#5FB878',0),(298,'template_puyuetian_changable_homereadlistdays','30',0),(299,'template_puyuetian_changable_homereadlistnums','15',0),(300,'template_puyuetian_changable_homeforumids','',0),(301,'template_puyuetian_changable_homenoshowsortids','',0),(302,'template_puyuetian_changable_hotwords','',0),(303,'template_puyuetian_changable_tjwz','looknum:0:10',0),(304,'template_puyuetian_changable_ad1','<!--\n<div style=\"margin:0 auto 15px;width:1170px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位1，1170 x auto</div>\n-->',0),(305,'template_puyuetian_changable_ad2','<!--\n<div style=\"margin:0 auto 15px;width:285px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位2，285 x auto</div>\n-->',0),(306,'template_puyuetian_changable_ad3','<!--\n<div style=\"margin:0 auto 15px;width:285px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位3，285 x auto</div>\n-->',0),(307,'template_puyuetian_changable_ad4','<!--\n<div style=\"margin:0 auto 15px;width:1170px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位4，1170 x auto</div>\n-->',0),(308,'template_puyuetian_changable_homenewnums','10',0),(309,'template_puyuetian_changable_ad5','<!--\n<div style=\"margin:0 auto 15px;width:870px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位5，870 x auto</div>\n-->',0),(310,'template_puyuetian_changable_ad6','<!--\n<div style=\"margin:0 auto;width:150px;height:120px;border-bottom:solid 1px #eee;border-radius:4px\">广告位6，150 x auto</div>\n-->',0),(311,'template_puyuetian_changable_ad7','<!--\n<div style=\"margin:0 auto;width:150px;height:120px;border-top:solid 1px #eee;border-bottom:solid 1px #eee;border-radius:4px\">广告位7，150 x auto</div>\n-->',0),(312,'template_puyuetian_changable_ad8','<!--\n<div style=\"margin:0 auto 15px;width:870px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位8，870 x auto</div>\n-->',0),(313,'template_puyuetian_changable_ad9','<!--\n<div style=\"margin:0 auto 15px;width:1170px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位9，1170 x auto</div>\n-->',0),(314,'template_puyuetian_changable_ad10','<!--\n<div style=\"margin:0 auto 15px;width:1170px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位10，1170 x auto</div>\n-->',0),(315,'template_puyuetian_changable_ad11','<!--\n<div style=\"margin:0 auto 15px;width:1170px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位11，1170 x auto</div>\n-->',0),(316,'template_puyuetian_changable_ad12','<!--\n<div style=\"margin:0 auto 15px;width:1170px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位12，1170 x auto</div>\n-->',0),(317,'template_puyuetian_changable_ad13','<!--\n<div style=\"margin:0 auto 15px;width:1170px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位13，1170 x auto</div>\n-->',0),(318,'template_puyuetian_changable_ad14','<!--\n<div style=\"margin:0 auto 15px;width:1170px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位14，1170 x auto</div>\n-->',0),(319,'template_puyuetian_changable_ad15','<!--\n<div style=\"margin:0 auto 15px;width:1170px;height:120px;border:solid 1px #ccc;border-radius:4px\">广告位15，1170 x auto</div>\n-->',0),(320,'template_puyuetian_changable_listshowvideo','1',0),(321,'template_puyuetian_changable_logo','template/puyuetian_changable/img/logo.png',0),(322,'template_puyuetian_changable_readcontentnum','255',0),(323,'template_puyuetian_changable_readimgnum','3',0),(324,'template_puyuetian_copyweibo_listshowvideo','1',0),(325,'app_puyuetian_traditional_load','embed',0),(326,'app_puyuetian_traditional_auto','0',0),(327,'app_puyuetian_webscan_load','1',0);
DROP TABLE IF EXISTS `pk_upload`;
CREATE TABLE `pk_upload` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传用户',
  `rid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所在的帖子id',
  `name` text COMMENT '上传的文件名',
  `suffix` text COMMENT '文件后缀',
  `uploadtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `datetime` bigint(20) NOT NULL DEFAULT '0' COMMENT '上传时间YYYYMMDDHHIISS',
  `rand` varchar(255) NOT NULL DEFAULT '' COMMENT '产生的随机数',
  `idcode` varchar(255) NOT NULL DEFAULT '' COMMENT '识别码',
  `jifen` int(11) NOT NULL DEFAULT '0' COMMENT '消耗积分',
  `tiandou` int(11) NOT NULL DEFAULT '0' COMMENT '消耗的天豆',
  `target` varchar(255) NOT NULL DEFAULT '' COMMENT '所存在的文件夹',
  `downloadcount` int(11) NOT NULL DEFAULT '0' COMMENT '下载次数',
  `downloadeduids` longtext COMMENT '已下载用户的uid',
  `url` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='论坛附件上传记录';
DROP TABLE IF EXISTS `pk_user`;
CREATE TABLE `pk_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户的uid',
  `username` varchar(100) NOT NULL DEFAULT '' COMMENT '用户名，仅允许字母和数字和下划线',
  `password` text NOT NULL COMMENT '加密后的密码',
  `nickname` text COMMENT '用户昵称',
  `quanxian` text COMMENT '用户具有的权限',
  `tiandou` int(11) NOT NULL DEFAULT '0' COMMENT '天豆数',
  `jifen` int(11) NOT NULL DEFAULT '0' COMMENT '积分数',
  `logininfo` text COMMENT '最后一次登录信息',
  `reginfo` text COMMENT '用户注册信息',
  `sex` text COMMENT '性别',
  `birthday` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '生日',
  `email` varchar(100) DEFAULT NULL COMMENT 'email地址',
  `qq` text COMMENT 'QQ',
  `phone` text COMMENT '手机号',
  `adress` text COMMENT '联系地址',
  `sign` text COMMENT '用户个性签名',
  `friends` text COMMENT '用户好友',
  `readlevel` int(11) NOT NULL DEFAULT '0' COMMENT '用户阅读权限',
  `qqopenid` varchar(255) DEFAULT NULL COMMENT 'qq登录openid',
  `data` longtext COMMENT '用户数据',
  `logintime` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `regtime` int(11) NOT NULL DEFAULT '0' COMMENT '注册时间',
  `session_token` varchar(255) DEFAULT NULL COMMENT '登录时产生的识别码',
  `groupid` int(11) NOT NULL DEFAULT '0' COMMENT '用户组id',
  `wxopenid` varchar(255) DEFAULT NULL COMMENT '微信登录openid',
  `weibo_uid` varchar(255) DEFAULT NULL,
  `baidu_userid` varchar(255) DEFAULT NULL,
  `regip` varchar(255) DEFAULT NULL,
  `loginip` varchar(255) DEFAULT NULL,
  `weixin_openids` text,
  `idol` longtext,
  `fans` longtext,
  `collect` longtext,
  `weixin` varchar(255) NOT NULL DEFAULT '' COMMENT '微信号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';
INSERT INTO `pk_user` VALUES (1,'admin','27da85f99b6e1207a71b6c4dd6404ddb','创始人','bbcode,login,lookuser,postreply,uploadfile,delread,editread,nopostreadcheck,noverifycode,admin,htmlcode,superman,nopostingtimeinterval,nopostreplycheck,editreply,delreply,uploadhead,search,postread,lookread,download',32,32,NULL,NULL,'s',20180709,'admin@hadsky.com','','','','有些梦虽然遥不可及，但并不是不可能实现。',NULL,0,NULL,'{\"trylogindata\":\"{\\\"127.0.0.1\\\":0}\",\"logindate\":\"20240418\",\"lasttimereadposttime\":\"1703574183\",\"privacysettings\":\"0\",\"lasttimereplyposttime\":\"1554345863\"}',1713403216,0,'EBvXKno',0,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,NULL,NULL,'');
DROP TABLE IF EXISTS `pk_user_message`;
CREATE TABLE `pk_user_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '消息的id',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '消息用户的uid',
  `fid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '来自哪个用户的uid',
  `content` text COMMENT '消息内容',
  `islook` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '此消息是否被查看',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '消息添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='用户消息表';
DROP TABLE IF EXISTS `pk_usergroup`;
CREATE TABLE `pk_usergroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usergroupname` varchar(255) NOT NULL DEFAULT '' COMMENT '用户组名称',
  `quanxian` text COMMENT '用户组权限',
  `readlevel` int(11) NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `data` longtext COMMENT '其他数据',
  `readlevelmax` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
INSERT INTO `pk_usergroup` VALUES (1,'普通会员','bbcode,login,lookuser,postreply,uploadfile,uploadhead,search,postread,lookread,download',10,'{\"htmlcodemarks\":\"\",\"htmlcodeattrs\":\"\",\"signcodemarks\":\"\",\"signcodeattrs\":\"\",\"uploadsize\":\"\",\"dayuploadfilesize\":\"\"}',0);
