<?php
if (!defined('puyuetian')) {
    exit('Not Found puyuetian!Please contact QQ632827168');
}

// 兼容php5.x
if (!function_exists('mysql_query')) {
    function mysql_query($query, $link = null)
    {
        return sqlQuery($query);
    }
}
if (!function_exists('mysql_error')) {
    function mysql_error()
    {
        return sqlError();
    }
}

//pdo连接数据库
try {
    switch ($_G['SQL']['TYPE']) {
        case 'mysql':
            $_G['PDO'] = new PDO("{$_G['SQL']['TYPE']}:host={$_G['SQL']['LOCATION']};dbname={$_G['SQL']['DATABASE']};charset=" . trim(str_ireplace('set names', '', $_G['SQL']['CHARSET'])), $_G['SQL']['USERNAME'], $_G['SQL']['PASSWORD'] . '');
            break;
        default:
            PkPopup(json_encode([
                'title'   => '数据库出错',
                'content' => '未定义的数据库类型',
            ]));
            break;
    }
} catch (PDOException $e) {
    PkPopup(json_encode([
        'title'   => 'PDO出错',
        'content' => $e->getMessage(),
    ]));
}

//系统设置的读取,所有设置统一存储为$_G['SET']数组内
$r = $_G['PDO']->query("SELECT `setname`,`setvalue` FROM `{$_G['SQL']['PREFIX']}set` WHERE `noload`=0");
while ($row = $r->fetch(PDO::FETCH_ASSOC)) {
    $_G['SET'][strtoupper($row['setname'])] = $row['setvalue'];
}

//各个数据表对象的实例化，统一放置于$_G['TABLE']内，大写
$prefixlen = strlen($_G['SQL']['PREFIX']);
$r         = $_G['PDO']->query("SHOW TABLES FROM `{$_G['SQL']['DATABASE']}`");
while ($row = $r->fetch(PDO::FETCH_NUM)) {
    if (substr($row[0], 0, $prefixlen) == $_G['SQL']['PREFIX']) {
        $tablename                           = substr($row[0], $prefixlen);
        $_G['TABLE'][strtoupper($tablename)] = new Data($tablename, true);
    }
}

//使用过后的无关变量清理
unset($r, $tablename, $prefixlen, $row);
