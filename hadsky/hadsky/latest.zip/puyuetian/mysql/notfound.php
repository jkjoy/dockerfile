<?php
if (!defined('puyuetian')) {
	exit('403');
}

class notfound
{
	public function __get($property_name)
	{
		return false;
	}

	public function __set($property_name, $value)
	{
		return false;
	}

	public function __isset($property_name)
	{
		return false;
	}

	public function __unset($property_name)
	{
		return false;
	}

	public function __call($methodName, $argument)
	{
		return false;
	}

	public static function __callstatic($methodName, $argument)
	{
		return false;
	}
}
