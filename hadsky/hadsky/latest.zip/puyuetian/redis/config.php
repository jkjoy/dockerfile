<?php
    if (!defined('puyuetian')) {
        exit('403');
    }

    g([
        'redis' => [
            'open'    => 0,
            'host'    => '127.0.0.1',
            'pass'    => '',
            'port'    => 6379,
            'dbno'    => 0,
            'timeout' => 0,
            'expire'  => 300,
            'prefix'  => 'hadsky_',
            'tables'  => 'reply_reply,reply,read'
        ],
    ]);
