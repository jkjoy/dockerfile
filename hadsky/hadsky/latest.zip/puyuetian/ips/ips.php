<?php
if (!defined('puyuetian')) {
	exit('403');
}

$_G['SYSTEM']['CLIENTIP'] = getClientInfos('ip');
$cip = explode('.', $_G['SYSTEM']['CLIENTIP']);
$ips = file_get_contents($_G['SYSTEM']['PATH'] . 'puyuetian/ips/config.hst');
if ($ips) {
	$ips = explode(',', $ips);
	foreach ($ips as $ip) {
		if (!$ip) {
			continue;
		}
		$ip = explode('.', $ip);
		$ban = true;
		foreach ($ip as $key => $value) {
			if ($cip[$key] != $value && $value != '*') {
				$ban = false;
				break;
			}
		}
		if ($ban) {
			PkPopup('{
				content:"您的IP：' . $_G['SYSTEM']['CLIENTIP'] . '处于网站黑名单中，请联系管理员。",
				icon:2,
				shade:1,
				hideclose:1,
				nomove:1,
				title:"禁止访问",
				submit:function(){
					window.close()
				}
			}');
		}
	}
	unset($ip, $ban, $key, $value);
}
unset($cip, $ips);
