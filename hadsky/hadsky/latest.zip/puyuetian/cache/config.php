<?php
define('HADSKY_CACHELIFE', 0);
define('HADSKY_CACHEPAGES', 'home,forum,list,read');
define('HADSKY_CACHEREFRESH', 1);
