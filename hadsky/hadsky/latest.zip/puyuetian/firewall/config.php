<?php
if (!defined('puyuetian'))
	exit('403');

define('HADSKY_FIREWALL_SWITCH', 0);
define('HADSKY_FIREWALL_RANGE', 'uri,get,user-agent');
define('HADSKY_FIREWALL_WHITELIST_UID', 0);
define('HADSKY_FIREWALL_WHITELIST_UGID', 0);
define('HADSKY_FIREWALL_WRITELOG', 1);