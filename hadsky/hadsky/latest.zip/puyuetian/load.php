<?php
if (!defined('puyuetian')) {
    exit('Not Found puyuetian!Please contact QQ632827168');
}

// get获取所要访问的文件，phpscript文件夹内
if (!g('get.c')) {
    g('get.c', Cstr(set('defaultpage'), 'main', true, 1, 255));
}

sys('scriptpath', sys('path') . 'phpscript/' . g('get.c') . '.php');
if (!file_exists(sys('scriptpath'))) {
    header('HTTP/1.1 404 Not Found');
    header('status: 404 Not Found');
    g('htmlcode.main', template('error', true));
    template(g('template.main'));
    exit;
}

//防止CSRF攻击
if (set('chkcsrfpages') && InArray(set('chkcsrfpages'), strtolower(g('get.c'))) && g('chkcsrfval') != $_POST['chkcsrfval'] && g('chkcsrfval') != $_GET['chkcsrfval']) {
    PkPopup('{
		title:"警告",
		content:"疑似CSRF攻击的操作，已被系统拦截！",
		icon:2,
		close:function(){
			location.href="index.php"
		},
		hideclose:1,
		shade:1
	}');
} else {
	// 部分插件公共环境运行，无法独立
    require sys('scriptpath');
}
