<?php
if (!defined('puyuetian')) {
    exit('Not Found puyuetian!Please contact QQ632827168');
}

/********************************************
puyuetianPHP框架扩展部分初始化代码
 *******************************************/

// 发布预设变量
$postarray = [];
// 注册预设变量
$regarray = [];

(function () {
    // 自动扩展框架php脚本
    $sysfiles = ['function', 'hadsky'];
    $path     = sys('path') . 'puyuetian/ext/';
    foreach ($sysfiles as $sysfile) {
        (function ($EXT_PHP_PATH) {
            require $EXT_PHP_PATH . '.php';
        })($path . $sysfile);
    }
    // 8.1.0临时不加载文件
    // $sysfiles  = array_merge($sysfiles, ['uia', 'loadapps', 'normal', 'preload']);
    $files     = [];
    $total     = 0;
    $loadinfo  = '';
    $PLUGFILES = scandir($path);
    foreach ($PLUGFILES as $FILENAME) {
        $file = $path . $FILENAME;
        if (is_file($file) == 'file' && end(explode('.', $FILENAME)) == 'php' && !InArray($sysfiles, basename($FILENAME, '.php'))) {
            $total++;
            $files[] = $file;
            (function ($EXT_PHP_PATH) {
                require $EXT_PHP_PATH;
            })($file);
        }
    }
    $loadinfo .= "共加载HadSky扩展{$total}个\n";
    g([
        'ext.path'     => $path,
        'ext.total'    => $total,
        'ext.files'    => $files,
        'ext.loadinfo' => $loadinfo,
    ]);
})();
