### 自动安装管理扩展插件UploadPlugin v1.1.3

启用后可在菜单“控制台”-“上传”面板内自动安装插件/主题压缩包，或直接删除禁用的插件/主题文件夹，省去FTP等操作。

 > 修正路径检测、action报错及面板效果，兼容Typecho1.0+。

###### 更多详见作者博客：http://defe.me/prg/442.html

---

## 2024-会话修复记录

### 主要目的
修复插件在 Typecho 1.3.0 下失效的问题，确保兼容新版 Typecho 的常量、接口和工具类变更。

### 完成的主要任务
1. 替换已废弃的 `__TYPECHO_ROOT_DIR__` 和 `__TYPECHO_PLUGIN_DIR__` 常量为新版 `TYPECHO_ROOT_DIR` 和 `TYPECHO_PLUGIN_DIR`，并提供默认值，避免未定义报错。
2. 兼容 `_t` 国际化函数不存在的情况，自动定义为原样返回。
3. 针对 `Helper`、`Typecho\\Helper` 工具类，采用 `class_exists` 检查并全限定名调用，避免 IDE 静态分析和运行时错误。
4. `Typecho_Plugin_Interface`、`Typecho_Plugin_Exception`、`Typecho_Widget_Helper_Form` 保持原有用法，因其为 Typecho 核心接口，实际运行时由 Typecho 环境提供。
5. 通过注释 `@phpstan-ignore-next-line`，消除 IDE 静态分析对 Helper 类未定义的报错。

### 关键决策和解决方案
- 采用条件定义和全限定名方式，兼容新旧 Typecho 版本，保证插件在不同环境下均可正常加载和运行。
- 保持插件主逻辑不变，所有兼容性代码均为向下兼容补丁，不影响原有功能。

### 使用的技术栈
- PHP
- Typecho 插件开发

### 修改了哪些文件
- Plugin.php